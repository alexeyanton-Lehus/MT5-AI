@echo off
setlocal
title MT5 AI - FULL AUTOSTART RESET

echo.
echo ==========================================
echo       MT5 AI - FULL AUTOSTART RESET
echo ==========================================
echo.

echo [1] Stopping MT5-TRADE processes...
taskkill /F /IM python.exe >nul 2>&1
taskkill /F /IM pythonw.exe >nul 2>&1

echo [2] Stopping MT5 terminals...
taskkill /F /IM terminal64.exe >nul 2>&1

echo [3] Removing Scheduled Tasks...
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
"Get-ScheduledTask -ErrorAction SilentlyContinue | Where-Object { $_.TaskName -like 'MT5-TRADE*' } | ForEach-Object { Write-Host ('Removing: ' + $_.TaskName); Unregister-ScheduledTask -TaskName $_.TaskName -Confirm:$false -ErrorAction SilentlyContinue }"

echo.
echo [4] Removing possible old startup shortcuts...

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
"$paths=@([Environment]::GetFolderPath('Startup'), 'C:\ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp'); foreach($p in $paths){ if(Test-Path $p){ Get-ChildItem $p -Force -ErrorAction SilentlyContinue | Where-Object { $_.Name -like '*MT5*' -or $_.Name -like '*TRADE*' -or $_.Name -like '*autonomous*' -or $_.Name -like '*trading*' } | ForEach-Object { Write-Host ('Removing startup item: ' + $_.FullName); Remove-Item $_.FullName -Force -ErrorAction SilentlyContinue } }}"

echo.
echo [5] Checking remaining Scheduled Tasks...
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
"Get-ScheduledTask -ErrorAction SilentlyContinue | Where-Object { $_.TaskName -like '*MT5*' -or $_.TaskName -like '*TRADE*' } | Select-Object TaskName,State,TaskPath"

echo.
echo [6] Checking remaining Python/MT5 processes...
echo.

tasklist | findstr /I "python pythonw terminal64"

echo.
echo ==========================================
echo RESET FINISHED
echo ==========================================
echo.
pause