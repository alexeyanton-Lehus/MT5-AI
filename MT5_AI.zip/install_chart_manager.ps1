﻿$ErrorActionPreference = 'Stop'

$ProjectRoot = 'C:\MT5_AI'
$TradingTerminal = 'C:\Program Files\Ava Trade MT5 Terminal\terminal64.exe'
$MetaEditor = 'C:\Program Files\Ava Trade MT5 Terminal\metaeditor64.exe'

$UiTarget = Join-Path $ProjectRoot 'MT5-TRADE\trade_mt5\ui.py'
$BridgeTarget = Join-Path $ProjectRoot 'MT5-TRADE\trade_mt5\chart_manager.py'
$PayloadUi = Join-Path $PSScriptRoot 'MT5-TRADE\trade_mt5\ui.py'
$PayloadBridge = Join-Path $PSScriptRoot 'MT5-TRADE\trade_mt5\chart_manager.py'
$PayloadEa = Join-Path $PSScriptRoot 'MT5-TRADE\mql5\Experts\MT5AI\MT5AI_ChartManager.mq5'

Write-Host '=== MT5_AI chart manager install ===' -ForegroundColor Cyan

if (-not (Test-Path $TradingTerminal)) {
    throw "Trading MT5 not found: $TradingTerminal"
}
if (-not (Test-Path $MetaEditor)) {
    throw "MetaEditor not found: $MetaEditor"
}

New-Item -ItemType Directory -Force -Path (Split-Path $UiTarget) | Out-Null
New-Item -ItemType Directory -Force -Path (Split-Path $BridgeTarget) | Out-Null

# If the archive was extracted directly into C:\MT5_AI, the files are already
# in their final locations. Otherwise copy them into the project.
if ((Resolve-Path $PayloadUi).Path -ne (Resolve-Path $UiTarget -ErrorAction SilentlyContinue).Path) {
    Copy-Item $PayloadUi $UiTarget -Force
}
if ((Resolve-Path $PayloadBridge).Path -ne (Resolve-Path $BridgeTarget -ErrorAction SilentlyContinue).Path) {
    Copy-Item $PayloadBridge $BridgeTarget -Force
}

# Locate the exact editable data directory belonging to this trading terminal.
# origin.txt stores the installation DIRECTORY, not terminal64.exe itself.
$terminalDirNorm = [IO.Path]::GetFullPath((Split-Path $TradingTerminal -Parent)).TrimEnd('\\').ToLowerInvariant()
$dataRoot = $null
$originFiles = Get-ChildItem (Join-Path $env:APPDATA 'MetaQuotes\Terminal') -Filter 'origin.txt' -File -Recurse -ErrorAction SilentlyContinue
foreach ($origin in $originFiles) {
    try {
        $originText = (Get-Content $origin.FullName -Raw -ErrorAction Stop).Trim().TrimEnd('\\').ToLowerInvariant()
        if ($originText -eq $terminalDirNorm) {
            $dataRoot = $origin.Directory.FullName
            break
        }
    } catch {}
}

if (-not $dataRoot) {
    throw "Trading MT5 data folder was not found via origin.txt for $TradingTerminal"
}

Write-Host "Trading MT5 data folder: $dataRoot"

$eaDir = Join-Path $dataRoot 'MQL5\Experts\MT5AI'
New-Item -ItemType Directory -Force -Path $eaDir | Out-Null
$eaSource = Join-Path $eaDir 'MT5_AI_ChartManager.mq5'
$eaEx5 = Join-Path $eaDir 'MT5_AI_ChartManager.ex5'
Copy-Item $PayloadEa $eaSource -Force

Write-Host 'Compiling MQL5 chart manager...' -ForegroundColor Yellow
& $MetaEditor "/compile:$eaSource" /log | Out-Null
Start-Sleep -Milliseconds 800

$log = [IO.Path]::ChangeExtension($eaSource, '.log')
if (-not (Test-Path $eaEx5)) {
    $detail = if (Test-Path $log) { (Get-Content $log -Tail 30) -join [Environment]::NewLine } else { 'Compilation log not found.' }
    throw "MT5_AI_ChartManager.ex5 was not created.`n$detail"
}

Write-Host "EX5 ready: $eaEx5" -ForegroundColor Green

python -m py_compile $UiTarget, $BridgeTarget
Write-Host 'Python syntax OK.' -ForegroundColor Green

Write-Host ''
Write-Host 'ONE-TIME ACTION:' -ForegroundColor Yellow
Write-Host '1. In the trading MT5, open one separate chart that is not used for trading.'
Write-Host '2. Attach Expert Advisor: MT5AI -> MT5_AI_ChartManager.'
Write-Host '3. Leave this EA running permanently.'
Write-Host 'After that Python can create new charts and apply the template without mouse or keyboard automation.'
