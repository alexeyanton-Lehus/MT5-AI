from pywinauto import Desktop
import traceback

OUTPUT_FILE = "mt5_ui_tree.txt"


def write(line):
    print(line)
    with open(OUTPUT_FILE, "a", encoding="utf-8") as f:
        f.write(line + "\n")


def print_tree(ctrl, level=0, max_level=10):
    if level > max_level:
        return

    indent = "    " * level

    try:
        info = ctrl.element_info

        try:
            rect = ctrl.rectangle()
            rect_str = f"{rect.left},{rect.top},{rect.right},{rect.bottom}"
        except:
            rect_str = "-"

        write(
            f"{indent}"
            f"Type={info.control_type} | "
            f"Class={info.class_name} | "
            f"Name='{info.name}' | "
            f"AutomationId='{info.automation_id}' | "
            f"Rect={rect_str}"
        )

    except Exception as e:
        write(indent + str(e))
        return

    try:
        for child in ctrl.children():
            print_tree(child, level + 1, max_level)
    except:
        pass


def main():

    open(OUTPUT_FILE, "w", encoding="utf-8").close()

    write("=" * 90)
    write("Поиск окон MT5")
    write("=" * 90)

    desktop = Desktop(backend="uia")

    windows = []

    for w in desktop.windows():

        try:
            title = w.window_text()

            # Исключаем Visual Studio Code
            if "Visual Studio Code" in title:
                continue

            cls = w.element_info.class_name

            if (
                "Terminal" in title
                or "MetaTrader" in title
                or "MT5" in title
                or "MetaQuotes" in cls
            ):
                windows.append(w)

        except:
            pass

    if not windows:
        write("Окно MT5 не найдено.")
        return

    write("")

    for i, w in enumerate(windows):

        try:
            write(
                f"[{i}] "
                f"{w.window_text()} | "
                f"Class={w.element_info.class_name} | "
                f"PID={w.process_id()}"
            )
        except:
            pass

    write("")

    index = int(input("Введите номер окна MT5: "))

    win = windows[index]

    write("")
    write("=" * 90)
    write("Информация об окне")
    write("=" * 90)

    write(f"Title : {win.window_text()}")
    write(f"Class : {win.element_info.class_name}")
    write(f"PID   : {win.process_id()}")

    try:
        rect = win.rectangle()
        write(f"Rect  : {rect}")
    except:
        pass

    write("")
    write("=" * 90)
    write("Дерево элементов")
    write("=" * 90)

    print_tree(win)

    write("")
    write("=" * 90)
    write(f"Готово. Результат сохранен в {OUTPUT_FILE}")
    write("=" * 90)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()