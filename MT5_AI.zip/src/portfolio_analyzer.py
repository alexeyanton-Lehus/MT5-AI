from __future__ import annotations

import argparse
import csv
import html
import json
import re
from dataclasses import dataclass
from datetime import datetime
from html.parser import HTMLParser
from pathlib import Path
from typing import Iterable

from project_paths import TRADE_REPORTS_DIR


@dataclass
class Deal:
    time: datetime
    symbol: str
    deal_type: str
    direction: str
    volume: float
    price: float | None = None
    source_report: str = ""


class _TableParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.rows: list[list[str]] = []
        self._row: list[str] | None = None
        self._cell_parts: list[str] | None = None
        self._skip = 0

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        if tag in {"script", "style"}:
            self._skip += 1
            return
        if self._skip:
            return
        if tag == "tr":
            if self._row is not None:
                self._finish_row()
            self._row = []
        elif tag in {"td", "th"} and self._row is not None:
            if self._cell_parts is not None:
                self._finish_cell()
            self._cell_parts = []

    def handle_endtag(self, tag):
        tag = tag.lower()
        if tag in {"script", "style"}:
            if self._skip:
                self._skip -= 1
            return
        if self._skip:
            return
        if tag in {"td", "th"}:
            self._finish_cell()
        elif tag == "tr":
            self._finish_row()

    def handle_data(self, data):
        if not self._skip and self._cell_parts is not None:
            self._cell_parts.append(data)

    def _finish_cell(self):
        if self._row is None or self._cell_parts is None:
            return
        text = re.sub(r"\s+", " ", " ".join(self._cell_parts).replace("\xa0", " ")).strip()
        self._row.append(text)
        self._cell_parts = None

    def _finish_row(self):
        if self._row is not None:
            if self._cell_parts is not None:
                self._finish_cell()
            if self._row:
                self.rows.append(self._row)
        self._row = None
        self._cell_parts = None


def _decode(raw: bytes) -> str:
    if raw.startswith(b"\xff\xfe"):
        return raw.decode("utf-16-le")
    if raw.startswith(b"\xfe\xff"):
        return raw.decode("utf-16-be")
    if raw.startswith(b"\xef\xbb\xbf"):
        return raw.decode("utf-8-sig")
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError:
        return raw.decode("cp1251", errors="replace")


def _norm(s: str) -> str:
    return re.sub(r"[^a-zа-яіїє0-9]+", "", s.lower())


def _num(s: str) -> float | None:
    s = html.unescape(s).strip().replace("\xa0", " ")
    s = re.sub(r"[^0-9,\.\-+]+", "", s)
    if not s:
        return None
    if "," in s and "." in s:
        if s.rfind(",") > s.rfind("."):
            s = s.replace(".", "").replace(",", ".")
        else:
            s = s.replace(",", "")
    elif "," in s:
        s = s.replace(",", ".")
    try:
        return float(s)
    except ValueError:
        return None


def _parse_time(s: str) -> datetime | None:
    s = re.sub(r"\s+", " ", s.strip())
    for fmt in (
        "%Y.%m.%d %H:%M:%S",
        "%Y.%m.%d %H:%M",
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d %H:%M",
        "%d.%m.%Y %H:%M:%S",
        "%d.%m.%Y %H:%M",
    ):
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            pass
    return None


def _find_column(headers: list[str], aliases: Iterable[str]) -> int | None:
    normalized = [_norm(x) for x in headers]
    aliases = [_norm(x) for x in aliases]
    for alias in aliases:
        for i, value in enumerate(normalized):
            if value == alias or alias in value:
                return i
    return None


def parse_report(path: Path) -> list[Deal]:
    text = _decode(path.read_bytes())
    parser = _TableParser()
    parser.feed(text)

    all_rows = parser.rows
    deals_header = None
    deals_rows: list[list[str]] = []

    for i, row in enumerate(all_rows):
        joined = " ".join(_norm(x) for x in row)
        has_time = _find_column(row, ["Time", "Время", "Час"]) is not None
        has_deal = _find_column(row, ["Deal", "Сделка", "Угода", "Трейд"]) is not None
        has_symbol = _find_column(row, ["Symbol", "Символ", "Символ"])
        has_volume = _find_column(row, ["Volume", "Объем", "Объём", "Обсяг"])
        has_direction = _find_column(row, ["Direction", "Направление", "Напрямок"])
        has_type = _find_column(row, ["Type", "Тип"])
        if has_time is not None and has_deal is not None and has_symbol is not None and has_volume is not None and has_direction is not None and has_type is not None:
            deals_header = row
            deals_rows = all_rows[i + 1 :]
            break

    if deals_header is None:
        raise RuntimeError(f"Не найдена таблица Deals в отчёте: {path}")

    idx_time = _find_column(deals_header, ["Time", "Время", "Час"])
    idx_symbol = _find_column(deals_header, ["Symbol", "Символ"])
    idx_type = _find_column(deals_header, ["Type", "Тип"])
    idx_direction = _find_column(deals_header, ["Direction", "Направление", "Напрямок"])
    idx_volume = _find_column(deals_header, ["Volume", "Объем", "Объём", "Обсяг"])
    idx_price = _find_column(deals_header, ["Price", "Цена", "Ціна"])

    deals: list[Deal] = []
    for row in deals_rows:
        if max(idx_time, idx_symbol, idx_type, idx_direction, idx_volume) >= len(row):
            continue
        dt = _parse_time(row[idx_time])
        volume = _num(row[idx_volume])
        if dt is None or volume is None or volume <= 0:
            continue
        symbol = row[idx_symbol].strip()
        deal_type = row[idx_type].strip().lower()
        direction = row[idx_direction].strip().lower()
        price = _num(row[idx_price]) if idx_price is not None and idx_price < len(row) else None
        deals.append(Deal(dt, symbol, deal_type, direction, volume, price, str(path)))

    if not deals:
        raise RuntimeError(f"В таблице Deals нет распознанных сделок: {path}")
    return deals


def _is_in(direction: str) -> bool:
    n = _norm(direction)
    return n in {"in", "вход", "входврынок", "входвугоду", "входврынок"}


def _is_out(direction: str) -> bool:
    n = _norm(direction)
    return n in {"out", "выход", "выходизрынка", "выходизугоды"}


def _side(deal_type: str) -> str | None:
    n = _norm(deal_type)
    if n in {"buy", "покупка", "купить", "buyin"}:
        return "BUY"
    if n in {"sell", "продажа", "продать", "sellout"}:
        return "SELL"
    return None


def load_top1_reports(root: Path) -> tuple[list[tuple[str, Path, dict]], list[str]]:
    selected = []
    errors = []
    if not root.exists():
        return selected, [f"Не найдена папка: {root}"]

    for manifest in sorted(root.glob("*/manifest.json")):
        try:
            data = json.loads(manifest.read_text(encoding="utf-8"))
            entries = data if isinstance(data, list) else []
            top1 = next((x for x in entries if int(x.get("rank", -1)) == 1), None)
            if not top1:
                errors.append(f"{manifest.parent.name}: TOP1 отсутствует в manifest.json")
                continue
            report = Path(top1.get("report", ""))
            if not report.exists():
                # Fallback for manifests copied between machines.
                report = manifest.parent / Path(str(top1.get("report", ""))).name
            if not report.exists():
                errors.append(f"{manifest.parent.name}: отчёт TOP1 не найден: {top1.get('report')}")
                continue
            selected.append((manifest.parent.name, report, top1))
        except Exception as exc:
            errors.append(f"{manifest}: {exc}")
    return selected, errors


def analyze(root: Path, output: Path) -> dict:
    selected, errors = load_top1_reports(root)
    all_deals: list[Deal] = []
    source_rows = []

    for symbol, report, manifest in selected:
        try:
            deals = parse_report(report)
            all_deals.extend(deals)
            source_rows.append({
                "symbol": symbol,
                "pass": manifest.get("pass"),
                "report": str(report),
                "deals": len(deals),
            })
        except Exception as exc:
            errors.append(f"{symbol}: {report}: {exc}")

    all_deals.sort(key=lambda d: (d.time, d.symbol))
    positions: dict[tuple[str, str], float] = {}
    timeline = []
    max_total = 0.0
    max_record = None
    ambiguous = 0

    for deal in all_deals:
        side = _side(deal.deal_type)
        direction = _norm(deal.direction)
        if side is None:
            ambiguous += 1
            continue

        if _is_in(direction):
            positions[(deal.symbol, side)] = positions.get((deal.symbol, side), 0.0) + deal.volume
        elif _is_out(direction):
            positions[(deal.symbol, side)] = max(0.0, positions.get((deal.symbol, side), 0.0) - deal.volume)
        else:
            # MT5 can report a combined in/out deal. We cannot split its volume
            # reliably from the HTML alone, so flag it instead of inventing data.
            ambiguous += 1
            continue

        # Remove numerical dust.
        positions = {k: v for k, v in positions.items() if v > 1e-12}
        total_lots = sum(positions.values())
        snapshot = {
            "time": deal.time.isoformat(sep=" "),
            "event_symbol": deal.symbol,
            "event_type": deal.deal_type,
            "event_direction": deal.direction,
            "event_volume": deal.volume,
            "total_open_lots": round(total_lots, 10),
            "open_positions": [
                {"symbol": s, "side": side_, "lots": round(v, 10)}
                for (s, side_), v in sorted(positions.items())
            ],
        }
        timeline.append(snapshot)
        if total_lots > max_total:
            max_total = total_lots
            max_record = snapshot

    output.mkdir(parents=True, exist_ok=True)
    selected_file = output / "selected_top1.json"
    timeline_file = output / "portfolio_lots_timeline.csv"
    deals_file = output / "portfolio_deals.csv"
    summary_file = output / "portfolio_summary.json"

    selected_file.write_text(json.dumps(source_rows, indent=2, ensure_ascii=False), encoding="utf-8")

    with deals_file.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f, delimiter=";")
        writer.writerow(["Time", "Symbol", "Type", "Direction", "Volume", "Price", "SourceReport"])
        for d in all_deals:
            writer.writerow([d.time.strftime("%Y-%m-%d %H:%M:%S"), d.symbol, d.deal_type, d.direction, d.volume, d.price if d.price is not None else "", d.source_report])

    with timeline_file.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f, delimiter=";")
        writer.writerow(["Time", "EventSymbol", "EventType", "EventDirection", "EventVolume", "TotalOpenLots", "OpenPositions"])
        for row in timeline:
            writer.writerow([
                row["time"], row["event_symbol"], row["event_type"], row["event_direction"],
                row["event_volume"], row["total_open_lots"],
                json.dumps(row["open_positions"], ensure_ascii=False),
            ])

    summary = {
        "source_directory": str(root),
        "selected_top1_count": len(source_rows),
        "parsed_deals": len(all_deals),
        "max_simultaneous_open_lots": round(max_total, 10),
        "max_lots_event": max_record,
        "ambiguous_deals_not_counted": ambiguous,
        "errors": errors,
        "margin_and_deposit_load": {
            "status": "not_calculated",
            "reason": "MT5 HTM trade reports do not contain enough information for exact historical margin/deposit-load reconstruction across multiple symbols."
        },
        "files": {
            "selected_top1": str(selected_file),
            "portfolio_deals": str(deals_file),
            "portfolio_lots_timeline": str(timeline_file),
        },
    }
    summary_file.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")

    print("\n========== PORTFOLIO ANALYSIS ==========")
    print(f"TOP-1 отчётов: {len(source_rows)}")
    print(f"Сделок: {len(all_deals)}")
    print(f"Максимум одновременно открытых лотов: {max_total:.4f}")
    if max_record:
        print(f"Момент максимума: {max_record['time']}")
        print(f"Открыто: {max_record['open_positions']}")
    if ambiguous:
        print(f"Неоднозначных in/out сделок: {ambiguous}")
    if errors:
        print(f"Ошибок/предупреждений: {len(errors)}")
    print(f"Итог: {summary_file}")
    return summary


def main():
    parser = argparse.ArgumentParser(description="Объединение TOP-1 MT5 trade reports и расчёт максимума одновременно открытых лотов.")
    parser.add_argument("--root", type=Path, default=TRADE_REPORTS_DIR)
    parser.add_argument("--output", type=Path, default=TRADE_REPORTS_DIR / "_portfolio_analysis")
    args = parser.parse_args()
    analyze(args.root, args.output)


if __name__ == "__main__":
    main()
