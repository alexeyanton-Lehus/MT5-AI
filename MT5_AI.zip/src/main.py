from pathlib import Path
import json
from datetime import datetime, timedelta

from config_loader import load_config
from config_loader import load_tester_config

from data.database import init_database
from mt5.mt5_connector import MT5Connector
from optimizer.optimization_pipeline import OptimizationPipeline
from deposit_sync import sync_tester_deposit_from_test_mt5

# Manual optimization handoff: reuse the same publication/application logic
# as the autonomous supervisor without ever launching the trading MT5 on a weekend.
import sys
TRADE_ROOT = Path(__file__).resolve().parent.parent / "MT5-TRADE"
if str(TRADE_ROOT) not in sys.path:
    sys.path.insert(0, str(TRADE_ROOT))
from autonomous import (
    publish_cycle,
    apply_pending,
    ensure_trading_terminal,
    in_trading_window,
    now_local,
    start_dashboard,
    schedule_next,
    load_auto_state,
    save_auto_state,
    current_batch_application_status,
    retry_apply_schedule,
    commit_schedule_after_application,
)


def main():
    print("\n========== MT5 AI ==========\n", flush=True)

    cfg = load_config()
    start_dashboard()

    # The dashboard may be opened at any time, but the optimization pipeline
    # must run only when the autonomous 14-day deadline is due.  In particular,
    # starting main.py manually must NOT start a new optimization before
    # next_optimization_at.
    state = load_auto_state()
    next_optimization_raw = state.get("next_optimization_at")
    if next_optimization_raw:
        try:
            next_optimization_at = datetime.fromisoformat(next_optimization_raw)
            current_time = now_local()
            if next_optimization_at.tzinfo is None:
                next_optimization_at = next_optimization_at.replace(
                    tzinfo=current_time.tzinfo
                )

            if current_time < next_optimization_at:
                print(
                    "Оптимизация ещё не наступила по расписанию. "
                    f"Следующая оптимизация: {next_optimization_at.isoformat(timespec='seconds')}",
                    flush=True,
                )
                print(
                    "GUI оставлен открытым; TEST MT5 и новый цикл оптимизации не запускаются.",
                    flush=True,
                )
                return
        except (TypeError, ValueError) as exc:
            raise RuntimeError(
                f"Некорректное значение next_optimization_at: {next_optimization_raw!r}"
            ) from exc

    tester = load_tester_config()
    test_terminal_path = cfg["mt5_path"]

    # The TEST MT5 is owned by this Python process. Start it first so the
    # MetaTrader5 API cannot launch an unminimized terminal behind our back.
    # The trading MT5 is never touched here.
    mt5 = MT5Connector()
    manifest = None
    try:
        mt5.start_terminal()

        # Test and trading terminals use the same account. Attach to the
        # already-running TEST terminal and read Balance/Currency without
        # allowing the API to start another terminal instance.
        balance, currency, old = sync_tester_deposit_from_test_mt5(
            test_terminal_path, allow_start=False
        )
        print(
            f"Депозит синхронизирован из тестового MT5: {balance:.2f} {currency} "
            f"(было {old[0]} {old[1] or ''})",
            flush=True,
        )

        tester = load_tester_config()
        if float(tester["deposit"]) != balance or str(tester.get("currency", "")).upper() != currency:
            raise RuntimeError("tester.json не содержит только что синхронизированные Balance/Currency")

        init_database()
        pipeline = OptimizationPipeline(mt5)
        manifest = pipeline.run_all()
    finally:
        mt5.disconnect()

    # Publish every fresh successful SET even when some pairs failed. Missing
    # pairs keep their previous trading SETs.
    trade_cfg = json.loads((TRADE_ROOT / "config.json").read_text(encoding="utf-8"))
    batch_id, published = publish_cycle(manifest)
    print(
        f"Торговый batch опубликован: {batch_id}; свежих валют={len(published)}; "
        f"неуспешных={len(manifest.get('failed_symbols', []))}", flush=True
    )

    # A partial cycle is not committed as the new 14-day successful cycle.
    # Fresh SETs are still handed to MT5-TRADE immediately.
    if not manifest.get("complete"):
        # IMPORTANT: reserve the retry BEFORE any trading-MT5 UI work.
        # A UI exception must never leave the old 14-day next_optimization_at
        # in autonomous_state.json and block recovery of this incomplete cycle.
        completed_at = datetime.now().astimezone()
        state = load_auto_state()
        retry_at = completed_at + timedelta(minutes=5)
        state["last_failed_optimization_at"] = completed_at.isoformat(timespec="seconds")
        state["next_optimization_at"] = retry_at.isoformat(timespec="seconds")
        state["retry_after"] = retry_at.isoformat(timespec="seconds")
        state.pop("last_successful_optimization_at", None)
        save_auto_state(state)
        print(f"Незавершённый цикл. Повтор через 5 минут: {state['next_optimization_at']}", flush=True)

        trade_now = now_local()
        if in_trading_window(trade_now, trade_cfg.get("trading_window", {})):
            launched = ensure_trading_terminal(trade_cfg, "ОПТИМИЗАЦИОННЫЙ HANDOFF")
            if launched:
                import time
                time.sleep(8)
            applied = apply_pending(trade_cfg, force=False)
            print(f"Свежие настройки применены в торговом MT5: {applied} SET", flush=True)
        else:
            print("Частичный batch сохранён; применение к торговому MT5 произойдёт в разрешённое окно.", flush=True)
        failed = ", ".join(manifest.get("failed_symbols", []))
        print(f"Цикл завершён с пропусками: {failed or 'неизвестно'}", flush=True)
        return

    # A manual optimization is a real completed optimization cycle too.
    # First publish the complete current-cycle SET batch to trading_input.
    # This is the same handoff used by the autonomous optimizer.
    # On weekdays inside the trading window, start the exact configured trading
    # MT5 if necessary and immediately apply the new SETs. On weekends the
    # trading MT5 is NEVER started; the published batch waits for Monday.
    trade_now = now_local()
    if in_trading_window(trade_now, trade_cfg.get("trading_window", {})):
        launched = ensure_trading_terminal(trade_cfg, "ОПТИМИЗАЦИОННЫЙ HANDOFF")
        if launched:
            import time
            time.sleep(8)
        try:
            applied = apply_pending(trade_cfg, force=False)
        except Exception as exc:
            failed_at = datetime.now().astimezone()
            state = load_auto_state()
            retry_at = failed_at + timedelta(minutes=5)
            state["last_failed_optimization_at"] = failed_at.isoformat(timespec="seconds")
            state["next_optimization_at"] = retry_at.isoformat(timespec="seconds")
            state["retry_after"] = retry_at.isoformat(timespec="seconds")
            save_auto_state(state)
            raise RuntimeError(
                f"SET опубликованы в trading_input, но применение к торговому MT5 не завершилось; "
                f"повтор назначен на {state['next_optimization_at']}: {exc}"
            ) from exc
        print(f"Новые настройки применены в торговом MT5: {applied} SET", flush=True)

        apply_complete, apply_missing = current_batch_application_status(trade_cfg)
        if not apply_complete:
            failed_at = datetime.now().astimezone()
            state = load_auto_state()
            retry_at = retry_apply_schedule(state, failed_at + timedelta(minutes=5))
            state["last_failed_optimization_at"] = failed_at.isoformat(timespec="seconds")
            save_auto_state(state)
            print(
                "Оптимизация завершена, но не все SET применены. "
                f"Ожидаются: {', '.join(apply_missing) if apply_missing else 'торговый MT5/подтверждение применения'}. "
                f"Повтор применения: {retry_at.isoformat(timespec='seconds')}",
                flush=True,
            )
            return
    else:
        state = load_auto_state()
        retry_at = retry_apply_schedule(state)
        state["last_failed_optimization_at"] = datetime.now().astimezone().isoformat(timespec="seconds")
        save_auto_state(state)
        print(
            "Торговый MT5 сейчас вне разрешённого окна; новые SET сохранены "
            "в trading_input. 14-дневный график НЕ зафиксирован; "
            f"повтор проверки применения: {retry_at.isoformat(timespec='seconds')}",
            flush=True,
        )
        return

    # Commit the next 14-day deadline only after every SET from the completed
    # optimization batch has actually been applied and marked -compl.
    state = load_auto_state()
    try:
        commit_schedule_after_application(
            state, cfg, Path(trade_cfg["trading_input"]) / "optimization_complete.json"
        )
    except Exception as exc:
        raise RuntimeError(f"Не удалось сохранить расписание следующей оптимизации: {exc}") from exc
    print(
        f"Следующая автоматическая оптимизация назначена на "
        f"{state['next_optimization_at']}",
        flush=True,
    )

    print("\nРабота завершена: все валюты оптимизированы успешно.", flush=True)


if __name__ == "__main__":
    main()
