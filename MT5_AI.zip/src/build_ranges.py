import json

from utils.project_paths import CONFIG_DIR
from utils.project_paths import TEMPLATES_DIR


SET_FILE = TEMPLATES_DIR / "base.set"

OUT_FILE = CONFIG_DIR / "optimization_ranges.json"


def convert(value):

    try:

        if "." in value:
            return float(value)

        return int(value)

    except:

        return value


ranges = {}

with open(SET_FILE, "r", encoding="utf-16") as f:

    for line in f:

        line = line.strip()

        if "=" not in line:
            continue

        if "||" not in line:
            continue

        name, values = line.split("=", 1)

        parts = values.split("||")

        if len(parts) < 5:
            continue

        ranges[name] = {

            "value": convert(parts[0]),
            "start": convert(parts[1]),
            "step": convert(parts[2]),
            "stop": convert(parts[3]),
            "enabled": parts[4]

        }

with open(OUT_FILE, "w", encoding="utf-8") as f:

    json.dump(
        ranges,
        f,
        indent=4,
        ensure_ascii=False
    )

print("optimization_ranges.json обновлен")