import json
from datetime import datetime
from pathlib import Path

import MetaTrader5 as mt5

PROJECT_ROOT = Path(__file__).resolve().parents[1]
TESTER_CONFIG = PROJECT_ROOT / "config" / "tester.json"


def sync_tester_deposit_from_test_mt5(test_terminal_path: str, allow_start: bool = False):
    """Read Balance/Currency from the TEST MT5 connected to the same account.

    The trading MT5 is deliberately never initialized or started here.
    The configured test terminal may be started by the MetaTrader5 API; that
    terminal is the isolated automation/test installation.
    """
    terminal = Path(test_terminal_path).resolve()
    expected_dir = terminal.parent

    if not allow_start:
        import psutil
        expected_exe = str(terminal).lower()
        running = False
        for proc in psutil.process_iter(["name", "exe"]):
            try:
                if str(proc.info.get("exe") or "").lower() == expected_exe:
                    running = True
                    break
            except Exception:
                pass
        if not running:
            raise RuntimeError(
                "Тестовый MT5 не запущен перед синхронизацией. "
                "Запуск через MetaTrader5.initialize() запрещён."
            )

    if not mt5.initialize(path=str(terminal)):
        raise RuntimeError(
            "Не удалось подключиться к тестовому MT5 для синхронизации депозита: "
            f"{mt5.last_error()}"
        )

    try:
        info = mt5.terminal_info()
        if info is None:
            raise RuntimeError(
                f"Не удалось получить terminal_info() тестового MT5: {mt5.last_error()}"
            )

        reported = getattr(info, "path", "") or ""
        actual_dir = Path(reported).resolve() if reported else None
        if actual_dir != expected_dir:
            raise RuntimeError(
                "MetaTrader5 подключился не к тестовому терминалу: "
                f"ожидалась папка {expected_dir}, получена {actual_dir}"
            )

        account = mt5.account_info()
        if account is None:
            raise RuntimeError(
                f"Не удалось получить account_info() тестового MT5: {mt5.last_error()}"
            )

        balance = float(account.balance)
        currency = str(account.currency or "").strip().upper()
        if balance <= 0:
            raise RuntimeError(f"Получен некорректный баланс: {balance}")
        if not currency:
            raise RuntimeError("Тестовый MT5 не вернул валюту счёта")
    finally:
        mt5.shutdown()

    if not TESTER_CONFIG.exists():
        raise FileNotFoundError(f"Не найден файл {TESTER_CONFIG}")

    data = json.loads(TESTER_CONFIG.read_text(encoding="utf-8"))
    old = (data.get("deposit"), data.get("currency"))
    data["deposit"] = balance
    data["currency"] = currency
    data["deposit_source"] = "test_mt5.account_info.balance_same_account"
    data["deposit_synced_at"] = datetime.now().astimezone().isoformat(timespec="seconds")
    TESTER_CONFIG.write_text(
        json.dumps(data, indent=4, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )

    check = json.loads(TESTER_CONFIG.read_text(encoding="utf-8"))
    if float(check["deposit"]) != balance or str(check["currency"]).upper() != currency:
        raise RuntimeError("Не удалось подтвердить запись актуального депозита в tester.json")

    return balance, currency, old


# Backward-compatible name for code that imports the helper directly.
def sync_tester_deposit(test_terminal_path: str):
    return sync_tester_deposit_from_test_mt5(test_terminal_path, allow_start=False)
