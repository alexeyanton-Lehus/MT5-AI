import json
from pathlib import Path


class PairManager:

    def __init__(self):

        with open(Path("config/pairs.json"), "r", encoding="utf-8") as f:
            self.pairs = json.load(f)

        with open(Path("config/optimization_list.json"), "r", encoding="utf-8") as f:
            self.optimization_list = json.load(f)

    def get_pairs(self):

        result = []

        for symbol in self.optimization_list:

            if symbol not in self.pairs:
                raise Exception(f"Пара '{symbol}' отсутствует в pairs.json")

            pair = self.pairs[symbol].copy()
            pair["symbol"] = symbol

            result.append(pair)

        return result

    def get_pair(self, symbol):

        if symbol not in self.pairs:
            raise Exception(f"Пара '{symbol}' отсутствует.")

        pair = self.pairs[symbol].copy()
        pair["symbol"] = symbol

        return pair

    def get_magic(self, symbol):
        return self.get_pair(symbol)["magic"]

    def get_max_spread(self, symbol):
        return self.get_pair(symbol)["max_spread"]

    def get_avg_spread(self, symbol):
        return self.get_pair(symbol)["avg_spread"]