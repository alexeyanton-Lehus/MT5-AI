import sqlite3
from pathlib import Path

DB = Path("database/mt5_ai.db")


def init_database():

    conn = sqlite3.connect(DB)
    cur = conn.cursor()

    cur.execute("""
    CREATE TABLE IF NOT EXISTS optimizations
    (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        optimization_id TEXT,

        symbol TEXT,
        timeframe TEXT,

        expert TEXT,

        test_from TEXT,
        test_to TEXT,

        deposit REAL,

        pf REAL,
        profit REAL,
        drawdown REAL,
        deposit_load REAL,
        trades INTEGER,

        created TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)

    conn.commit()
    conn.close()

    print("База данных готова.")
def save_results(results):

    conn = sqlite3.connect(DB)
    cur = conn.cursor()

    for row in results:

        cur.execute("""
        INSERT INTO optimizations
        (
            optimization_id,
            profit,
            pf,
            drawdown
        )
        VALUES (?, ?, ?, ?)
        """,
        (
            row.get("id"),
            row.get("Profit"),
            row.get("PF"),
            row.get("Drawdown")
        ))

    conn.commit()
    conn.close()

    print(f"Сохранено {len(results)} результатов.")