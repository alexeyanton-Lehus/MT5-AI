from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent

CONFIG_DIR = PROJECT_ROOT / "config"
DATABASE_DIR = PROJECT_ROOT / "database"

# Терминал MT5
MT5_DIR = Path(r"C:\MT5_AI\Ava Trade MT5 Terminal")

# Все отчёты MT5
REPORTS_DIR = MT5_DIR / "reports"
TESTER_DIR = MT5_DIR / "Tester"

RESULTS_DIR = PROJECT_ROOT / "results"
TEMPLATES_DIR = PROJECT_ROOT / "templates"
WORKING_DIR = PROJECT_ROOT / "working"
TEMP_DIR = PROJECT_ROOT / "temp"
SRC_DIR = PROJECT_ROOT / "src"
# Финальные SET-файлы советника
ADVISOR_SETTINGS_DIR = Path(r"C:\MT5_AI\sets_RSI+MA_adaptiv-V13")
# Финальные INI-файлы для ручного запуска Strategy Tester
TESTER_INI_SETTINGS_DIR = Path(r"C:\MT5_AI\ini_RSI+MA_adaptiv-V13")

# Temporary INI files generated for optimization runs. These are NOT final settings.
OPTIMIZATION_INI_DIR = WORKING_DIR / "optimization_ini"

# Постоянные финальные отчёты SINGLE TEST для анализа сделок
TRADE_REPORTS_DIR = Path(r"C:\MT5_AI\trade_reports")
