"""Shared optimization progress state used by the pipeline and dashboard."""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
STATUS_FILE = ROOT / "working" / "optimization_progress.json"


def _now():
    return datetime.now().astimezone().isoformat(timespec="seconds")


def update(**changes):
    STATUS_FILE.parent.mkdir(parents=True, exist_ok=True)
    data = {}
    if STATUS_FILE.exists():
        try:
            data = json.loads(STATUS_FILE.read_text(encoding="utf-8"))
        except Exception:
            data = {}
    data.update(changes)
    data["updated_at"] = _now()
    tmp = STATUS_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(STATUS_FILE)
    return data


def reset(expected_symbols):
    return update(
        status="RUNNING",
        started_at=_now(),
        completed_at=None,
        expected_symbols=list(expected_symbols),
        total_symbols=len(expected_symbols),
        completed_symbols=[],
        failed_symbols=[],
        current_symbol=None,
        current_symbol_index=0,
        current_stage=None,
        current_stage_number=0,
        total_stages=4,
        last_event="Цикл оптимизации запущен",
        last_error=None,
    )


def finish(complete, completed_symbols, failed_symbols, message):
    return update(
        status="COMPLETED" if complete else "COMPLETED_WITH_SKIPS",
        completed_at=_now(),
        completed_symbols=list(completed_symbols),
        failed_symbols=list(failed_symbols),
        current_symbol=None,
        current_stage=None,
        current_stage_number=0,
        last_event=message,
        last_error=None,
    )
