from pathlib import Path
from shutil import copyfile
from datetime import datetime

from config_loader import load_config, load_tester_config
from project_paths import TEMPLATES_DIR
from project_paths import WORKING_DIR


class IniBuilder:

    def __init__(self):

        self.cfg = load_config()

        self.tester_cfg = load_tester_config()

        self.template = (
            TEMPLATES_DIR / "base.ini"
        )

        self.output = (
            WORKING_DIR / "working.ini"
        )

        self.terminal_dir = Path(
            self.cfg["mt5_path"]
        ).parent

        WORKING_DIR.mkdir(
            parents=True,
            exist_ok=True
        )

    # =========================================================
    # REPORT PATH
    # =========================================================

    def _report_ini_path(
        self,
        symbol,
        report_name="optimization"
    ):

        report_dir = (
            self.terminal_dir
            / "reports"
            / symbol
        )

        report_dir.mkdir(
            parents=True,
            exist_ok=True
        )

        report_path = (
            report_dir / report_name
        )

        report_path.parent.mkdir(
            parents=True,
            exist_ok=True
        )

        relative = (
            report_path.relative_to(
                self.terminal_dir
            )
        )

        return str(
            relative
        ).replace(
            "/",
            "\\"
        )

    # =========================================================
    # BUILD
    # =========================================================

    def build(
        self,
        pair,
        deposit=None,
        currency=None,
        timeframe=None,
        from_date="2024.01.01",
        to_date=None,
        optimization=2,
        model=2,
        criterion=7,
        leverage=400,
        report_name="optimization",
        shutdown_terminal=0
    ):

        if timeframe is None:
            timeframe = self.tester_cfg.get(
                "period", self.cfg.get("timeframe", "H4")
            )

        if from_date == "2024.01.01":
            from_date = self.tester_cfg.get("from_date", from_date)

        if to_date is None:
            to_date = self.tester_cfg.get("to_date", "today")

        if str(to_date).lower() == "today":
            to_date = datetime.today().strftime("%Y.%m.%d")

        if deposit is None:
            deposit = self.tester_cfg["deposit"]

        if currency is None:
            currency = self.tester_cfg.get("currency", "PLN")

        leverage = self.tester_cfg.get("leverage", leverage) if leverage == 400 else leverage

        # =====================================================
        # COPY TEMPLATE
        # =====================================================

        copyfile(
            self.template,
            self.output
        )

        with open(
            self.output,
            "r",
            encoding="utf-16"
        ) as f:

            ini_lines = f.readlines()

        # =====================================================
        # WORKING.SET
        # =====================================================

        set_path = (
            WORKING_DIR
            / "working.set"
        )

        if not set_path.exists():

            raise RuntimeError(
                f"Нет файла {set_path}"
            )

        with open(
            set_path,
            "r",
            encoding="utf-16"
        ) as f:

            set_lines = f.readlines()

        # =====================================================
        # REPORT
        # =====================================================

        report = self._report_ini_path(
            pair["symbol"],
            report_name
        )

        print(
            "\nMT5 REPORT PATH:"
        )

        print(
            report
        )

        # =====================================================
        # FIND TESTER INPUTS
        # =====================================================

        tester_idx = None

        for i, line in enumerate(
            ini_lines
        ):

            if (
                line.strip()
                == "[TesterInputs]"
            ):

                tester_idx = i

                break

        if tester_idx is None:

            raise RuntimeError(
                "В base.ini отсутствует "
                "[TesterInputs]"
            )

        header = ini_lines[
            :tester_idx + 1
        ]

        # =====================================================
        # TESTER SETTINGS
        # =====================================================

        for i, line in enumerate(
            header
        ):

            if line.startswith(
                "Symbol="
            ):

                header[i] = (
                    f"Symbol="
                    f"{pair['symbol']}\n"
                )

            elif line.startswith(
                "Period="
            ):

                header[i] = (
                    f"Period="
                    f"{timeframe}\n"
                )

            elif line.startswith(
                "Optimization="
            ):

                header[i] = (
                    f"Optimization="
                    f"{optimization}\n"
                )

            elif line.startswith(
                "Model="
            ):

                header[i] = (
                    f"Model="
                    f"{model}\n"
                )

            elif line.startswith(
                "FromDate="
            ):

                header[i] = (
                    f"FromDate="
                    f"{from_date}\n"
                )

            elif line.startswith(
                "ToDate="
            ):

                header[i] = (
                    f"ToDate="
                    f"{to_date}\n"
                )

            elif line.startswith(
                "Deposit="
            ):

                header[i] = (
                    f"Deposit="
                    f"{deposit}\n"
                )

            elif line.startswith(
                "Currency="
            ):

                header[i] = (
                    f"Currency="
                    f"{currency}\n"
                )

            elif line.startswith(
                "OptimizationCriterion="
            ):

                header[i] = (
                    f"OptimizationCriterion="
                    f"{criterion}\n"
                )

            elif line.startswith(
                "Leverage="
            ):

                header[i] = (
                    f"Leverage="
                    f"{leverage}\n"
                )

            elif line.startswith(
                "Visual="
            ):

                header[i] = (
                    "Visual=0\n"
                )

            elif line.startswith(
                "Report="
            ):

                header[i] = (
                    f"Report="
                    f"{report}\n"
                )

            elif line.startswith(
                "ReplaceReport="
            ):

                header[i] = (
                    "ReplaceReport=1\n"
                )

            elif line.startswith(
                "ShutdownTerminal="
            ):

                header[i] = (
                    f"ShutdownTerminal={int(shutdown_terminal)}\n"
                )

        # =====================================================
        # ADD MISSING TESTER SETTINGS
        # =====================================================

        if not any(
            line.startswith("Report=")
            for line in header
        ):

            header.insert(
                -1,
                f"Report={report}\n"
            )

        if not any(
            line.startswith(
                "ReplaceReport="
            )
            for line in header
        ):

            header.insert(
                -1,
                "ReplaceReport=1\n"
            )

        if not any(
            line.startswith(
                "ShutdownTerminal="
            )
            for line in header
        ):

            header.insert(
                -1,
                f"ShutdownTerminal={int(shutdown_terminal)}\n"
            )

        # =====================================================
        # EA INPUTS
        # =====================================================

        body = []

        for line in set_lines:

            if (
                line.strip()
                == "[TesterInputs]"
            ):

                continue

            # -------------------------------------------------
            # TRADE SYMBOL
            # -------------------------------------------------

            if line.startswith(
                "TradeSymbol="
            ):

                line = (
                    f"TradeSymbol="
                    f"{pair['symbol']}\n"
                )

            # -------------------------------------------------
            # SYMBOL
            # -------------------------------------------------

            elif line.startswith(
                "Symbol="
            ):

                line = (
                    f"Symbol="
                    f"{pair['symbol']}\n"
                )

            # -------------------------------------------------
            # MAGIC
            # -------------------------------------------------

            elif line.startswith(
                "Magic="
            ):

                m = pair["magic"]

                line = (
                    f"Magic={m}||"
                    f"{m}||1||999999||N\n"
                )

            # -------------------------------------------------
            # MAX SPREAD
            # -------------------------------------------------

            elif line.startswith(
                "MaxSpread="
            ):

                s = pair["max_spread"]

                line = (
                    f"MaxSpread={s}||"
                    f"80||1||800||N\n"
                )

            if not line.endswith(
                "\n"
            ):

                line += "\n"

            body.append(
                line
            )

        # =====================================================
        # WRITE WORKING.INI
        # =====================================================

        with open(
            self.output,
            "w",
            encoding="utf-16"
        ) as f:

            f.writelines(
                header + body
            )

        # =====================================================
        # VERIFY PAIR-SPECIFIC EA INPUTS
        # =====================================================

        expected_pair_inputs = {
            "TradeSymbol": str(pair["symbol"]),
            "MaxSpread": str(pair["max_spread"]),
            "Magic": str(pair["magic"]),
        }

        actual_pair_inputs = {}
        with open(self.output, "r", encoding="utf-16") as f:
            for raw_line in f:
                line = raw_line.rstrip("\r\n")
                for name in expected_pair_inputs:
                    if line.startswith(name + "="):
                        actual_pair_inputs[name] = line.split("=", 1)[1].split("||", 1)[0]
                        break

        mismatches = {
            name: (actual_pair_inputs.get(name), expected)
            for name, expected in expected_pair_inputs.items()
            if actual_pair_inputs.get(name) != expected
        }
        if mismatches:
            raise RuntimeError(
                f"INI pair synchronization failed for {pair['symbol']}: {mismatches}"
            )

        print(
            f"INI PAIR SYNC OK: {pair['symbol']} | "
            f"TradeSymbol={actual_pair_inputs['TradeSymbol']} | "
            f"MaxSpread={actual_pair_inputs['MaxSpread']} | "
            f"Magic={actual_pair_inputs['Magic']}"
        )

        # =====================================================
        # DEBUG
        # =====================================================

        print(
            "\n========== WORKING.INI ==========\n"
        )

        with open(
            self.output,
            "r",
            encoding="utf-16"
        ) as f:

            print(
                f.read()
            )

        print(
            "\n=================================\n"
        )

        return self.output

    # =========================================================
    # SINGLE TEST
    # =========================================================

    def build_single_test(
        self,
        pair,
        pass_number,
        deposit=None,
        currency=None,
        timeframe=None,
        from_date="2024.01.01",
        to_date=None,
        leverage=400
    ):

        # =====================================================
        # NORMALIZE PASS
        # =====================================================

        pass_number = int(
            float(
                pass_number
            )
        )

        # =====================================================
        # UNIQUE SINGLE TEST REPORT
        #
        # MT5:
        #
        # reports/<symbol>/tests/
        #
        # SINGLE_EURUSD_Pass_4500.htm
        # =====================================================

        symbol = pair["symbol"]

        report_name = (
            f"tests\\SINGLE_"
            f"{symbol}_"
            f"Pass_{pass_number}"
        )

        print(
            "\nSINGLE TEST REPORT:"
        )

        print(
            report_name
        )

        # =====================================================
        # BUILD SINGLE TEST INI
        # =====================================================

        return self.build(
            pair=pair,
            deposit=deposit,
            currency=currency,
            timeframe=timeframe,
            from_date=from_date,
            to_date=to_date,
            optimization=0,
            model=2,
            criterion=7,
            leverage=leverage,
            report_name=report_name,
            shutdown_terminal=1
        )