import os
import subprocess
import time
import re

import MetaTrader5 as mt5
import psutil

from config_loader import load_config


class MT5Connector:
    """Connector for the automation MT5 instance only."""

    def __init__(self):
        cfg = load_config()
        self.terminal_path = os.path.abspath(cfg["mt5_path"])
        self.process = None
        self.pid = None
        self.automation_config = None

    def connect(self):
        return mt5.initialize(path=self.terminal_path)

    def disconnect(self):
        mt5.shutdown()

    @staticmethod
    def _normalize_path(value):
        if not value:
            return ""
        return os.path.normcase(os.path.abspath(str(value))).replace("/", "\\")

    def _process_executable_matches(self, proc):
        """Return True when proc is the configured MT5 terminal executable."""
        try:
            name = proc.info.get("name", "") or ""
            if name.lower() != os.path.basename(self.terminal_path).lower():
                return False

            exe = proc.info.get("exe") or ""
            if exe:
                return self._normalize_path(exe).lower() == self._normalize_path(self.terminal_path).lower()

            # Some Windows processes may hide exe information. In that case
            # the executable name is still a useful fallback.
            return True
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            return False
        except Exception:
            return False

    def _process_has_automation_config(self, proc):
        """Return True only for an MT5 process started with our /config file."""
        if not self.automation_config:
            return False
        try:
            cfg = self._normalize_path(self.automation_config).lower()
            cmdline = " ".join(str(x) for x in (proc.info.get("cmdline") or []))
            return cfg in cmdline.lower()
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            return False
        except Exception:
            return False

    def _process_matches_automation(self, proc):
        try:
            if not self._process_executable_matches(proc):
                return False

            # After launch, the exact PID selected by execute_config() is the
            # identity of the automation terminal. Do not require /config to
            # remain visible in the command line: MT5 can consume /config and
            # then expose a command line without it.
            if self.pid and proc.pid == self.pid:
                return True

            # Before a PID is known, only an explicit /config match can identify
            # an old automation instance. Never adopt an arbitrary terminal.
            return self._process_has_automation_config(proc)
        except Exception:
            return False

    def _find_automation_processes(self):
        result = []
        for proc in psutil.process_iter(["pid", "name", "cmdline", "exe"]):
            try:
                if self._process_matches_automation(proc):
                    result.append(proc)
            except Exception:
                pass
        return result

    def _find_terminal_processes(self):
        """Find every MT5 terminal process for this installation."""
        result = []
        for proc in psutil.process_iter(["pid", "name", "cmdline", "exe"]):
            try:
                if self._process_executable_matches(proc):
                    result.append(proc)
            except Exception:
                pass
        return result

    def _find_automation_pid(self):
        # Once the automation PID is known, never replace it with another MT5
        # process. This is critical when a manual trading terminal is open.
        if self.pid:
            try:
                proc = psutil.Process(self.pid)
                if self._process_executable_matches(proc) and proc.is_running():
                    return self.pid
            except Exception:
                pass

        processes = self._find_automation_processes()
        if not processes:
            return None

        # Only an explicit /config match is safe before launch PID binding.
        if self.automation_config:
            cfg = self._normalize_path(self.automation_config).lower()
            for proc in processes:
                try:
                    cmdline = " ".join(str(x) for x in (proc.info.get("cmdline") or []))
                    if cfg in cmdline.lower():
                        return proc.pid
                except Exception:
                    pass
        return None

    def _terminal_pid_snapshot(self):
        return {proc.pid for proc in self._find_terminal_processes()}

    def _find_new_terminal_pid(self, old_pids, launched_pid, launched_at):
        """Find the MT5 process created by this launch, without using /config.

        MT5 may consume /config and spawn/replace its terminal process. The
        original Popen PID therefore is not always the final terminal PID.
        Existing PIDs are excluded so a manual trading terminal can never be
        adopted.
        """
        candidates = []
        for proc in self._find_terminal_processes():
            if proc.pid in old_pids:
                continue
            try:
                if proc.pid == launched_pid or proc.create_time() >= launched_at - 1.0:
                    candidates.append(proc)
            except Exception:
                continue

        if not candidates:
            return None

        candidates.sort(key=lambda x: getattr(x, 'pid', 0), reverse=True)
        return candidates[0].pid

    @staticmethod
    def _is_chart_title(title):
        if not title:
            return False
        return bool(
            re.match(
                r"^[A-Z0-9_]{3,20},"
                r"(M1|M2|M3|M4|M5|M6|M10|M12|M15|M20|M30|H1|H2|H3|H4|H6|H8|H12|D1|W1|MN1)$",
                str(title).strip(),
                re.IGNORECASE,
            )
        )

    def _close_chart_windows(self):
        """Close chart MDI children of this exact automation terminal PID."""
        if not self.pid:
            return
        try:
            import win32gui
            import win32con
            import win32process
        except Exception:
            return

        def owned(hwnd):
            try:
                return (
                    win32gui.IsWindow(hwnd)
                    and win32process.GetWindowThreadProcessId(hwnd)[1] == self.pid
                )
            except Exception:
                return False

        def descendants(root):
            out = []
            try:
                win32gui.EnumChildWindows(root, lambda h, _: out.append(h), None)
            except Exception:
                pass
            return out

        def collect():
            found = []
            tops = []
            try:
                win32gui.EnumWindows(lambda h, _: tops.append(h), None)
            except Exception:
                return found

            for top in tops:
                if not owned(top):
                    continue
                for node in [top] + descendants(top):
                    try:
                        if not owned(node) or win32gui.GetClassName(node).lower() != "mdiclient":
                            continue
                        for child in descendants(node):
                            if not owned(child):
                                continue
                            title = str(win32gui.GetWindowText(child) or "").strip()
                            if self._is_chart_title(title):
                                found.append(child)
                    except Exception:
                        pass

                try:
                    title = str(win32gui.GetWindowText(top) or "").strip()
                    if self._is_chart_title(title):
                        found.append(top)
                except Exception:
                    pass

            return list(dict.fromkeys(found))

        for _ in range(20):
            charts = collect()
            if not charts:
                break
            sent = 0
            for hwnd in charts:
                try:
                    if win32gui.IsWindow(hwnd):
                        win32gui.PostMessage(hwnd, win32con.WM_CLOSE, 0, 0)
                        sent += 1
                except Exception:
                    pass
            time.sleep(0.15)
            if sent == 0:
                break

    def _terminate_automation_only(self):
        # Close chart tabs first so the MT5 profile is not left with a growing
        # number of restored charts on the next launch.
        self._close_chart_windows()

        processes = self._find_automation_processes()

        if self.process is not None:
            try:
                if self.process.poll() is None and all(p.pid != self.process.pid for p in processes):
                    try:
                        processes.append(psutil.Process(self.process.pid))
                    except Exception:
                        pass
            except Exception:
                pass

        for proc in processes:
            try:
                proc.terminate()
            except Exception:
                pass

        deadline = time.time() + 10
        while time.time() < deadline:
            alive = []
            for proc in processes:
                try:
                    if proc.is_running():
                        alive.append(proc)
                except Exception:
                    pass
            if not alive:
                break
            time.sleep(0.25)

        for proc in processes:
            try:
                if proc.is_running():
                    proc.kill()
            except Exception:
                pass

        self.process = None
        self.pid = None
        self.automation_config = None

    def ensure_clean_start(self):
        """Prepare a clean automation start without touching a manual MT5.

        A terminal.exe process for the same installation is classified as:
        - automation: command line contains the configured /config file;
        - manual: no automation /config is present.

        Manual MT5 must never be terminated or silently coexist with an
        automation launch, because MT5 may reject/ignore the second launch.
        """
        print("\n===== CHECK MT5 BEFORE RUN =====")

        # At this point automation_config is normally set only for a process
        # we are about to control. Existing processes from a previous Python
        # run therefore have to be inspected by their command line, not by
        # self.pid/self.automation_config.
        terminals = self._find_terminal_processes()
        automation_cfg = None
        cfg_path = self._normalize_path(
            self.automation_config or ""
        ).lower()

        if cfg_path:
            for proc in terminals:
                try:
                    # A terminal launched by this connector may no longer show
                    # /config in its command line after MT5 consumes the INI.
                    # When execute_config() already bound the previous terminal
                    # PID, that PID is authoritative for this connector.
                    if self.pid and proc.pid == self.pid:
                        automation_cfg = proc
                        break

                    cmdline = " ".join(str(x) for x in (proc.info.get("cmdline") or []))
                    if cfg_path in cmdline.lower():
                        automation_cfg = proc
                        break
                except Exception:
                    pass

        if automation_cfg is not None:
            print(
                f"Найден старый автоматический MT5 (PID={automation_cfg.pid}). "
                "Останавливаю только его..."
            )
            self._terminate_automation_only()
            terminals = self._find_terminal_processes()

        # Any remaining terminal for this installation is manual. Do not
        # start a second instance and do not terminate the user's terminal.
        manual = []
        for proc in terminals:
            if automation_cfg is not None and proc.pid == automation_cfg.pid:
                continue
            manual.append(proc)

        if manual:
            pids = ", ".join(str(proc.pid) for proc in manual)
            raise RuntimeError(
                "MT5 уже запущен вручную (PID=" + pids + "). "
                "Автоматическая оптимизация НЕ запущена. "
                "Закройте вручную запущенный MT5 и повторите запуск."
            )

        print("MT5 не запущен. Можно запускать автоматический экземпляр.")

    @staticmethod
    def _startupinfo_minimized():
        """Request a minimized MT5 window at process creation time."""
        if os.name != "nt":
            return None
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = 7  # SW_SHOWMINNOACTIVE
        return si

    def _force_minimize_terminal_window(self, retries=25, delay=0.1):
        """Force only this automation MT5 process window to be minimized.

        Uses ctypes instead of pywin32, so the result does not depend on an
        optional Python package being installed. MT5 can restore its saved
        maximized layout after startup, therefore SW_FORCEMINIMIZE is applied
        repeatedly while the main window is being created.
        """
        if os.name != "nt" or not self.pid:
            return False

        try:
            import ctypes
            from ctypes import wintypes

            user32 = ctypes.windll.user32
            kernel32 = ctypes.windll.kernel32

            EnumWindowsProc = ctypes.WINFUNCTYPE(
                wintypes.BOOL, wintypes.HWND, wintypes.LPARAM
            )

            SW_FORCEMINIMIZE = 11
            SW_MINIMIZE = 6

            found = False
            for _ in range(retries):
                hwnds = []

                def callback(hwnd, lparam):
                    pid = wintypes.DWORD()
                    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
                    if pid.value == self.pid and user32.IsWindowVisible(hwnd):
                        hwnds.append(hwnd)
                    return True

                user32.EnumWindows(EnumWindowsProc(callback), 0)

                if hwnds:
                    found = True
                    all_minimized = True
                    for hwnd in hwnds:
                        user32.ShowWindow(hwnd, SW_FORCEMINIMIZE)
                        if user32.IsIconic(hwnd) == 0:
                            user32.ShowWindow(hwnd, SW_MINIMIZE)
                        if user32.IsIconic(hwnd) == 0:
                            all_minimized = False
                    if all_minimized:
                        return True

                time.sleep(delay)

            return found
        except Exception:
            return False

    def start_terminal(self):
        """Start the TEST MT5 under this connector's ownership, minimized.

        This method is intentionally used before account synchronization. It
        prevents MetaTrader5.initialize() from becoming the process that
        launches the terminal, because the API-launched window can restore the
        terminal's saved maximized state.
        """
        self.automation_config = None
        self.ensure_clean_start()
        terminal_dir = os.path.dirname(self.terminal_path)
        old_pids = self._terminal_pid_snapshot()
        launched_at = time.time()

        self.process = subprocess.Popen(
            [self.terminal_path],
            cwd=terminal_dir,
            startupinfo=self._startupinfo_minimized(),
        )
        launched_pid = self.process.pid
        self.pid = launched_pid

        deadline = time.time() + 15.0
        actual_pid = None
        while time.time() < deadline:
            actual_pid = self._find_new_terminal_pid(old_pids, launched_pid, launched_at)
            if actual_pid is not None:
                self.pid = actual_pid
                break
            time.sleep(0.2)

        if actual_pid is None:
            try:
                if self.process.poll() is None:
                    self.process.terminate()
            except Exception:
                pass
            self.process = None
            self.pid = None
            raise RuntimeError(
                "Тестовый MT5 не подтвердил запуск: новый процесс terminal64.exe не найден."
            )

        # Minimize the actual terminal PID, not merely the launcher PID.
        self._force_minimize_terminal_window(retries=50, delay=0.1)
        print("Тестовый MT5 запущен и свернут. PID =", self.pid, flush=True)

    def execute_config(self, ini_file):
        ini_file = os.path.abspath(ini_file)
        if not os.path.exists(ini_file):
            raise FileNotFoundError(f"INI не найден: {ini_file}")

        self.automation_config = ini_file
        self.ensure_clean_start()

        terminal_dir = os.path.dirname(self.terminal_path)
        old_pids = self._terminal_pid_snapshot()
        launched_at = time.time()

        print("\n========== START MT5 ==========")
        print("terminal =", self.terminal_path)
        print("config   =", ini_file)
        print("exists   =", os.path.exists(ini_file))
        print("==============================\n")

        with open(ini_file, "r", encoding="utf-16") as f:
            for line in f:
                if line.startswith("Optimization="):
                    value = line.split("=", 1)[1].strip()
                    print(f"Optimization={value}")
                    if value == "0":
                        print("Режим MT5: одиночный тест (Optimization=0)")
                    elif value == "2":
                        print("Режим MT5: генетическая оптимизация (Optimization=2)")
                    else:
                        print(f"Режим MT5: Optimization={value}")
                    break

        try:
            self.process = subprocess.Popen(
                [self.terminal_path, f"/config:{ini_file}"],
                cwd=terminal_dir,
                startupinfo=self._startupinfo_minimized(),
            )
            launched_pid = self.process.pid
            self.pid = launched_pid

            # Minimize the process created by this launch immediately.
            self._force_minimize_terminal_window(retries=20, delay=0.1)

            # Bind automation identity to a PID created by THIS launch. The
            # /config argument is used for startup, not as a permanent process
            # identity because MT5 may consume it.
            deadline = time.time() + 15.0
            actual_pid = None
            while time.time() < deadline:
                actual_pid = self._find_new_terminal_pid(
                    old_pids, launched_pid, launched_at
                )
                if actual_pid is not None:
                    self.pid = actual_pid
                    break

                try:
                    if self.process.poll() is not None:
                        # The launcher exited; give MT5 a short opportunity to
                        # leave behind its real terminal process.
                        time.sleep(0.2)
                except Exception:
                    pass
                time.sleep(0.2)

            if actual_pid is None:
                raise RuntimeError(
                    "MT5 не подтвердил запуск автоматического экземпляра. "
                    "Новый процесс MT5 с момента запуска не найден; ручной MT5 "
                    "не был принят за автоматический."
                )

            self._force_minimize_terminal_window(retries=20, delay=0.1)
            print("Автоматический MT5 подтверждён. PID =", self.pid)

        except Exception:
            # Kill only the process created by this launch or a newly created
            # MT5 process. Never terminate any PID that existed before launch.
            try:
                if self.process is not None and self.process.poll() is None:
                    self.process.terminate()
            except Exception:
                pass

            for proc in self._find_terminal_processes():
                try:
                    if proc.pid not in old_pids:
                        proc.kill()
                except Exception:
                    pass

            self.process = None
            self.pid = None
            self.automation_config = None
            raise

    def is_running(self):
        # Never use self.process.poll() as proof of an automation MT5. The
        # child process can remain alive even when MT5 rejected/ignored the
        # config command. Only the matching /config process is authoritative.
        pid = self._find_automation_pid()
        if pid:
            self.pid = pid
            return True
        return False


    def wait_terminal(self):
        if self.process is None:
            return
        try:
            self.process.wait()
        finally:
            self.process = None
            self.pid = None

    def stop_terminal(self):
        print("Остановка автоматического MT5...")
        self._terminate_automation_only()
        print("Автоматический MT5 остановлен")
