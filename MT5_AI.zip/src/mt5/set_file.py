from pathlib import Path


class SetFile:

    def __init__(self, filename):

        self.filename = Path(filename)

        with open(self.filename, "r", encoding="utf-16") as f:
            self.lines = f.readlines()

    def set_value(self, variable, value):

        for i, line in enumerate(self.lines):
            if line.startswith(variable + "="):
                self.lines[i] = f"{variable}={value}\n"
                return

        raise Exception(f"Переменная {variable} не найдена")

    def set_optimizer(self, variable, value, start, step, stop, enabled):

        flag = "Y" if enabled else "N"

        def fmt(x):
            try:
                x = float(x)
            except (TypeError, ValueError):
                return str(x)

            if x.is_integer():
                return str(int(x))

            return f"{x:.6f}"

        text = (
            f"{variable}="
            f"{fmt(value)}||{fmt(start)}||{fmt(step)}||{fmt(stop)}||{flag}\n"
        )

        for i, line in enumerate(self.lines):
            if line.startswith(variable + "="):
                self.lines[i] = text
                return

        raise Exception(f"{variable} не найден")

    def set_trade_direction(self, direction):

        modes = {
            "BUY_ONLY": 0,
            "SELL_ONLY": 1,
            "BOTH": 2
        }

        if direction not in modes:
            raise Exception(f"Неизвестное направление торговли: {direction}")

        value = modes[direction]

        for i, line in enumerate(self.lines):
            if line.startswith("TradeDirection="):
                self.lines[i] = (
                    f"TradeDirection={value}"
                    f"||0||0||2||N\n"
                )
                return

        raise Exception("TradeDirection не найден")

    def save(self):

        with open(self.filename, "w", encoding="utf-16") as f:
            f.writelines(self.lines)