import re
import time
from pathlib import Path

from pywinauto import Desktop


class JournalMonitor:
    """Monitor MT5 tester state without depending on the active MT5 tab.

    The Strategy Tester journal is the primary completion signal. The visible
    "Stop" button is only a UI element and disappears when the user changes
    tabs, so it cannot be used as the authoritative optimization state.
    """

    COMPLETION_PATTERNS = (
        re.compile(r"genetic\s+optimization\s+finished", re.IGNORECASE),
        re.compile(r"genetic\s+calculation\s+is\s+over", re.IGNORECASE),
        re.compile(r"optimization\s+done\s+in\s+", re.IGNORECASE),
        re.compile(r"optimization\s+finished", re.IGNORECASE),
        re.compile(r"оптимизац(?:ия|ии)\s+(?:завершена|завершено|закончена)", re.IGNORECASE),
    )

    def __init__(self, pid, terminal_dir=None):
        self.pid = pid
        self.window = None
        self.terminal_dir = Path(terminal_dir) if terminal_dir else None
        self._log_offsets = {}
        self._tracking_started = False

    def connect(self, timeout=None):
        deadline = None if timeout is None else time.time() + timeout

        while True:
            try:
                windows = Desktop(backend="uia").windows()

                for w in windows:
                    try:
                        if w.process_id() != self.pid:
                            continue

                        self.window = w

                        print("\n===== MT5 CONNECTED =====")
                        print("PID   :", self.pid)
                        print("TITLE :", w.window_text())
                        print()

                        return

                    except Exception:
                        pass

            except Exception:
                pass

            if deadline is not None and time.time() >= deadline:
                raise TimeoutError(
                    f"Не удалось подключиться к окну MT5 за {timeout} сек."
                )

            time.sleep(1)

    def dump_elements(self):
        print("\n===== ELEMENTS =====\n")
        elements = self.window.descendants()
        print("Всего элементов:", len(elements))
        print()

        for i, e in enumerate(elements):
            try:
                print(
                    f"{i:04d} | "
                    f"{e.element_info.control_type:<15} | "
                    f"'{e.window_text()}'"
                )
            except Exception:
                pass

        print("\n===== END =====\n")

    @staticmethod
    def _is_chart_title(title):
        if not title:
            return False

        title = str(title).strip()
        return bool(
            re.match(
                r"^[A-Z0-9_]{3,20},"
                r"(M1|M2|M3|M4|M5|M6|M10|M12|M15|M20|M30|H1|H2|H3|H4|H6|H8|H12|D1|W1|MN1)$",
                title,
                re.IGNORECASE,
            )
        )

    def _chart_handles_win32(self):
        """Return chart HWNDs belonging only to the automation MT5 PID."""
        try:
            import win32gui
            import win32process
        except Exception:
            return []

        handles = []

        def inspect(hwnd):
            try:
                if not win32gui.IsWindow(hwnd):
                    return
                _, pid = win32process.GetWindowThreadProcessId(hwnd)
                if pid != self.pid:
                    return
                title = win32gui.GetWindowText(hwnd)
                if self._is_chart_title(title):
                    handles.append((hwnd, title))
            except Exception:
                pass

        try:
            win32gui.EnumWindows(inspect, None)
        except Exception:
            pass

        # MDI chart documents are often child HWNDs rather than top-level
        # windows, so enumerate every child of every top-level window too.
        top_level = []
        try:
            def collect(hwnd):
                try:
                    _, pid = win32process.GetWindowThreadProcessId(hwnd)
                    if pid == self.pid:
                        top_level.append(hwnd)
                except Exception:
                    pass
            win32gui.EnumWindows(collect, None)
        except Exception:
            pass

        for parent in top_level:
            try:
                win32gui.EnumChildWindows(parent, inspect, None)
            except Exception:
                pass

        # Deduplicate HWNDs.
        unique = {}
        for hwnd, title in handles:
            unique[hwnd] = title
        return list(unique.items())

    def _remaining_chart_titles(self):
        return [title for _, title in self._chart_handles_win32()]

    def close_all_windows(self, verbose=True):
        """Close chart MDI documents belonging only to this automation PID.

        MT5 chart tabs are MDI child windows.  In practice WM_MDICLOSE sent
        to the MDI client is not reliable here: MT5 can keep the child alive
        and restore it on the next test.  Close the actual chart child with
        WM_CLOSE instead.  The PID guard prevents touching the user's manual
        trading terminal.
        """
        if verbose:
            print("\n===== CLOSE WINDOWS =====\n")

        if not self.pid:
            if verbose:
                print("Нет PID автоматического MT5 — закрывать нечего.")
                print("\n===== WINDOWS CLOSED =====\n")
            return

        try:
            import win32gui
            import win32con
            import win32process
        except Exception as exc:
            if verbose:
                print("Win32 API недоступен:", exc)
                print("\n===== WINDOWS CLOSED =====\n")
            return

        def owned(hwnd):
            try:
                return (
                    win32gui.IsWindow(hwnd)
                    and win32process.GetWindowThreadProcessId(hwnd)[1] == self.pid
                )
            except Exception:
                return False

        def descendants(root):
            result = []
            try:
                win32gui.EnumChildWindows(root, lambda h, _: result.append(h), None)
            except Exception:
                pass
            return result

        def collect_chart_windows():
            found = []
            tops = []
            try:
                win32gui.EnumWindows(lambda h, _: tops.append(h), None)
            except Exception:
                return found

            for top in tops:
                if not owned(top):
                    continue

                # Standard MT5 MDI layout: top-level terminal -> MDIClient
                # -> chart MDI children.  Search all descendants because the
                # exact wrapper classes differ between MT5 builds.
                nodes = [top] + descendants(top)
                for node in nodes:
                    try:
                        if not owned(node):
                            continue
                        if win32gui.GetClassName(node).lower() != "mdiclient":
                            continue

                        for child in descendants(node):
                            if not owned(child):
                                continue
                            title = str(win32gui.GetWindowText(child) or "").strip()
                            if self._is_chart_title(title):
                                found.append(child)
                    except Exception:
                        pass

                # Detached chart windows, if any.
                try:
                    title = str(win32gui.GetWindowText(top) or "").strip()
                    if self._is_chart_title(title):
                        found.append(top)
                except Exception:
                    pass

            return list(dict.fromkeys(found))

        closed = 0
        # A test/optimization can create a chart while MT5 is switching the
        # active document. Repeat until the exact PID has no chart children.
        for _ in range(20):
            charts = collect_chart_windows()
            if not charts:
                break

            sent = 0
            for hwnd in charts:
                try:
                    if not win32gui.IsWindow(hwnd):
                        continue
                    # WM_CLOSE is sent to the actual MDI child, not to the
                    # MDIClient. This is the critical difference from the
                    # previous implementation, which reported 99 charts but
                    # closed 0.
                    win32gui.PostMessage(hwnd, win32con.WM_CLOSE, 0, 0)
                    sent += 1
                except Exception:
                    pass

            closed += sent
            time.sleep(0.15)
            if sent == 0:
                break

        remaining = collect_chart_windows()
        if verbose:
            print("Графиков закрыто:", closed)
            print("Осталось графиков:", len(remaining))
            if remaining:
                titles = []
                for hwnd in remaining[:20]:
                    try:
                        titles.append(str(win32gui.GetWindowText(hwnd) or "").strip())
                    except Exception:
                        pass
                if titles:
                    print("Не закрыты:", ", ".join(titles))
            print("\n===== WINDOWS CLOSED =====\n")

    # ------------------------------------------------------------------
    # MT5 tester journal monitoring
    # ------------------------------------------------------------------

    def _log_directories(self):
        if self.terminal_dir is None:
            return []

        root = self.terminal_dir
        return [
            root / "Tester" / "logs",
            root / "logs",
            root / "MQL5" / "Tester" / "logs",
            root / "MQL5" / "Logs",
        ]

    def _candidate_log_files(self):
        files = []
        seen = set()

        for directory in self._log_directories():
            try:
                if not directory.exists():
                    continue
                for path in directory.glob("*.log"):
                    try:
                        resolved = path.resolve()
                    except Exception:
                        resolved = path
                    if resolved in seen:
                        continue
                    seen.add(resolved)
                    files.append(path)
            except Exception:
                pass

        files.sort(
            key=lambda p: p.stat().st_mtime if p.exists() else 0,
            reverse=True,
        )
        return files

    def prepare_optimization_tracking(self):
        """Record log offsets before MT5 is launched.

        This prevents an old completion message in an existing log from being
        mistaken for the current optimization. New log files are tracked from
        byte 0 automatically.
        """
        self._log_offsets = {}
        for path in self._candidate_log_files():
            try:
                self._log_offsets[str(path)] = path.stat().st_size
            except OSError:
                pass
        self._tracking_started = True

        if self.terminal_dir is not None:
            print(
                "JOURNAL TRACKING: "
                f"найдено логов={len(self._log_offsets)}"
            )

    @staticmethod
    def _decode_log(raw):
        if not raw:
            return ""

        for encoding in ("utf-16", "utf-8-sig", "cp1251", "utf-8"):
            try:
                return raw.decode(encoding)
            except (UnicodeDecodeError, LookupError):
                continue

        return raw.decode("latin-1", errors="replace")

    def _read_new_log_text(self):
        if self.terminal_dir is None:
            return ""

        chunks = []
        current_files = self._candidate_log_files()

        for path in current_files:
            key = str(path)
            try:
                size = path.stat().st_size
            except OSError:
                continue

            offset = self._log_offsets.get(key, 0)
            if size < offset:
                # Log was rotated/truncated. Read the new file from the start.
                offset = 0

            if size <= offset:
                self._log_offsets[key] = size
                continue

            try:
                with open(path, "rb") as f:
                    f.seek(offset)
                    raw = f.read()
                self._log_offsets[key] = size
                if raw:
                    chunks.append(self._decode_log(raw))
            except (OSError, IOError):
                pass

        return "\n".join(chunks)

    @classmethod
    def _find_completion_signal(cls, text):
        if not text:
            return None

        for pattern in cls.COMPLETION_PATTERNS:
            match = pattern.search(text)
            if match:
                return match.group(0)
        return None

    def _wait_completion_from_journal(self, timeout):
        deadline = None if timeout is None else time.time() + timeout
        last_log_notice = 0.0
        last_chart_cleanup = 0.0

        while True:
            now = time.time()

            # MT5 can create/restore a chart tab while optimization is still
            # running. Do NOT wait until the end of the optimization: with a
            # large genetic run this can leave hundreds of MDI chart tabs.
            # Clean only charts belonging to this exact automation PID.
            if now - last_chart_cleanup >= 1.0:
                self.close_all_windows(verbose=False)
                last_chart_cleanup = now

            text = self._read_new_log_text()
            signal = self._find_completion_signal(text)
            if signal:
                # One final sweep catches tabs created between the last poll
                # and the completion message.
                self.close_all_windows(verbose=False)
                print(
                    "\n===== MT5 OPTIMIZATION FINISHED =====\n"
                    f"Источник: Tester journal\n"
                    f"Сигнал: {signal}\n"
                )
                return True

            if now - last_log_notice >= 10:
                files = self._candidate_log_files()
                print(
                    f"Оптимизация идет... | Tester logs: {len(files)}",
                    end="\r",
                    flush=True,
                )
                last_log_notice = now

            if deadline is not None and now >= deadline:
                raise TimeoutError(
                    f"Не найдено реальное завершение оптимизации в Tester journal "
                    f"за {timeout} сек."
                )

            time.sleep(0.5)

    def _wait_completion_from_ui(self, timeout):
        """Fallback for MT5 installations where Tester journal is unavailable.

        Unlike the old implementation, the fallback first requires observing
        the Stop button for the current run. Therefore a tab switch immediately
        after startup cannot be interpreted as completion.
        """
        if self.window is None:
            raise RuntimeError("MT5 window не подключено.")

        deadline = None if timeout is None else time.time() + timeout
        seen_running = False

        while True:
            stop_found = False
            try:
                for ctrl in self.window.descendants(control_type="Button"):
                    try:
                        button_text = str(ctrl.window_text() or "").strip().casefold()
                        if button_text in {"зупинити", "остановить", "stop"}:
                            stop_found = True
                            break
                    except Exception:
                        pass
            except Exception:
                pass

            if stop_found:
                seen_running = True
                print("Оптимизация идет...", end="\r", flush=True)
            elif seen_running:
                print("\nОптимизация завершена по UI.\n")
                return True

            if deadline is not None and time.time() >= deadline:
                raise TimeoutError(
                    f"Оптимизация не завершилась за {timeout} сек."
                )

            time.sleep(1)

    SINGLE_TEST_COMPLETION_PATTERNS = (
        re.compile(r"total\s+time\s+from\s+login\s+to\s+stop\s+testing", re.IGNORECASE),
        re.compile(r"quality\s+of\s+analyzed\s+history\s+is", re.IGNORECASE),
        re.compile(r"test\s+passed\s+in", re.IGNORECASE),
    )

    @classmethod
    def _find_single_test_completion_signal(cls, text):
        if not text:
            return None

        for pattern in cls.SINGLE_TEST_COMPLETION_PATTERNS:
            match = pattern.search(text)
            if match:
                return match.group(0)
        return None

    def _backtest_tab_present(self):
        """Return True when MT5 has created the Strategy Tester "Back-test" tab.

        This tab exists only after a single test has finished in the current
        MT5 instance. It is therefore used only as a delayed fallback signal
        when the Tester journal completion message was not detected.
        """
        if self.window is None:
            return False

        target_texts = {
            "бек-тест",
            "бек тест",
            "back-test",
            "back test",
            "backtest",
        }

        try:
            for ctrl in self.window.descendants():
                try:
                    text = str(ctrl.window_text() or "").strip().casefold()
                    if text in target_texts:
                        return True
                except Exception:
                    pass
        except Exception:
            pass

        return False

    def wait_single_test_finished(self, timeout=60):
        """Wait for completion of a single MT5 test using the Tester journal.

        This is intentionally separate from optimization completion detection.
        A single test does not emit the genetic-optimization messages used by
        wait_optimization_finished(), so using that method here could wait
        forever after MT5 had already finished the test.
        """
        print("\n===== WAIT SINGLE TEST =====\n")

        if self.terminal_dir is None:
            return self._wait_completion_from_ui(timeout)

        if not self._tracking_started:
            self.prepare_optimization_tracking()

        deadline = time.time() + timeout if timeout is not None else None
        fallback_after = time.time() + 10.0
        next_fallback_check = fallback_after

        while True:
            text = self._read_new_log_text()
            signal = self._find_single_test_completion_signal(text)
            if signal:
                print(
                    "\n===== MT5 SINGLE TEST FINISHED =====\n"
                    "Источник: Tester journal\n"
                    f"Сигнал: {signal}\n"
                )
                return True

            now = time.time()

            # резервный сигнал: после 10 секунд ожидания проверяем,
            # появилась ли вкладка "Бек-тест". По условиям проекта
            # она создаётся только после завершения одиночного теста
            # и исчезает при перезапуске MT5.
            if now >= next_fallback_check:
                if self._backtest_tab_present():
                    print(
                        "\n===== MT5 SINGLE TEST FINISHED =====\n"
                        "Источник: UI\n"
                        "Сигнал: вкладка 'Бек-тест' появилась после запуска теста\n"
                    )
                    return True

                next_fallback_check = now + 2.0

            if deadline is not None and now >= deadline:
                raise TimeoutError(
                    f"Не найдено завершение одиночного теста в Tester journal "
                    f"или вкладка 'Бек-тест' за {timeout} сек."
                )

            time.sleep(0.25)

    def ensure_optimization_started(self, timeout=15.0):
        """Start the Strategy Tester optimization if MT5 opened it idle.

        MT5 /config normally starts the tester automatically, but on some
        installations it only opens the Tester with the loaded parameters and
        leaves the green Start button visible. In that case the old optimizer
        waited forever because no test had actually started.

        We inspect only buttons belonging to the exact automation MT5 PID.
        If a Stop button is already present, the optimization is running and
        nothing is clicked. Otherwise we click a localized Start button.
        """
        if self.window is None:
            raise RuntimeError("MT5 window не подключено перед запуском оптимизации.")

        deadline = time.time() + timeout if timeout is not None else None
        start_texts = {
            "старт", "start", "почати", "запустити",
        }
        stop_texts = {
            "зупинити", "остановить", "stop",
        }

        while True:
            start_controls = []
            stop_found = False

            try:
                for ctrl in self.window.descendants(control_type="Button"):
                    try:
                        text = str(ctrl.window_text() or "").strip().casefold()
                        if text in stop_texts:
                            stop_found = True
                            break
                        if text in start_texts:
                            start_controls.append(ctrl)
                    except Exception:
                        pass
            except Exception:
                pass

            if stop_found:
                print("Оптимизация уже запущена.", flush=True)
                return True

            if start_controls:
                # Prefer the enabled/visible Start button.
                for ctrl in start_controls:
                    try:
                        if not ctrl.is_enabled() or not ctrl.is_visible():
                            continue
                        print("MT5: найдено состояние ожидания — запускаю оптимизацию кнопкой START.", flush=True)
                        try:
                            ctrl.click_input()
                        except Exception:
                            ctrl.click()
                        time.sleep(1.0)
                        print("MT5: команда START отправлена.", flush=True)
                        return True
                    except Exception:
                        continue

            if deadline is not None and time.time() >= deadline:
                raise TimeoutError(
                    "MT5 окно подключено, но кнопка START/STOP Strategy Tester не найдена "
                    f"за {timeout} сек. Оптимизация не была запущена."
                )

            time.sleep(0.5)


    def wait_optimization_finished(self, timeout=None):
        """Wait for the actual optimization completion.

        Primary authority: Tester journal completion messages. The active MT5
        tab is irrelevant, so switching tabs cannot trigger a false finish.
        """
        print("\n===== WAIT OPTIMIZATION =====\n")

        if self.terminal_dir is not None:
            # Tracking should normally be prepared before execute_config().
            # If the caller did not do that, take the current snapshot now.
            if not self._tracking_started:
                self.prepare_optimization_tracking()

            return self._wait_completion_from_journal(timeout)

        # Legacy callers without terminal_dir retain a guarded UI fallback.
        return self._wait_completion_from_ui(timeout)
