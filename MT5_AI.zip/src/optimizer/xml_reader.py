import re
import unicodedata
import xml.etree.ElementTree as ET


class XMLReader:
    """Read the MT5 optimization-results worksheet.

    Source of every optimization metric in this reader is ONLY the
    ``Результаты оптимизации`` worksheet/XML.  The value in physical column 2
    is exposed internally as ``result_2`` and is never confused with the
    single-test ``result_ontester`` value, which is read by TesterReader from
    the completed Бек-тест report.
    """

    NS = "urn:schemas-microsoft-com:office:spreadsheet"

    _ALIASES = {
        "pass": "Pass",
        "прохід": "Pass",
        "проход": "Pass",
        "результат": "result_2",
        "результат №2": "result_2",
        "результат 2": "result_2",
        "результат2": "result_2",
        "result": "result_2",
        "result 2": "result_2",
        "result #2": "result_2",
        "result №2": "result_2",
        "profit": "Profit",
        "прибуток": "Profit",
        "прибуток usd": "Profit",
        "expected payoff": "Expected Payoff",
        "математичне очікування": "Expected Payoff",
        "математическое ожидание": "Expected Payoff",
        "profitability": "Profitability",
        "прибыльность": "Profitability",
        "прибутковість": "Profitability",
        "profit factor": "Profit Factor",
        "profitfactor": "Profit Factor",
        "фактор прибутку": "Profit Factor",
        "фактор прибыли": "Profit Factor",
        "recovery factor": "Recovery Factor",
        "recoveryfactor": "Recovery Factor",
        "фактор відновлення": "Recovery Factor",
        "фактор восстановления": "Recovery Factor",
        "sharpe ratio": "Sharpe Ratio",
        "sharperatio": "Sharpe Ratio",
        "sharpe": "Sharpe Ratio",
        "коефіцієнт шарпа": "Sharpe Ratio",
        "коэффициент шарпа": "Sharpe Ratio",
        "custom": "Custom",
        "equity dd %": "Equity DD %",
        "equity dd": "Equity DD %",
        "equity drawdown relative": "Equity DD %",
        "relative drawdown": "Equity DD %",
        "relative drawdown %": "Equity DD %",
        "drawdown": "Equity DD %",
        "просадка %": "Equity DD %",
        "просадка": "Equity DD %",
        "просадка по средствам %": "Equity DD %",
        "відносна просадка за коштами": "Equity DD %",
        "trades": "Trades",
        "total trades": "Trades",
        "всього угод": "Trades",
        "всего сделок": "Trades",
    }

    def __init__(self, xml_path):
        self.xml_path = xml_path

    @staticmethod
    def _norm(value):
        # MT5 localizes headers and may vary spaces, punctuation, hyphens and
        # the case of the same header.  Normalize those presentation details
        # before alias matching.  The physical column position remains the
        # authority for Result №2 when the header itself is missing.
        value = str(value or "").replace("№", "")
        value = unicodedata.normalize("NFKC", value)
        value = value.replace("\u00a0", " ").replace("\u200b", "")
        value = value.replace("ё", "е").replace("Ё", "Е")
        value = value.replace("–", "-").replace("—", "-").replace("‑", "-")
        value = value.casefold()
        return re.sub(r"[^\w]+", "", value, flags=re.UNICODE).replace("_", "")

    @classmethod
    def _canonical_header(cls, header):
        text = str(header or "").strip()
        if not text:
            return None
        normalized = cls._norm(text)
        for alias, canonical in cls._ALIASES.items():
            if cls._norm(alias) == normalized:
                return canonical
        return text

    @staticmethod
    def _cell_value(cell, ns):
        data = cell.find("ss:Data", ns)
        if data is None or data.text is None:
            return ""
        return data.text.strip()

    def _read_row(self, row, ns):
        """Return values indexed by actual SpreadsheetML column index."""
        values = {}
        next_index = 1
        for cell in row.findall("ss:Cell", ns):
            index_attr = cell.get(f"{{{self.NS}}}Index")
            index = int(index_attr) if index_attr else next_index
            values[index - 1] = self._cell_value(cell, ns)
            next_index = index + 1
        return values

    def load(self):
        ns = {"ss": self.NS}
        tree = ET.parse(self.xml_path)
        root = tree.getroot()

        worksheets = root.findall("ss:Worksheet", ns)
        if not worksheets:
            raise RuntimeError("Worksheet не найден")

        table = None
        for worksheet in worksheets:
            candidate = worksheet.find("ss:Table", ns)
            if candidate is not None and len(candidate.findall("ss:Row", ns)) >= 2:
                table = candidate
                break
        if table is None:
            raise RuntimeError("Таблица результатов оптимизации не найдена")

        rows = table.findall("ss:Row", ns)
        header_values = self._read_row(rows[0], ns)
        if not header_values:
            raise RuntimeError("В optimization.xml отсутствует строка заголовков")

        max_index = max(header_values)
        headers = {
            index: self._canonical_header(header_values.get(index, ""))
            for index in range(max_index + 1)
        }

        # The only positional fallback permitted for the ambiguous MT5
        # Result column is physical column #2 (zero-based index 1).  We use it
        # only when the header itself is absent there and the data row actually
        # contains a value at that physical position.  We never shift Profit
        # or another column into result_2.
        result_2_header = headers.get(1)
        if result_2_header not in (None, "result_2"):
            result_2_header_missing = False
        else:
            result_2_header_missing = result_2_header is None

        records = []
        result_2_sources = set()

        for row in rows[1:]:
            values_by_index = self._read_row(row, ns)
            if not values_by_index:
                continue

            max_row_index = max(max_index, max(values_by_index))
            record = {}

            for index, value in values_by_index.items():
                key = headers.get(index)
                if key:
                    record[key] = value

            if result_2_header_missing and 1 in values_by_index and "result_2" not in record:
                record["result_2"] = values_by_index[1]
                result_2_sources.add("physical_column_2")
            elif "result_2" in record:
                result_2_sources.add("header")

            if not any(str(v).strip() for v in values_by_index.values()):
                continue

            records.append(record)

        if not records:
            raise RuntimeError("В optimization.xml нет валидных результатов")

        missing_result_2 = sum(1 for row in records if "result_2" not in row)
        if missing_result_2:
            raise RuntimeError(
                "В Результатах оптимизации не удалось надёжно определить "
                "физическую колонку №2 (Результат №2). "
                f"Строк без result_2: {missing_result_2} из {len(records)}. "
                "Другую колонку вместо неё не подставляю."
            )

        print(f"XMLReader: headers={headers}")
        print(f"XMLReader: records={len(records)}")
        print(
            "XMLReader: result_2 source="
            + ("header" if "header" in result_2_sources else "physical_column_2")
        )
        first = records[0]
        print(
            "XMLReader: first="
            f"Pass={first.get('Pass')} | "
            f"Result№2={first.get('result_2')} | "
            f"Profit={first.get('Profit')} | "
            f"PF={first.get('Profit Factor')} | "
            f"RF={first.get('Recovery Factor')} | "
            f"Sharpe={first.get('Sharpe Ratio')} | "
            f"DD={first.get('Equity DD %')}"
        )
        return records
