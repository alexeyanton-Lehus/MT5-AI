import time
import json
from pathlib import Path
from shutil import copy2


from optimizer.xml_reader import XMLReader
from mt5.ini_builder import IniBuilder
from mt5.journal_monitor import JournalMonitor
from project_paths import OPTIMIZATION_INI_DIR, TESTER_INI_SETTINGS_DIR
from optimizer.report_cleanup import ReportCleanup


class OptimizationRunner:
    def __init__(self, mt5, terminal_dir):
        self.mt5 = mt5
        self.builder = IniBuilder()
        self.terminal_dir = Path(terminal_dir)
        self.report_cleanup = ReportCleanup(self.terminal_dir)
        self._last_xml_cleanup = 0.0
        self._remove_legacy_optimization_inis()

    @staticmethod
    def _remove_legacy_optimization_inis():
        """Remove stage/optimization INIs from the FINAL INI folder.

        Stage INIs are temporary and are stored only under
        working/optimization_ini. The final folder is reserved for final
        candidate INIs.
        """
        directory = Path(TESTER_INI_SETTINGS_DIR)
        if not directory.exists():
            return

        removed = 0
        for path in directory.iterdir():
            if not path.is_file():
                continue
            if path.suffix.lower() == ".ini" and path.name.lower().endswith("-optimization.ini"):
                try:
                    path.unlink()
                    removed += 1
                except OSError:
                    pass

        single_tests = directory / "single_tests"
        if single_tests.exists():
            import shutil
            try:
                shutil.rmtree(single_tests)
            except OSError:
                pass

        if removed:
            print(f"Удалено старых optimization INI из финальной папки: {removed}")



    def _cleanup_old_xml_if_due(self):
        """Периодически удаляет только XML старше 4 часов.

        Очистка не привязана к переходу между stage: проверка выполняется
        не чаще одного раза в час и никогда не удаляет свежий XML.
        """
        now = time.time()
        if now - self._last_xml_cleanup < 3600:
            return

        self.report_cleanup.cleanup_old_xml(max_age_seconds=4 * 3600)
        self._last_xml_cleanup = now

    def build_report_path(self, pair):
        return self.terminal_dir / "reports" / pair["symbol"] / "optimization.xml"

    def build_final_report_path(self, pair, stage):
        reports_dir = self.terminal_dir / "reports" / pair["symbol"]
        reports_dir.mkdir(parents=True, exist_ok=True)
        return reports_dir / f"optimization_{stage['name']}.xml"

    def wait_finish(self, report_path, started_at, timeout=3600, monitor=None):
        """Wait for the actual MT5 optimization completion signal.

        The Tester journal is the completion authority. The visible MT5
        "Остановить" / "Зупинити" / "Stop" button is NOT authoritative
        because it disappears when the user changes tabs.

        XML is validated only AFTER the Tester journal reports completion.
        """
        deadline = time.time() + timeout

        if not self.mt5.pid:
            raise RuntimeError(
                "Не найден PID автоматического MT5 перед ожиданием оптимизации."
            )

        if monitor is None:
            monitor = JournalMonitor(self.mt5.pid, self.terminal_dir)
        print("\n===== WAIT OPTIMIZATION =====\n", flush=True)

        # Connect to the exact automation MT5 instance started by this run.
        # The completion signal is read from the Tester journal, not from
        # whichever MT5 tab happens to be visible.
        #
        # IMPORTANT: some MT5 builds open the Strategy Tester from /config
        # but leave the tester in an idle state with the green START button.
        # Previously we skipped monitor.connect() whenever terminal_dir was
        # present, so there was no way to detect/start that state.
        # Connect unconditionally to the exact PID and explicitly press START
        # only when the tester is idle.
        monitor.connect(
            timeout=min(30.0, max(1.0, deadline - time.time()))
        )
        monitor.ensure_optimization_started()

        monitor.wait_optimization_finished(
            timeout=max(1.0, deadline - time.time())
        )

        if time.time() >= deadline:
            raise TimeoutError(
                f"Оптимизация не завершилась за {timeout} сек: {report_path}"
            )

        # The Tester journal has confirmed completion. Give MT5 a short
        # window to finish flushing optimization.xml. Do not use mtime as a
        # completion condition.
        # A long timeout would only hide the real cause of a missing report.
        xml_deadline = min(deadline, time.time() + 10.0)
        last_size = -1
        last_mtime = -1.0

        while time.time() < xml_deadline:
            exists = report_path.exists()
            size = -1
            mtime = -1.0

            if exists:
                try:
                    stat = report_path.stat()
                    size = stat.st_size
                    mtime = stat.st_mtime
                except OSError:
                    pass

            print(
                f"XML CHECK: exists={exists} | size={size} | mtime={mtime:.3f}",
                end="\r",
                flush=True,
            )

            # Do not accept a fresh-looking old optimization.xml left from a
            # previous run. MT5 must have written this report after this run
            # started; journal completion remains the completion authority.
            fresh_enough = exists and mtime >= (started_at - 2.0)

            if fresh_enough and size > 0:
                try:
                    records = XMLReader(report_path).load()
                except Exception as exc:
                    records = None
                    print(
                        f"\nXML CHECK: файл есть, но ещё не читается: {exc}",
                        flush=True,
                    )

                if records:
                    print(
                        "\n===== ОПТИМИЗАЦИЯ ПОДТВЕРЖДЕНА =====\n"
                        f"Записей в XML: {len(records)}\n",
                        flush=True,
                    )
                    return True

            last_size = size
            last_mtime = mtime
            time.sleep(1)

        raise TimeoutError(
            "MT5 сообщил завершение оптимизации через Tester journal, "
            f"но читаемый optimization.xml не готов за 10 сек: {report_path}. "
            f"Последний размер={last_size}, mtime={last_mtime:.3f}"
        )

    def _save_stage_ini(self, ini, pair, stage):
        OPTIMIZATION_INI_DIR.mkdir(parents=True, exist_ok=True)

        target = (
            OPTIMIZATION_INI_DIR
            / f"{pair['symbol']}-{stage['name']}-optimization.ini"
        )

        copy2(ini, target)
        return target

    def run(self, pair, stage):
        # XML cleanup is age-based, not stage-based: only files older than
        # 4 hours are removed, and the check runs at most once per hour.
        self._cleanup_old_xml_if_due()

        # Safety guard: final INI folder is never a staging area.
        self._remove_legacy_optimization_inis()
        ini = self.builder.build(pair)
        saved_ini = self._save_stage_ini(ini, pair, stage)

        print(f"INI сохранён: {saved_ini}")

        report_path = self.build_report_path(pair)
        final_report_path = self.build_final_report_path(pair, stage)
        report_path.parent.mkdir(parents=True, exist_ok=True)
        final_report_path.parent.mkdir(parents=True, exist_ok=True)

        trace = {
            "symbol": pair.get("symbol"),
            "stage": stage.get("name"),
            "trade_direction": stage.get("trade_direction"),
            "optimization_ini": str(saved_ini),
            "report_path": str(report_path),
            "started_at": None,
        }

        print("1. Запуск MT5")
        started_at = time.time()
        trace["started_at"] = started_at
        monitor = JournalMonitor(None, self.terminal_dir)
        monitor.prepare_optimization_tracking()

        self.mt5.execute_config(str(ini))
        monitor.pid = self.mt5.pid
        print("2. MT5 запущен")

        try:
            self.wait_finish(report_path, started_at=started_at, monitor=monitor)
            trace["wait_finish"] = "OK"
        except Exception as exc:
            trace["wait_finish"] = "ERROR"
            trace["error"] = str(exc)
            trace["traceback"] = __import__("traceback").format_exc()
            raise
        finally:
            trace_path = Path(OPTIMIZATION_INI_DIR).parent / "optimization_runner_trace.jsonl"
            with open(trace_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(trace, ensure_ascii=False, default=str) + "\n")

        if not report_path.exists():
            raise RuntimeError(f"XML не найден:\n{report_path}")

        copy2(report_path, final_report_path)
        print(f"Исходный XML : {report_path}")
        print(f"Копия XML    : {final_report_path}")
        print(f"\nОтчёт сохранён:\n{final_report_path}\n")

        records = XMLReader(final_report_path).load()
        print(f"Получено записей: {len(records)}")
        if records:
            print("Первый распознанный результат:", {
                k: records[0].get(k)
                for k in (
                    "Pass", "result_2", "Profit", "Profitability", "Profit Factor",
                    "Recovery Factor", "Sharpe Ratio",
                    "Equity DD %", "Relative Drawdown"
                )
                if k in records[0]
            })
        else:
            print("КРИТИЧЕСКАЯ ДИАГНОСТИКА: XML прочитан, но records=0")
        return records
