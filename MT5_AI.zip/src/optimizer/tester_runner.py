from pathlib import Path

from optimizer.set_writer import SetWriter
from mt5.ini_builder import IniBuilder
from mt5.journal_monitor import JournalMonitor
from optimizer.report_manager import ReportManager
from project_paths import WORKING_DIR


class TesterRunner:

    def __init__(self, mt5):

        self.mt5 = mt5
        self.builder = IniBuilder()
        self.reports = ReportManager(
            self.builder.terminal_dir
        )

    # =========================================================
    # SINGLE TEST
    # =========================================================

    def run_single(
        self,
        pair,
        record,
        trade_direction=None,
    ):
        pass_number = int(float(record["Pass"]))

        print("\n======================================")
        print("RUN SINGLE TEST")
        print(f"Pass = {pass_number}")
        print("======================================\n")

        working_set = WORKING_DIR / "working.set"
        record_to_write = dict(record)
        direction = trade_direction or "BOTH"
        record_to_write["TradeDirection"] = direction
        SetWriter(working_set).write(record_to_write)
        print("working.set обновлён")

        self.reports.remove_single_test_artifacts(pair, record)
        ini = self.builder.build_single_test(pair, pass_number)

        monitor = JournalMonitor(None, self.builder.terminal_dir)
        monitor.prepare_optimization_tracking()

        started = False
        try:
            self.mt5.execute_config(str(ini))
            started = True
            monitor.pid = self.mt5.pid
            monitor.connect(timeout=30)

            monitor.wait_single_test_finished(timeout=60)
            print("\nMT5 завершил одиночный тест.")

            monitor.close_all_windows()

            report = self.reports.wait_for_single_test_report(
                pair,
                record,
                timeout=60
            )

            print("\nОдиночный отчёт готов:")
            print(report)

            monitor.close_all_windows()
            return report
        finally:
            # A failed startup/test must never leave an automation MT5 behind.
            # stop_terminal() is PID-bound and does not touch pre-existing
            # manual terminals.
            if started:
                try:
                    self.mt5.stop_terminal()
                except Exception as exc:
                    print(f"WARNING: не удалось остановить автоматический MT5: {exc}")
