import json
import math
from pathlib import Path

from optimizer.number_parser import parse_report_number
from optimizer.atr_scaler import ATRScaler


class RangeShrinker:
    """Сужает диапазон вокруг медианы up to TOP-1000.

    Каждое новое сужение использует диапазон предыдущего прохода.
    Шаг каждого следующего прохода делится на 2.

    Для int:
      5 -> 2 -> 1
    т.е. используется floor(old_step / 2), но не меньше 1.

    Для double минимальный шаг задаётся индивидуально через поле
    ``min_step`` в optimization_ranges.json. Универсального минимального
    шага для всех double нет.
    """

    INTEGER_PARAMETERS = {
        "RiskPercent",
        "MaxOrdersGrid",
        "MA_Period",
        "ATR_Period_for_MM_buy",
        "ATR_Period_for_Grid_buy",
        "RSI_Period_buy",
        "RSI_BOTTOM",
        "ATR_Period_for_MAdist_buy",
        "ATR_Period_for_MM_sell",
        "ATR_Period_for_Grid_sell",
        "RSI_Period_sell",
        "RSI_UP",
        "ATR_Period_for_MAdist_sell",
    }

    def __init__(self, ranges_file, state_file):
        self.ranges_file = Path(ranges_file)
        self.state_file = Path(state_file)

        with open(self.ranges_file, "r", encoding="utf-8") as f:
            self.original_ranges = json.load(f)
        self.atr_scaler = ATRScaler()

    @staticmethod
    def _number(value):
        parsed = parse_report_number(value)
        if parsed is None:
            raise ValueError(f"Некорректное числовое значение: {value!r}")
        return parsed

    @classmethod
    def _is_integer_parameter(cls, name, rng):
        if name in cls.INTEGER_PARAMETERS:
            return True

        # Для неизвестного параметра сохраняем старую безопасную логику.
        values = (
            rng.get("start"),
            rng.get("step"),
            rng.get("stop"),
            rng.get("value"),
        )
        return all(
            isinstance(v, int)
            or (isinstance(v, float) and float(v).is_integer())
            for v in values
            if v is not None
        )

    @staticmethod
    def _round(value, integer=False):
        if integer:
            return int(value)
        return round(value, 10)

    def _current_symbol(self):
        """Read the symbol of the currently prepared MT5 test."""
        working_ini = self.state_file.parent / "working.ini"
        if not working_ini.exists():
            raise RuntimeError(f"Не найден working.ini для определения текущей пары: {working_ini}")
        # working.ini is written by the MT5 pipeline in UTF-16.
        # Fall back to UTF-8 only for compatibility with manually created files.
        text = None
        for encoding in ("utf-16", "utf-8-sig", "utf-8"):
            try:
                text = working_ini.read_text(encoding=encoding)
                break
            except (UnicodeError, OSError):
                continue
        if text is None:
            raise RuntimeError(f"Не удалось прочитать working.ini: {working_ini}")

        for raw in text.splitlines():
            line = raw.strip()
            if line.lower().startswith("symbol="):
                symbol = line.split("=", 1)[1].strip()
                if symbol:
                    return symbol
        raise RuntimeError(f"В working.ini не найден Symbol: {working_ini}")

    def _min_step(self, name, rng, integer):
        # These three parameters have fixed optimization steps on EVERY stage.
        # They must not be halved by range narrowing:
        #   RiskPercent   -> 1
        #   MaxOrdersGrid -> 1
        #   MA_Period     -> 25
        fixed_steps = {
            "RiskPercent": 1.0,
            "MaxOrdersGrid": 1.0,
            "MA_Period": 25.0,
        }
        if name in fixed_steps:
            return fixed_steps[name]

        if integer:
            return 2.0

        if name in ("ATR_min_level_for_buy", "ATR_min_level_for_sell"):
            symbol = self._current_symbol()
            # Shrinker works on normalized units. Convert the native minimum
            # step from Appendix B to that internal scale.
            return self.atr_scaler.min_step(symbol) / self.atr_scaler.coefficient(symbol)

        if "min_step" not in rng:
            original = self.original_ranges.get(name, {})
            if "min_step" in original:
                return self._number(original["min_step"])
            return 0.0

        value = self._number(rng["min_step"])
        if value < 0:
            raise RuntimeError(f"Некорректный min_step для {name}: {value}")
        return value

    def build(self, parameter_names, medians, source_ranges=None):
        """Построить следующий диапазон из предыдущего диапазона.

        source_ranges:
          - None -> исходные диапазоны из optimization_ranges.json;
          - dict -> диапазоны предыдущего прохода.
        """
        result = {}
        first_narrowing = source_ranges is None
        source = source_ranges if source_ranges is not None else self.original_ranges

        for name in parameter_names:
            if name not in source:
                raise RuntimeError(
                    f"Нет исходного диапазона для параметра {name}"
                )

            rng = source[name]
            old_start = self._number(rng["start"])
            old_stop = self._number(rng["stop"])
            old_step = self._number(rng["step"])

            if old_stop < old_start:
                raise RuntimeError(
                    f"Некорректный диапазон {name}: {old_start} > {old_stop}"
                )

            median = self._number(medians[name])
            median = min(max(median, old_start), old_stop)

            # Каждая граница проходит половину расстояния к медиане.
            new_start = old_start + (median - old_start) / 2.0
            new_stop = median + (old_stop - median) / 2.0

            integer = self._is_integer_parameter(name, rng)
            min_step = self._min_step(name, rng, integer)

            # Следующий проход: обычный шаг делится на 2.
            # Исключение: три общих параметра имеют фиксированный шаг
            # на всех этапах и никогда не уменьшаются.
            fixed_steps = {
                "RiskPercent": 1.0,
                "MaxOrdersGrid": 1.0,
                "MA_Period": 25.0,
            }
            if name in fixed_steps:
                new_step = fixed_steps[name]
            elif integer:
                # 5 -> 2, 3 -> 1, 1 -> 1
                new_step = max(
                    math.floor(old_step / 2.0),
                    int(min_step),
                )
            else:
                new_step = None

            if integer:
                new_start = math.ceil(new_start)
                new_stop = math.floor(new_stop)
            else:
                if name in ("ATR_min_level_for_buy", "ATR_min_level_for_sell"):
                    symbol = self._current_symbol()
                    initial_normalized = (
                        self.atr_scaler.start_step(symbol)
                        / self.atr_scaler.coefficient(symbol)
                    )
                    # First narrowing starts from the Appendix-B start step;
                    # subsequent narrowings halve it, never crossing the
                    # Appendix-B minimum step.
                    if first_narrowing:
                        new_step = initial_normalized
                    else:
                        new_step = max(old_step / 2.0, min_step)
                else:
                    new_step = max(old_step / 2.0, min_step)
                new_start = round(new_start, 10)
                new_stop = round(new_stop, 10)
                new_step = round(new_step, 10)

            if integer:
                # MT5 rejects an optimization range when stop < start and,
                # in practice, a one-point range is not an optimization at
                # all. Keep at least two valid grid points whenever the
                # previous range contains at least two points with the fixed
                # step. This is especially important for the three common
                # parameters, whose steps are fixed on every stage.
                old_start_i = math.ceil(old_start)
                old_stop_i = math.floor(old_stop)
                step_i = max(1, int(round(new_step)))

                new_start = int(new_start)
                new_stop = int(new_stop)

                # Clamp to the source range first.
                new_start = max(old_start_i, min(new_start, old_stop_i))
                new_stop = max(old_start_i, min(new_stop, old_stop_i))

                # If the narrowed range has fewer than two points, expand it
                # by one step while staying inside the previous range.
                if old_stop_i - old_start_i >= step_i and new_stop - new_start < step_i:
                    center = int(round(median))
                    center = max(old_start_i, min(center, old_stop_i))
                    lower = center - step_i
                    upper = center + step_i

                    if lower >= old_start_i:
                        new_start, new_stop = lower, center
                    elif upper <= old_stop_i:
                        new_start, new_stop = center, upper
                    else:
                        new_start, new_stop = old_start_i, min(old_start_i + step_i, old_stop_i)

                if new_stop < new_start:
                    new_start, new_stop = old_start_i, old_stop_i

            elif new_stop < new_start:
                new_start = median
                new_stop = median

            result[name] = {
                "start": self._round(new_start, integer),
                "step": self._round(new_step, integer),
                "stop": self._round(new_stop, integer),
                "enabled": "Y",
                "median": self._round(median, integer),
                "source_start": rng["start"],
                "source_step": rng["step"],
                "source_stop": rng["stop"],
                "min_step": self._round(min_step, False),
            }

        return result

    def save(self, direction, ranges):
        self.state_file.parent.mkdir(parents=True, exist_ok=True)

        state = {}
        if self.state_file.exists():
            try:
                with open(self.state_file, "r", encoding="utf-8") as f:
                    state = json.load(f)
            except (OSError, json.JSONDecodeError):
                state = {}

        state[direction] = ranges

        with open(self.state_file, "w", encoding="utf-8") as f:
            json.dump(state, f, indent=2, ensure_ascii=False)

    def load(self, direction):
        if not self.state_file.exists():
            raise RuntimeError(
                f"Суженные диапазоны {direction} не найдены: {self.state_file}"
            )

        with open(self.state_file, "r", encoding="utf-8") as f:
            state = json.load(f)

        if direction not in state:
            raise RuntimeError(
                f"Суженные диапазоны {direction} отсутствуют в {self.state_file}"
            )

        return state[direction]
