from pathlib import Path
import json
import traceback
import time

from optimizer.tester_runner import TesterRunner
from optimizer.tester_reader import TesterReader
from optimizer.report_manager import ReportManager
from project_paths import WORKING_DIR
from optimizer.number_parser import parse_report_number


class CandidateSelector:
    """Run single tests using fixed, non-adaptive back-test criteria."""

    def __init__(self, mt5, terminal_dir, criteria_settings=None):
        self.mt5 = mt5
        self.terminal_dir = Path(terminal_dir)
        self.criteria_settings = criteria_settings or {}
        self.last_passed = []
        self.runner = TesterRunner(mt5)
        self.reader = TesterReader()
        self.reports = ReportManager(terminal_dir)

    @staticmethod
    def f(v):
        parsed = parse_report_number(v)
        return 0.0 if parsed is None else parsed

    def _cfg(self, key, default):
        value = self.criteria_settings.get(key, default)
        parsed = parse_report_number(value)
        return default if parsed is None else parsed

    def _direction_win_key(self, stage):
        direction = stage.get("trade_direction", "BOTH")
        if direction == "BUY_ONLY":
            return "Win % Long"
        if direction == "SELL_ONLY":
            return "Win % Short"
        return "Win %"

    def _single_test_checks(self, stats, stage):
        """Return the single-test acceptance checks.

        FINAL_TEST uses the completed MT5 Бек-тест as the source of truth for
        the single-test verdict. The adaptive ResultSelector criteria are
        applied to the optimization table before a candidate reaches this
        method and are never repeated here.
        """
        dd_max = self._cfg("drawdown", 10.0)
        lr_min = self._cfg("lr_correlation", 0.96)
        win_min = self._cfg("single_test_win", 70.0)
        ontester_min = self._cfg("single_test_ontester", 4.0)
        win_key = self._direction_win_key(stage)

        def check(key, operator, threshold, comparator):
            value = parse_report_number(stats.get(key))
            present = value is not None
            ok = present and comparator(value, threshold)
            return key, (value if present else None), operator, threshold, ok, key

        return [
            ("Relative Drawdown", *check(
                "Equity Drawdown Relative", "<", dd_max, lambda value, limit: value < limit
            )[1:]),
            ("LR Correlation", *check(
                "LR Correlation", ">=", lr_min, lambda value, limit: value >= limit
            )[1:]),
            (win_key, *check(
                win_key, ">=", win_min, lambda value, limit: value >= limit
            )[1:]),
            ("Результат OnTester", *check(
                "result_ontester", ">=", ontester_min, lambda value, limit: value >= limit
            )[1:]),
        ]

    def _failed_criteria(self, stats, stage):
        return [name for name, _, _, _, ok, _ in self._single_test_checks(stats, stage) if not ok]

    def _single_candidate_verdict(self, candidate, stats, stage, copied_reports=None, error=None):
        checks = self._single_test_checks(stats, stage)
        return {
            "candidate": candidate,
            "stage": stage.get("name"),
            "trade_direction": stage.get("trade_direction", "BOTH"),
            "pass": candidate.get("Pass"),
            "reports": copied_reports or {},
            "error": error,
            "stats": stats,
            "criteria": [
                {"name": n, "source_key": sk, "value": v, "operator": op,
                 "threshold": t, "passed": bool(ok), "value_present": sk in stats}
                for n, v, op, t, ok, sk in checks
            ],
            "failed_criteria": [n for n, _, _, _, ok, _ in checks if not ok],
            "verdict": "ERROR" if error else ("PASS" if all(ok for *_, ok, _ in checks) else "FAIL"),
        }

    def select_batch(self, pair, stage, candidates, target_valid=3):
        """Test candidates in ranking order and stop immediately after target_valid passes.

        ``candidates`` is expected to be pre-ranked by optimization Profit.
        Only the first ``target_valid`` candidates that pass ALL single-test
        criteria are returned. There is no batch-of-20 behavior: once the
        required number of valid candidates is reached, no further MT5 tests
        are started.
        """
        candidates = list(candidates or [])
        target_valid = max(1, int(target_valid))
        tested = []
        passed_items = []

        diagnostic_dir = WORKING_DIR / "single_test_diagnostics"
        diagnostic_dir.mkdir(parents=True, exist_ok=True)
        diagnostic_file = diagnostic_dir / f"{stage['name']}.jsonl"
        summary_file = diagnostic_dir / f"{stage['name']}_summary.json"
        if not diagnostic_file.exists():
            diagnostic_file.write_text("", encoding="utf-8")

        for candidate in candidates:
            # The candidate list is already ranked by optimization Profit.
            # Do not reorder it: the first three candidates passing the
            # single-test criteria are the required TOP-3.
            pass_number = int(float(candidate["Pass"]))
            try:
                self.runner.run_single(pair, candidate, trade_direction=stage.get("trade_direction", "BOTH"))
                if self.mt5.is_running():
                    self.mt5.stop_terminal()
                    deadline = time.time() + 20
                    while self.mt5.is_running() and time.time() < deadline:
                        time.sleep(0.2)

                copied_reports = self.reports.copy_test_reports(pair, stage, candidate)
                stats = self.reader.read(copied_reports["common"])
                failed = self._failed_criteria(stats, stage)
                item = {"candidate": candidate, "stats": stats, "failed_criteria": failed}
                tested.append(item)

                verdict = self._single_candidate_verdict(candidate, stats, stage, copied_reports=copied_reports)
                with diagnostic_file.open("a", encoding="utf-8") as df:
                    df.write(json.dumps(verdict, ensure_ascii=False, default=str) + "\n")

                if not failed:
                    passed_items.append(item)

                print(
                    f"Pass={pass_number} | Profit={self.f(stats.get('Profit')):.2f} | "
                    f"Win={self.f(stats.get(self._direction_win_key(stage))):.2f}% | "
                    f"DD={self.f(stats.get('Equity Drawdown Relative')):.2f}% | "
                    f"LR={self.f(stats.get('LR Correlation')):.4f} | "
                    f"OnTester={self.f(stats.get('result_ontester')):.4f} | "
                    f"Причина={failed or 'PASSED'}"
                )

                if len(passed_items) >= target_valid:
                    print(
                        f"TOP-{target_valid}: достигнуто {target_valid} успешных кандидатов; "
                        "дальнейшие одиночные тесты прекращены."
                    )
                    break
            except Exception as exc:
                tested.append({"candidate": candidate, "stats": {}, "failed_criteria": [f"TEST ERROR: {exc}"], "error": str(exc)})
                verdict = self._single_candidate_verdict(candidate, {}, stage, error=str(exc))
                verdict["traceback"] = traceback.format_exc()
                with diagnostic_file.open("a", encoding="utf-8") as df:
                    df.write(json.dumps(verdict, ensure_ascii=False, default=str) + "\n")
                print(f"ERROR single test Pass={pass_number}: {exc}")
                if self.mt5.is_running():
                    self.mt5.stop_terminal()

        # The order of passed_items is the optimization ranking order.
        # Keep it unchanged so TOP-1/2/3 mean the first qualifying candidates.
        all_entries = []
        try:
            for line in diagnostic_file.read_text(encoding="utf-8").splitlines():
                if not line.strip():
                    continue
                try:
                    all_entries.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
        except OSError:
            all_entries = []

        summary = {
            "stage": stage.get("name"),
            "tested": len(all_entries),
            "passed": sum(1 for entry in all_entries if entry.get("verdict") == "PASS"),
            "errors": sum(1 for entry in all_entries if entry.get("verdict") == "ERROR"),
            "candidate_pool": len(candidates),
            "target_valid": target_valid,
            "single_test_criteria": [
                {
                    "name": name,
                    "source_key": source_key,
                    "operator": operator,
                    "threshold": threshold,
                }
                for name, _value, operator, threshold, _ok, source_key
                in self._single_test_checks({}, stage)
            ],
            "diagnostic_file": str(diagnostic_file),
        }
        summary_file.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
        self.last_passed = passed_items[:target_valid]
        return self.last_passed

    # Compatibility wrapper for callers that still use select().
    def select(self, pair, stage, candidates, max_single_tests=None, target_valid=3):
        if max_single_tests is not None:
            candidates = list(candidates)[:int(max_single_tests)]
        return self.select_batch(pair, stage, candidates, target_valid=target_valid)
