from optimizer.number_parser import parse_report_number


class ResultSelector:
    """Filter and rank MT5 optimization results using one adaptive mechanism."""

    # The order is intentional: only one criterion is relaxed per failed level.
    RELAX_ORDER = ("result_2", "profitability", "recovery", "sharpe")

    def __init__(self, records, criteria_settings=None):
        self.records = list(records or [])
        self.criteria_settings = criteria_settings or {}

    @staticmethod
    def f(value):
        parsed = parse_report_number(value)
        return 0.0 if parsed is None else parsed

    @staticmethod
    def _value(row, *keys):
        for key in keys:
            value = row.get(key)
            if value not in (None, ""):
                return value
        return None

    def _configured(self, key, default):
        value = self.criteria_settings.get(key, default)
        parsed = parse_report_number(value)
        return default if parsed is None else parsed

    def _optimization_values(self, row):
        def parsed(*keys):
            value = self._value(row, *keys)
            if value in (None, ""):
                return None
            return parse_report_number(value)

        return {
            "Profit": parsed("Profit", "Total Net Profit", "Net Profit"),
            # In MT5 optimization reports the metric shown to the user as
            # "Прибутковість / Profitability" may be exported as either
            # "Profit Factor" or "Profitability" depending on the report.
            "Profitability": parsed(
                "Profit Factor", "ProfitFactor", "PF",
                "Profitability", "Прибыльность", "Прибутковість",
                "Фактор прибыли", "Фактор прибутку",
            ),
            "Drawdown": parsed(
                "Equity Drawdown Relative", "Relative Drawdown", "Equity DD %"
            ),
            "Recovery Factor": parsed(
                "Recovery Factor", "RecoveryFactor", "RF"
            ),
            "Sharpe Ratio": parsed(
                "Sharpe Ratio", "SharpeRatio", "Sharpe"
            ),
            "Результат №2": parsed("result_2"),
        }

    def _ranked_records(self):
        return sorted(
            self.records,
            key=lambda row: (
                self._optimization_values(row)["Profit"]
                if self._optimization_values(row)["Profit"] is not None
                else float("-inf")
            ),
            reverse=True,
        )

    def filter_level(self, result_2_min, profitability_min, recovery_min, sharpe_min):
        """Filter the COMPLETE optimization table at one criteria level."""
        ranked = self._ranked_records()
        dd_max = self._configured("optimization_filter_drawdown", 10.0)
        out = []
        for row in ranked:
            v = self._optimization_values(row)
            # A missing metric is not a zero. It is an invalid optimization
            # record and must never pass a positive threshold (especially DD,
            # where the old 0.0 fallback could incorrectly accept it).
            if any(
                v[key] is None
                for key in (
                    "Drawdown",
                    "Результат №2",
                    "Profitability",
                    "Recovery Factor",
                    "Sharpe Ratio",
                )
            ):
                continue

            if (
                v["Drawdown"] < dd_max
                and v["Результат №2"] > result_2_min
                and v["Profitability"] > profitability_min
                and v["Recovery Factor"] > recovery_min
                and v["Sharpe Ratio"] > sharpe_min
            ):
                out.append(row)
        return out

    def adaptive_levels(self):
        """Yield levels, relaxing exactly one criterion at a time."""
        result_2 = self._configured("result_2_start", 95.0)
        profitability = self._configured("profitability_start", 4.0)
        recovery = self._configured("recovery_start", 4.0)
        sharpe = self._configured("sharpe_start", 2.0)
        result_2_min = self._configured("result_2_min", 90.0)
        profitability_min = self._configured("profitability_min", 3.0)
        recovery_min = self._configured("recovery_min", 3.0)
        sharpe_min = self._configured("sharpe_min", 1.5)
        sharpe_factor = self._configured("sharpe_step_factor", 0.8)

        yield {
            "result_2": result_2,
            "profitability": profitability,
            "recovery": recovery,
            "sharpe": sharpe,
        }

        # Relax cyclically: Result№2 -> Profit Factor -> Recovery Factor ->
        # Sharpe -> Result№2 -> ... . Only one criterion changes per failed
        # full pass; already-relaxed values remain at their current levels.
        order = ("result_2", "profitability", "recovery", "sharpe")
        index = 0
        while True:
            key = order[index % len(order)]
            changed = False

            if key == "result_2" and result_2 > result_2_min:
                result_2 = max(
                    result_2_min,
                    result_2 - self._configured("result_2_step", 0.50),
                )
                changed = True
            elif key == "profitability" and profitability > profitability_min:
                profitability = max(
                    profitability_min,
                    profitability - self._configured("profitability_step", 0.5),
                )
                changed = True
            elif key == "recovery" and recovery > recovery_min:
                recovery = max(
                    recovery_min,
                    recovery - self._configured("recovery_step", 0.5),
                )
                changed = True
            elif key == "sharpe" and sharpe > sharpe_min:
                sharpe = max(
                    sharpe_min,
                    sharpe * sharpe_factor,
                )
                changed = True

            if changed:
                yield {
                    "result_2": result_2,
                    "profitability": profitability,
                    "recovery": recovery,
                    "sharpe": sharpe,
                }

            # If the current criterion is already at its minimum, move to the
            # next criterion. Stop only after a complete cycle has no possible
            # relaxation left.
            index += 1
            if index % len(order) == 0:
                if (
                    result_2 <= result_2_min
                    and profitability <= profitability_min
                    and recovery <= recovery_min
                    and sharpe <= sharpe_min
                ):
                    break

    def _base_filter_level(self):
        """Return the non-adaptive filter used by COMMON/narrowing stages.

        The adaptive criteria (92/10/5/3 -> minima) belong ONLY to FINAL_TEST.
        COMMON and the range-narrowing passes need the established broad
        optimization filter; otherwise a strict final-test threshold can
        terminate the pair before FINAL_TEST ever gets a chance to relax it.
        """
        return self.filter_level(
            self._configured("optimization_filter_result_2", 92.0),
            self._configured("optimization_filter_profitability", 4.0),
            self._configured("optimization_filter_recovery", 4.0),
            self._configured("optimization_filter_sharpe", 2.0),
        )

    def best200(self):
        """Backward-compatible method; return up to 2000 narrowing candidates."""
        candidates = self._base_filter_level()
        if not candidates:
            raise RuntimeError("Нет результатов после фильтрации")
        return candidates[:2000]

    # Backward-compatible alias for older callers.
    def best20(self):
        return self.best200()

    def adaptive_narrowing_candidates(self):
        """Return the first non-empty narrowing pool using adaptive criteria.

        The normal COMMON/narrowing filter starts from optimization_filter_*
        values. If no candidate exists, relax one criterion at a time using the
        configured *_min values. The same rule is used on every narrowing stage.
        """
        start = {
            "result_2": self._configured("optimization_filter_result_2", 92.0),
            "profitability": self._configured("optimization_filter_profitability", 4.0),
            "recovery": self._configured("optimization_filter_recovery", 4.0),
            "sharpe": self._configured("optimization_filter_sharpe", 2.0),
        }
        mins = {
            "result_2": self._configured("result_2_min", 90.0),
            "profitability": self._configured("profitability_min", 3.0),
            "recovery": self._configured("recovery_min", 3.0),
            "sharpe": self._configured("sharpe_min", 1.5),
        }
        current = dict(start)
        levels = []
        order = ("result_2", "profitability", "recovery", "sharpe")
        while True:
            candidates = self.filter_level(
                current["result_2"], current["profitability"],
                current["recovery"], current["sharpe"]
            )
            levels.append((dict(current), len(candidates)))
            if candidates:
                return candidates[:2000], current, levels, False

            changed = False
            for key in order:
                if current[key] > mins[key]:
                    if key == "result_2":
                        current[key] = max(mins[key], current[key] - self._configured("result_2_step", 0.5))
                    elif key == "profitability":
                        current[key] = max(mins[key], current[key] - self._configured("profitability_step", 0.5))
                    elif key == "recovery":
                        current[key] = max(mins[key], current[key] - self._configured("recovery_step", 0.5))
                    else:
                        current[key] = max(mins[key], current[key] * self._configured("sharpe_step_factor", 0.9))
                    changed = True
                    break
            if not changed:
                # No acceptable candidate even at the configured minima.
                # The caller must continue the optimization rather than fail.
                return [], current, levels, True

    def best_up_to_1000(self):
        """Return the adaptive narrowing pool, up to 2000 records.

        Kept for compatibility; best200()/best_up_to_1000() intentionally use
        the existing 2000-record pool size.
        """
        candidates = self._base_filter_level()
        return candidates[:2000]

    def best1000(self):
        return self.best_up_to_1000()

    def medians(self, records, parameter_names):
        result = {}
        for name in parameter_names:
            values = []
            for row in records:
                if name not in row:
                    continue
                parsed = parse_report_number(row[name])
                if parsed is not None:
                    values.append(parsed)
            if not values:
                raise RuntimeError(f"Невозможно рассчитать медиану: параметр {name} отсутствует в результатах")
            values.sort()
            count = len(values)
            middle = count // 2
            result[name] = values[middle] if count % 2 else (values[middle - 1] + values[middle]) / 2.0
        return result
