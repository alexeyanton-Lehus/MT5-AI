import json

from project_paths import CONFIG_DIR


class StageManager:
    """Owns the fixed optimization stage sequence.

    Three optimization passes are executed: COMMON, BOTH_STAGE_1 and
    BOTH_STAGE_2. The three common parameters are optimized on every pass.
    Ranges are narrowed after COMMON and BOTH_STAGE_1. FINAL_TEST uses the
    union of all three optimization result tables.
    """

    REQUIRED_SEQUENCE = (
        "COMMON",
        "BOTH_STAGE_1",
        "BOTH_STAGE_2",
        "FINAL_TEST",
    )

    def __init__(self):
        file = CONFIG_DIR / "stages.json"
        with open(file, "r", encoding="utf-8") as f:
            self.stages = json.load(f)

        names = tuple(stage.get("name") for stage in self.stages)
        if names != self.REQUIRED_SEQUENCE:
            raise RuntimeError(
                "Некорректный config/stages.json. Ожидается последовательность: "
                + " -> ".join(self.REQUIRED_SEQUENCE)
                + "; получено: " + " -> ".join(str(name) for name in names)
            )
        self.index = 0

    def has_next(self):
        return self.index < len(self.stages)

    def current(self):
        return self.stages[self.index] if self.has_next() else None

    def next(self):
        stage = self.current()
        if stage is None:
            raise RuntimeError("Попытка перейти за пределы списка этапов.")
        self.index += 1
        return stage

    def reset(self):
        self.index = 0
