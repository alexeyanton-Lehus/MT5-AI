from pathlib import Path
from shutil import copy2
import json
import shutil
import time


class ReportManager:

    def __init__(
        self,
        terminal_dir
    ):

        self.terminal_dir = Path(
            terminal_dir
        )

    # =========================================================
    # DIRECTORIES
    # =========================================================

    def reports_dir(
        self,
        pair
    ):

        path = (
            self.terminal_dir
            / "reports"
            / pair["symbol"]
        )

        path.mkdir(
            parents=True,
            exist_ok=True
        )

        return path

    # ---------------------------------------------------------

    def tests_dir(
        self,
        pair
    ):

        path = (
            self.reports_dir(pair)
            / "tests"
        )

        path.mkdir(
            parents=True,
            exist_ok=True
        )

        return path

    # =========================================================
    # OPTIMIZATION REPORT
    # =========================================================

    def optimization_xml(
        self,
        pair
    ):

        return (
            self.reports_dir(pair)
            / "optimization.xml"
        )

    # =========================================================
    # PASS NUMBER
    # =========================================================

    @staticmethod
    def pass_number(
        candidate
    ):

        return int(
            float(
                candidate["Pass"]
            )
        )

    # =========================================================
    # SINGLE TEST REPORT
    # =========================================================

    def single_test_htm(
        self,
        pair,
        candidate,
        stage=None
    ):

        number = self.pass_number(
            candidate
        )

        symbol = pair["symbol"]

        return (
            self.tests_dir(pair)
            / (
                f"SINGLE_"
                f"{symbol}_"
                f"Pass_{number}.htm"
            )
        )

    # =========================================================
    # SOURCE REPORT
    #
    # MT5 creates the report directly here.
    # =========================================================

    def source_single_test_htm(
        self,
        pair,
        candidate
    ):

        return self.single_test_htm(
            pair,
            candidate
        )

    # =========================================================
    # REMOVE OLD REPORT
    # =========================================================

    def remove_single_test_report(
        self,
        pair,
        candidate
    ):

        report = (
            self.single_test_htm(
                pair,
                candidate
            )
        )

        if not report.exists():

            return

        try:

            report.unlink()

            print(
                "\nСтарый одиночный отчёт удалён:"
            )

            print(
                report
            )

        except PermissionError as e:

            raise RuntimeError(
                "\nНевозможно удалить "
                "старый отчёт.\n"
                f"{report}"
            ) from e

    # =========================================================
    # REMOVE ALL SINGLE TEST ARTIFACTS
    # =========================================================

    def remove_single_test_artifacts(
        self,
        pair,
        candidate
    ):

        number = self.pass_number(candidate)
        symbol = pair["symbol"]
        prefix = f"SINGLE_{symbol}_Pass_{number}"

        tests_dir = self.tests_dir(pair)

        if not tests_dir.exists():
            return

        deleted = 0

        for item in list(tests_dir.iterdir()):

            if not item.name.startswith(prefix):
                continue

            try:
                if item.is_dir():
                    shutil.rmtree(item)
                else:
                    item.unlink()

                deleted += 1

            except PermissionError as e:
                raise RuntimeError(
                    "\nНевозможно удалить одиночный отчёт:\n"
                    f"{item}"
                ) from e

        if deleted:
            print(
                f"\nУдалены старые файлы Pass={number}: "
                f"{deleted}"
            )

    # =========================================================
    # CLEAR ALL SINGLE TEST REPORTS
    # =========================================================

    def clear_tests(self, pair):

        tests_dir = self.tests_dir(pair)

        deleted = 0

        for item in list(tests_dir.iterdir()):

            try:
                if item.is_dir():
                    shutil.rmtree(item)
                else:
                    item.unlink()

                deleted += 1

            except PermissionError as e:
                raise RuntimeError(
                    "\nНевозможно очистить папку tests:\n"
                    f"{item}"
                ) from e

        print(
            f"\nОчистка tests/{pair['symbol']}: "
            f"удалено объектов {deleted}"
        )

    # =========================================================
    # WAIT FOR MT5 REPORT
    # =========================================================

    def wait_for_single_test_report(
        self,
        pair,
        candidate,
        timeout=60
    ):

        report = (
            self.source_single_test_htm(
                pair,
                candidate
            )
        )

        number = self.pass_number(
            candidate
        )

        deadline = (
            time.time()
            + timeout
        )

        last_size = -1
        stable_count = 0

        print(
            "\nОжидание исходного HTM отчёта MT5:"
        )

        print(
            report
        )

        while time.time() < deadline:

            if report.exists():

                try:

                    size = report.stat().st_size

                except OSError:

                    size = -1

                if size > 0:

                    if size == last_size:

                        stable_count += 1

                    else:

                        stable_count = 0
                        last_size = size

                    # MT5 has already reported the test as finished.
                    # Require two unchanged observations with a short interval
                    # instead of an unnecessary multi-second pause.
                    if stable_count >= 2:

                        print(
                            "\nПолный HTM отчёт найден:"
                        )

                        print(
                            report
                        )

                        return report

            time.sleep(0.2)

        raise FileNotFoundError(
            "\nMT5 завершил тест, "
            "но исходный HTM отчёт "
            "не найден.\n"
            f"Pass = {number}\n"
            f"Ожидался:\n{report}"
        )

    # =========================================================
    # COPY TEST REPORT
    #
    # ВАЖНО:
    # source == destination.
    #
    # Поэтому НИКАКОГО copy2/unlink здесь нет.
    # MT5 уже создал окончательный файл.
    # =========================================================

    def copy_test_reports(
        self,
        pair,
        stage,
        candidate
    ):

        report = (
            self.wait_for_single_test_report(
                pair,
                candidate
            )
        )

        print(
            "\nОдиночный отчёт готов:"
        )

        print(
            report
        )

        return {
            "common": report,
            "htm": report
        }

    # =========================================================
    # PERMANENT FINAL TOP-3 TRADE REPORTS
    #
    # Для каждой валюты сохраняются три исходных SINGLE_*.htm
    # финальных TOP-3 кандидатов. REPORT.htm является копией
    # TOP-1 и используется как основной отчёт для портфельного анализа.
    # =========================================================

    def save_final_trade_report(
        self,
        pair,
        candidate,
        rank,
        set_target=None,
        ini_target=None,
    ):
        from project_paths import TRADE_REPORTS_DIR

        source = self.single_test_htm(pair, candidate)
        if not source.exists() or source.stat().st_size == 0:
            raise FileNotFoundError(
                f"Не найден завершённый SINGLE TEST отчёт для TOP-{rank}: {source}"
            )

        pair_dir = TRADE_REPORTS_DIR / pair["symbol"]
        pair_dir.mkdir(parents=True, exist_ok=True)

        # Сохраняем исходное имя, чтобы Pass был виден в названии.
        target = pair_dir / source.name
        copy2(source, target)

        # REPORT.htm — основной отчёт TOP-1.
        if int(rank) == 1:
            report_target = pair_dir / "REPORT.htm"
            copy2(source, report_target)
            print(f"Основной REPORT сохранён:\n{report_target}")

        print(f"TOP-{rank} trade report сохранён:\n{target}")
        return target

