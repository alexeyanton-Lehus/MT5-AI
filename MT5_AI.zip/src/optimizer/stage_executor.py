from pathlib import Path
from shutil import copy2
import re
from datetime import datetime
import json
import time
import traceback

from optimizer.stage_preparer import StagePreparer
from optimizer.optimization_runner import OptimizationRunner
from optimizer.candidate_selector import CandidateSelector
from optimizer.set_writer import SetWriter
from optimizer.result_selector import ResultSelector
from optimizer.range_shrinker import RangeShrinker
from optimizer.range_manager import RangeManager
from optimizer.report_cleanup import ReportCleanup
from project_paths import (
    CONFIG_DIR,
    WORKING_DIR,
    ADVISOR_SETTINGS_DIR,
    RESULTS_DIR,
)
from config_loader import load_config, load_tester_config
from optimizer.number_parser import parse_report_number
from optimizer.atr_scaler import ATRScaler
from optimizer.xml_reader import XMLReader


class StageExecutor:
    def __init__(
        self,
        stage_manager,
        mt5,
        terminal_dir,
        working_set,
        tester_settings=None,
        expert_settings=None,
        criteria_settings=None,
    ):
        self.stage_manager = stage_manager
        self.working_set = working_set
        # tester.json is the single source of truth for actual MT5 tester
        # settings (including the initial deposit). Explicit tester_settings
        # may override it only when a caller deliberately supplies them.
        self.tester_settings = dict(load_tester_config())
        if tester_settings:
            self.tester_settings.update(tester_settings)
        self.expert_settings = expert_settings or {}
        self.criteria_settings = criteria_settings or {}

        self.runner = OptimizationRunner(mt5, terminal_dir)
        self.selector = CandidateSelector(
            mt5,
            terminal_dir,
            self.criteria_settings,
        )
        # ReportManager is owned by CandidateSelector. Keep an explicit
        # reference here because StageExecutor uses it during FINAL_TEST.
        # This prevents FINAL_TEST from failing with:
        # "StageExecutor has no attribute 'reports'".
        self.reports = self.selector.reports
        self.range_manager = RangeManager()
        self.report_cleanup = ReportCleanup(terminal_dir)
        self.shrinker = RangeShrinker(
            CONFIG_DIR / "optimization_ranges.json",
            WORKING_DIR / "narrowed_ranges.json",
        )
        # optimization_ranges.json stores ATR_min_level_* in normalized
        # units, while MT5 reports the optimized value in symbol-native
        # units for symbols with fewer than 5 digits. Convert only these
        # two parameters back to normalized units before narrowing.
        self.atr_scaler = ATRScaler()

    def _force_stage_trade_direction(self, stage):
        """Write the stage direction into the actual MT5 input files.

        MT5 input enum mapping used by the EA:
            BUY_ONLY  = 0
            SELL_ONLY = 1
            BOTH      = 2

        StagePreparer currently leaves TradeDirection from the previous
        working.set, so BUY/SELL stages can accidentally run as BOTH.
        This method is deliberately called after StagePreparer and before
        any optimization/single test starts.
        """
        direction_map = {
            "BUY_ONLY": 0,
            "SELL_ONLY": 1,
            "BOTH": 2,
        }
        direction = stage.get("trade_direction", "BOTH")
        if direction not in direction_map:
            raise ValueError(
                f"Неизвестное направление stage {stage.get('name')}: {direction}"
            )

        value = str(direction_map[direction])
        files = [
            Path(WORKING_DIR) / "working.set",
            Path(WORKING_DIR) / "working.ini",
        ]

        for path in files:
            if not path.exists():
                continue

            # working.set / working.ini are UTF-16 in this project.
            # Fall back to UTF-8 only if an external/manual file is supplied.
            try:
                text = path.read_text(encoding="utf-16")
                encoding = "utf-16"
            except UnicodeError:
                text = path.read_text(encoding="utf-8")
                encoding = "utf-8"

            lines = text.splitlines(keepends=True)
            found = False
            out = []

            for line in lines:
                if line.lstrip().startswith("TradeDirection="):
                    newline = "\r\n" if line.endswith("\r\n") else "\n" if line.endswith("\n") else ""
                    # Preserve MT5 optimization syntax in SET/INI.
                    parts = line.rstrip("\r\n").split("=", 1)
                    current = parts[1]
                    suffix = ""
                    if "||" in current:
                        suffix = "||" + current.split("||", 1)[1]
                    out.append(f"TradeDirection={value}{suffix}{newline}")
                    found = True
                else:
                    out.append(line)

            if not found:
                # Insert into [TesterInputs] if the key is missing.
                inserted = False
                out2 = []
                in_inputs = False
                for line in out:
                    stripped = line.strip()
                    if stripped.lower() == "[testerinputs]":
                        in_inputs = True
                        out2.append(line)
                        continue
                    if in_inputs and stripped.startswith("[") and stripped.endswith("]"):
                        if not inserted:
                            out2.append(f"TradeDirection={value}||0||0||2||N\n")
                            inserted = True
                        in_inputs = False
                    out2.append(line)
                if in_inputs and not inserted:
                    out2.append(f"TradeDirection={value}||0||0||2||N\n")
                    inserted = True
                out = out2

            path.write_text("".join(out), encoding=encoding)

        print(
            f"TradeDirection принудительно установлен: {direction} ({value}) "
            f"для stage {stage.get('name')}"
        )

    @staticmethod
    def _active_parameters(stage):
        optimize = stage.get("optimize", [])

        if optimize == "BUY":
            return list(StagePreparer.BUY_PARAMETERS)

        if optimize == "SELL":
            return list(StagePreparer.SELL_PARAMETERS)

        if optimize == "BOTH":
            # BOTH includes the three common parameters and the complete
            # BUY + SELL parameter set.
            return (
                list(StagePreparer.COMMON_PARAMETERS)
                + list(StagePreparer.BUY_PARAMETERS)
                + list(StagePreparer.SELL_PARAMETERS)
            )

        if isinstance(optimize, (list, tuple, set)):
            return list(optimize)

        raise RuntimeError(
            f"Неизвестное значение optimize для stage {stage.get('name')}: {optimize!r}"
        )

    def _source_ranges_for_shrink(self, stage, pair, parameters):
        # COMMON is narrowed from the original ranges. BOTH_STAGE_1 is then
        # narrowed from the ranges produced by COMMON. BOTH_STAGE_2 is the last
        # optimization pass and does not perform another narrowing.
        if stage["name"] == "BOTH_STAGE_1":
            source = self.shrinker.load("BOTH")
        elif stage["name"] in ("BUY_STAGE_2", "BUY_STAGE_3"):
            source = self.shrinker.load("BUY")
        elif stage["name"] in ("SELL_STAGE_2", "SELL_STAGE_3"):
            source = self.shrinker.load("SELL")
        else:
            source = {}
            for name in parameters:
                if name in self.expert_settings:
                    settings = self.expert_settings[name]
                    source[name] = {
                        "start": settings["start"],
                        "step": settings["step"],
                        "stop": settings["end"],
                    }
                else:
                    rng = self.range_manager.get(name)
                    if rng is not None:
                        source[name] = rng

        missing = [name for name in parameters if name not in source]
        if missing:
            raise KeyError(
                "Нет исходного диапазона для параметров: "
                + ", ".join(missing)
            )

        return {name: source[name] for name in parameters}

    def _save_median_ranges(self, stage, records, pair):
        direction = (
            "BUY"
            if stage["trade_direction"] == "BUY_ONLY"
            else "SELL"
            if stage["trade_direction"] == "SELL_ONLY"
            else "BOTH"
        )
        parameters = self._active_parameters(stage)

        selector = ResultSelector(records, self.criteria_settings)
        top1000, used_level, levels, exhausted = selector.adaptive_narrowing_candidates()

        print(
            f"NARROWING {pair['symbol']} {stage['name']} {direction}: "
            f"кандидатов={len(top1000)} | уровень="
            f"Result№2>{used_level['result_2']:.4g}, PF>{used_level['profitability']:.4g}, "
            f"RF>{used_level['recovery']:.4g}, Sharpe>{used_level['sharpe']:.4g}"
        )

        if not top1000:
            # Even the minimum adaptive criteria produced no valid candidate.
            # Do not abort the currency: preserve the source ranges so the next
            # optimization stage can still run.
            source_ranges = self._source_ranges_for_shrink(stage, pair, parameters)
            self.shrinker.save(direction, source_ranges)
            print(
                f"NARROWING {pair['symbol']} {stage['name']} {direction}: "
                "кандидатов нет даже на минимальном уровне; диапазоны сохранены без сужения."
            )
            return {
                "record": None,
                "medians": {},
                "narrowed": source_ranges,
                "FallbackRecord": None,
                "AdaptiveLevel": used_level,
                "AdaptiveLevels": levels,
                "NoCandidateAtMinimum": True,
            }

        medians = selector.medians(top1000, parameters)

        # Keep RangeShrinker entirely on the normalized scale used by
        # optimization_ranges.json. MT5 returns ATR_min_level_* in native
        # price units, so convert those medians back before narrowing.
        # For 5-digit symbols the scaler factor is 1.0, therefore existing
        # behavior is unchanged. Do not modify the original medians dict:
        # it is also used below for diagnostics/fallback artifacts.
        shrink_medians = dict(medians)
        for name in (
            "ATR_min_level_for_buy",
            "ATR_min_level_for_sell",
        ):
            if name in shrink_medians:
                shrink_medians[name] = self.atr_scaler.native_to_normalized(
                    shrink_medians[name], pair["symbol"]
                )

        source_ranges = self._source_ranges_for_shrink(
            stage,
            pair,
            parameters,
        )

        narrowed = self.shrinker.build(
            parameters,
            shrink_medians,
            source_ranges=source_ranges,
        )
        self.shrinker.save(direction, narrowed)

        print(
            f"\n========== МЕДИАНА TOP-{len(top1000)} {direction} =========="
        )
        for name in parameters:
            print(f"{name:35} median={medians[name]}")

        print(f"\n========== СУЖЕНЫЕ ДИАПАЗОНЫ {direction} ==========")
        for name in parameters:
            rng = narrowed[name]
            print(
                f"{name:35} "
                f"{rng['start']} || {rng['step']} || {rng['stop']}"
            )

        # Keep the highest-ranked valid optimization record. It is also a
        # valid source for FINAL cross-combinations if the corresponding
        # single-test stage later produces no candidates.
        fallback_file = WORKING_DIR / f"last_successful_{direction.lower()}_candidate.json"
        fallback_file.write_text(
            json.dumps(
                {
                    "stage": stage["name"],
                    "direction": direction,
                    "record": top1000[0],
                },
                indent=2,
                ensure_ascii=False,
                default=str,
            ),
            encoding="utf-8",
        )
        return {
            "record": top1000[0],
            "medians": medians,
            "narrowed": narrowed,
            "FallbackRecord": top1000[0],
        }

    @staticmethod
    def _read_set_values():
        values = {}
        path = Path(WORKING_DIR) / "working.set"

        with open(path, "r", encoding="utf-16") as f:
            for line in f:
                if "=" not in line:
                    continue

                name, rest = line.rstrip("\r\n").split("=", 1)
                values[name] = rest.split("||", 1)[0]

        return values

    @staticmethod
    def _write_set_values(values):
        """Write values back to working.set, preserving optimization syntax."""
        path = Path(WORKING_DIR) / "working.set"
        
        with open(path, "r", encoding="utf-16") as f:
            lines = f.readlines()
        
        out_lines = []
        for line in lines:
            if "=" in line:
                name, rest = line.rstrip("\r\n").split("=", 1)
                if name in values:
                    # Preserve optimization syntax if present
                    if "||" in rest:
                        parts = rest.split("||", 1)
                        new_line = f"{name}={values[name]}||{parts[1]}\n"
                    else:
                        new_line = f"{name}={values[name]}\n"
                    out_lines.append(new_line)
                else:
                    out_lines.append(line)
            else:
                out_lines.append(line)
        
        with open(path, "w", encoding="utf-16") as f:
            f.writelines(out_lines)

    def _single_test_stats(self, pair):
        # Pass=-1 is a synthetic id. The test uses current working.set.
        report = self.selector.runner.run_single(
            pair,
            {"Pass": -1},
        )

        if self.selector.mt5.is_running():
            self.selector.mt5.stop_terminal()

        report = self.selector.reports.wait_for_single_test_report(
            pair,
            {"Pass": -1},
            timeout=60,
        )

        return self.selector.reader.read(report), report

    def _passes_final(self, stats):
        """Compatibility wrapper around CandidateSelector's single-test verdict."""
        stage = {"name": "FINAL_TEST", "trade_direction": "BOTH"}
        failed = self.selector._failed_criteria(stats, stage)
        for name in failed:
            print(f"FINAL_TEST: не пройден критерий {name}")
        return not failed

    @staticmethod
    def _format_filename_number(value, decimals=None):
        try:
            number = float(value)
        except (TypeError, ValueError):
            return str(value).strip()

        if decimals is not None:
            return f"{number:.{decimals}f}"

        if number.is_integer():
            return str(int(number))

        return f"{number:.10f}".rstrip("0").rstrip(".")

    @staticmethod
    def _filename_period(value):
        """Convert YYYY.MM.DD / YYYY-MM-DD to MMYYYY."""
        match = re.search(r"(\d{4})[.\-/](\d{2})", str(value))
        if not match:
            raise ValueError(f"Некорректная дата для имени файла: {value}")
        return f"{match.group(2)}{match.group(1)}"

    @staticmethod
    def _equity_drawdown_relative(stats):
        """Return MT5 Equity Drawdown Relative from any supported report shape.

        Optimization XML uses ``Equity DD %`` while single-test HTML is
        normalized to ``Equity Drawdown Relative``. Never fall back to the
        generic Balance/Equity Drawdown field.
        """
        if not isinstance(stats, dict):
            return 0.0
        for key in (
            "Equity Drawdown Relative",
            "Equity DD %",
            "Относительная просадка по средствам",
            "Относительная просадка за средствами",
            "Відносна просадка за коштами",
        ):
            value = stats.get(key)
            parsed = parse_report_number(value)
            if parsed is not None:
                return parsed
        return 0.0

    def _final_filename(self, pair, stats, set_values=None):
        """Build the exact final SET/INI basename from the project TЗ.

        Example:
        EURUSD-RSI+MA-martin-adaptiv-V13-H4-012015+072026-
        100%balance-25%load-5curr-5%-5orders-
        15000pln+9240pln-10.2%DD
        """
        # Use the exact parameter values of the candidate being saved.
        # Falling back to working.set is kept for compatibility with callers
        # that do not pass an explicit candidate.
        values = set_values if set_values is not None else self._read_set_values()
        cfg = load_config()
        tester_cfg = self.tester_settings

        # Filename period MUST match the dates actually written to the MT5
        # tester configuration. Read the current working.ini first; this avoids
        # stale/default config dates in the filename.
        from_date = None
        to_date = None
        working_ini = Path(WORKING_DIR) / "working.ini"
        if working_ini.exists():
            try:
                text = working_ini.read_text(encoding="utf-16")
                m = re.search(r"(?m)^FromDate=(.+)$", text)
                if m:
                    from_date = m.group(1).strip()
                m = re.search(r"(?m)^ToDate=(.+)$", text)
                if m:
                    to_date = m.group(1).strip()
            except (OSError, UnicodeError):
                pass
        if not from_date:
            from_date = self.tester_settings.get(
                "from_date", tester_cfg.get("from_date", "2024.01.01")
            )
        if not to_date:
            to_date = self.tester_settings.get(
                "to_date", tester_cfg.get("to_date", "")
            )
        if not to_date or str(to_date).lower() == "today":
            to_date = datetime.today().strftime("%Y.%m.%d")

        deposit = self.tester_settings["deposit"]
        currency = self.tester_settings.get("currency", "PLN")
        timeframe = cfg.get("timeframe", tester_cfg.get("period", "H4"))
        expert = cfg.get("expert_name", "RSI+MA-martin-adaptiv-V13")

        profit = self.selector.f(stats.get("Profit"))
        dd = self._equity_drawdown_relative(stats)

        balance_pct = self._format_filename_number(
            values.get("RiskCapitalPercent", "")
        )
        load_pct = self._format_filename_number(
            values.get("MaxMarginUsagePercent", "")
        )
        currencies = self._format_filename_number(
            values.get("MaxActiveSymbols", "")
        )
        risk_pct = self._format_filename_number(
            values.get("RiskPercent", "")
        )
        orders = self._format_filename_number(
            values.get("MaxOrdersGrid", "")
        )

        # Direction prefix is used only for one-direction final settings.
        # BOTH keeps the existing filename format; BUY/SELL are explicit so
        # a saved one-sided EA can never be mistaken for a BOTH configuration.
        direction_prefix = {
            "0": "BUY-",
            "1": "SELL-",
        }.get(str(values.get("TradeDirection", "2")).strip(), "")

        # ТЗ: [direction-]symbol-EA-timeframe-period-balance-load-curr-risk-orders-
        # deposit+PROFIT-DD. Второе числовое значение после депозита —
        # именно чистая прибыль Profit, а не конечный баланс.
        return (
            f"{direction_prefix}{pair['symbol']}-{expert}-{timeframe}-"
            f"{self._filename_period(from_date)}+{self._filename_period(to_date)}-"
            f"{balance_pct}%balance-"
            f"{load_pct}%load-"
            f"{currencies}curr-"
            f"{risk_pct}%-"
            f"{orders}orders-"
            f"{self._format_filename_number(deposit)}{str(currency).lower()}+"
            f"{int(round(profit))}{str(currency).lower()}-"
            f"{dd:.1f}%DD"
        )

    @staticmethod
    def _make_unique_target(directory, filename, rank):
        """Keep the TЗ name; add rank only if two results have identical names."""
        target = Path(directory) / filename
        if not target.exists():
            return target

        stem = target.stem
        suffix = target.suffix
        return Path(directory) / f"{stem}-TOP{rank}{suffix}"

    def _save_final_artifacts(self, pair, stats, rank, set_values=None):
        """Save one final passed candidate as both SET and INI.

        ``set_values`` is the exact merged candidate state that was tested.
        It is used for the filename so RiskPercent/MaxOrdersGrid cannot be
        taken accidentally from a stale working.set.
        """
        ADVISOR_SETTINGS_DIR.mkdir(parents=True, exist_ok=True)
        from project_paths import TESTER_INI_SETTINGS_DIR
        TESTER_INI_SETTINGS_DIR.mkdir(parents=True, exist_ok=True)

        # Filename metadata MUST come from the exact candidate state that
        # was just written/tested, never from a stale working.set.
        current_set_values = dict(set_values) if set_values is not None else self._read_set_values()
        base = self._final_filename(pair, stats, current_set_values)
        set_name = f"{base}.set"
        ini_name = f"{base}.ini"

        set_target = self._make_unique_target(
            ADVISOR_SETTINGS_DIR,
            set_name,
            rank,
        )
        ini_target = self._make_unique_target(
            TESTER_INI_SETTINGS_DIR,
            ini_name,
            rank,
        )

        working_set = Path(WORKING_DIR) / "working.set"
        working_ini = Path(WORKING_DIR) / "working.ini"

        if not working_set.exists():
            raise RuntimeError(f"Не найден SET для сохранения: {working_set}")

        # Rebuild working.ini FROM THE CURRENT working.set before copying it.
        # Otherwise every final INI could contain parameters of the last tested
        # combination instead of the TOP candidate being saved now.
        self.selector.runner.builder.build_single_test(
            pair,
            -int(rank),
        )

        if not working_ini.exists():
            raise RuntimeError(f"Не удалось создать INI для сохранения: {working_ini}")

        copy2(working_set, set_target)

        # Make the permanent INI independently usable for a single test.
        text = working_ini.read_text(encoding="utf-16")
        lines = text.splitlines(keepends=True)
        out = []
        for line in lines:
            stripped = line.strip()
            if stripped.startswith("Optimization="):
                newline = "\r\n" if line.endswith("\r\n") else "\n"
                out.append(f"Optimization=0{newline}")
            elif stripped.startswith("Report="):
                newline = "\r\n" if line.endswith("\r\n") else "\n"
                report_rel = (
                    Path("reports")
                    / pair["symbol"]
                    / "tests"
                    / f"FINAL_{Path(base).stem}"
                )
                out.append(f"Report={str(report_rel).replace('/', chr(92))}{newline}")
            elif stripped.startswith("ReplaceReport="):
                newline = "\r\n" if line.endswith("\r\n") else "\n"
                out.append(f"ReplaceReport=1{newline}")
            elif stripped.startswith("ShutdownTerminal="):
                newline = "\r\n" if line.endswith("\r\n") else "\n"
                out.append(f"ShutdownTerminal=0{newline}")
            else:
                out.append(line)

        ini_target.write_text("".join(out), encoding="utf-16")

        # Verify both permanent artifacts really exist and are non-empty
        # before reporting this candidate as saved.
        if not set_target.exists() or set_target.stat().st_size == 0:
            raise RuntimeError(f"SET не создан или пустой: {set_target}")
        if not ini_target.exists() or ini_target.stat().st_size == 0:
            raise RuntimeError(f"INI не создан или пустой: {ini_target}")

        print(f"\nTOP-{rank} SET сохранён:\n{set_target}")
        print(f"TOP-{rank} INI сохранён:\n{ini_target}\n")

        return set_target, ini_target

    def _cleanup_old(self):
        cutoff = datetime.now().timestamp() - 30 * 24 * 3600
        roots = [
            WORKING_DIR,
            RESULTS_DIR,
            Path("logs"),
        ]

        for root in roots:
            root = Path(root)

            if not root.exists():
                continue

            for item in root.rglob("*"):
                try:
                    if (
                        item.is_file()
                        and item.stat().st_mtime < cutoff
                    ):
                        item.unlink()
                except OSError:
                    pass

    @staticmethod
    def _candidate_identity(candidate):
        """Unique identity for a row from the combined optimization tables.

        MT5 Pass numbers restart at 0 for every optimization stage, so Pass
        alone is not a safe identifier after COMMON + BOTH_STAGE_1 + BOTH_STAGE_2
        are merged.
        """
        return (
            str(candidate.get("_source_stage", "")),
            str(candidate.get("Pass", "")),
        )

    def execute(self, pair):
        stage = self.stage_manager.current()
        preparer = StagePreparer(
            self.stage_manager,
            self.working_set,
            pair,
            self.expert_settings,
        )
        preparer.prepare()
        self._force_stage_trade_direction(stage)

        # All three common parameters are optimized together with the full
        # BUY+SELL parameter set on every optimization pass. COMMON is the
        # first pass; its ranges are narrowed for BOTH_STAGE_1, then narrowed
        # again for BOTH_STAGE_2. No common values are frozen/copied between
        # stages.
        if stage["name"] in ("COMMON", "BOTH_STAGE_1", "BOTH_STAGE_2"):
            records = self.runner.run(pair, stage)

            # Narrow after COMMON and after BOTH_STAGE_1. BOTH_STAGE_2 is the
            # last optimization pass, so there is no third narrowing.
            if stage["name"] in ("COMMON", "BOTH_STAGE_1"):
                shrink_result = self._save_median_ranges(stage, records, pair)
                return {
                    "Stage": stage["name"],
                    "Records": len(records),
                    "NarrowingPool": len(shrink_result.get("medians", {})) if shrink_result.get("NoCandidateAtMinimum") else len(
                        ResultSelector(records, self.criteria_settings).adaptive_narrowing_candidates()[0]
                    ),
                    "Narrowed": shrink_result.get("narrowed", {}),
                    "Median": shrink_result.get("medians", {}),
                }

            return {
                "Stage": stage["name"],
                "Records": len(records),
                "Status": "OPTIMIZATION_COMPLETE",
            }

        # FINAL_TEST: adaptive first-stage criteria over the COMPLETE optimization
        # result list. At every level candidates are ranked by Maximum Profit,
        # TOP-200 are selected, and single tests run in that order until the
        # first three candidates pass ALL second-stage criteria. If none pass,
        # the existing adaptive mechanism relaxes exactly one criterion and
        # starts again with the next level.
        if stage["name"] == "FINAL_TEST":
            # Use the UNION of every completed optimization table. Strong
            # passes found in COMMON must participate in FINAL_TEST together
            # with passes found in BOTH_STAGE_1 and BOTH_STAGE_2.
            all_records = []
            reports_dir = self.runner.terminal_dir / "reports" / pair["symbol"]
            optimization_stages = ("COMMON", "BOTH_STAGE_1", "BOTH_STAGE_2")

            for source_stage in optimization_stages:
                report_path = reports_dir / f"optimization_{source_stage}.xml"
                if not report_path.exists():
                    raise RuntimeError(
                        f"FINAL_TEST: не найден отчёт оптимизации {source_stage}: {report_path}"
                    )

                stage_records = XMLReader(report_path).load()
                for record in stage_records:
                    row = dict(record)
                    row["_source_stage"] = source_stage
                    all_records.append(row)

            if not all_records:
                return {"Status": "NO_VALID_CANDIDATES", "SavedFiles": [], "SavedIniFiles": [], "SavedTop3": 0}

            combined_file = WORKING_DIR / "combined_optimization_results.json"
            combined_file.write_text(
                json.dumps(all_records, indent=2, ensure_ascii=False, default=str),
                encoding="utf-8",
            )
            print(
                f"FINAL_TEST: объединены результаты {', '.join(optimization_stages)}: "
                f"{len(all_records)} записей."
            )

            selector = ResultSelector(all_records, self.criteria_settings)
            collected = []
            level_log = []
            tested_passes = set()

            # Each adaptive level starts from the complete combined table,
            # already ranked by optimization Profit. The first strict level
            # uses exactly the configured initial criteria. Single tests are
            # taken in batches of TOP-10. If fewer than the required number
            # pass, continue with candidates 11, 12, ... from the SAME
            # filtered list before relaxing the criteria.
            for level_no, level in enumerate(selector.adaptive_levels(), 1):
                if len(collected) >= 3:
                    break

                candidates = selector.filter_level(
                    level["result_2"], level["profitability"],
                    level["recovery"], level["sharpe"]
                )
                print(
                    f"FINAL_TEST LEVEL {level_no}: Result№2>{level['result_2']:.4g}, "
                    f"Profitability>{level['profitability']:.4g}, "
                    f"RF>{level['recovery']:.4g}, Sharpe>{level['sharpe']:.4g}; "
                    f"кандидатов={len(candidates)}"
                )

                level_tested = 0
                level_passed_count = 0
                next_index = 0

                while next_index < len(candidates) and len(collected) < 3:
                    # TOP-10 is the size of each single-test selection batch.
                    # If it does not yield enough passes, continue with the
                    # next candidates from the same ranked filtered list.
                    batch = []
                    while next_index < len(candidates) and len(batch) < 10:
                        row = candidates[next_index]
                        next_index += 1
                        identity = self._candidate_identity(row)
                        if identity in tested_passes:
                            continue
                        batch.append(row)

                    if not batch:
                        break

                    before_tested = set(tested_passes)
                    level_passed = self.selector.select_batch(
                        pair, stage, batch, target_valid=3 - len(collected)
                    )

                    # CandidateSelector stops as soon as the remaining target
                    # is reached. Mark candidates actually represented in the
                    # diagnostic file for this invocation; successful ones are
                    # added to the final collection in Profit order.
                    for item in level_passed:
                        candidate = item.get("candidate", {})
                        pass_id = self._candidate_identity(candidate)
                        if pass_id not in {self._candidate_identity(x.get("candidate", {})) for x in collected}:
                            collected.append(item)
                        tested_passes.add(pass_id)

                    diagnostic_file = WORKING_DIR / "single_test_diagnostics" / f"{stage['name']}.jsonl"
                    batch_tested_ids = set()
                    if diagnostic_file.exists():
                        try:
                            for line in diagnostic_file.read_text(encoding="utf-8").splitlines():
                                if not line.strip():
                                    continue
                                entry = json.loads(line)
                                candidate = entry.get("candidate", {})
                                if candidate:
                                    cid = self._candidate_identity(candidate)
                                    if cid not in before_tested:
                                        batch_tested_ids.add(cid)
                        except (OSError, json.JSONDecodeError):
                            pass
                    tested_passes.update(batch_tested_ids)
                    level_tested += len(batch_tested_ids)
                    level_passed_count += len(level_passed)

                    # If select_batch stopped before consuming the complete
                    # batch because the target was reached, the outer condition
                    # ends the process. Otherwise the next batch starts at the
                    # next ranked candidate (11th, 12th, ...).

                level_log.append({
                    "level": level_no,
                    "criteria": level,
                    "optimization_candidates": len(candidates),
                    "single_test_batch_size": 10,
                    "single_tests_run": level_tested,
                    "single_test_passed": level_passed_count,
                    "total_collected": len(collected),
                })

            if len(collected) > 3:
                collected = collected[:3]

            if not collected:
                audit_file = WORKING_DIR / f"final_artifact_audit_{pair['symbol']}.json"
                audit_file.write_text(json.dumps({
                    "symbol": pair["symbol"],
                    "status": "NO_FINAL_PASS",
                    "levels": level_log,
                }, indent=2, ensure_ascii=False), encoding="utf-8")
                self._append_pair_log(
                    f"{pair['symbol']} | NO_FINAL_PASS | достигнуты минимумы первого механизма"
                )
                return {
                    "Status": "NO_FINAL_PASS",
                    "SavedFiles": [],
                    "SavedIniFiles": [],
                    "SavedTop3": 0,
                    "Levels": level_log,
                    "AuditFile": str(audit_file),
                }

            # ``collected`` is already in optimization Profit order because
            # CandidateSelector tests TOP-200 in that order and stops on the
            # first three single-test passes. Preserve that order for TOP-1/2/3.
            top3 = collected[:3]

            saved_files = []
            saved_ini_files = []
            save_attempts = []
            for rank, item in enumerate(top3, 1):
                candidate = item.get("candidate", {})
                stats = item.get("stats", {})
                set_values = self._read_set_values()
                for key, value in candidate.items():
                    if key in set_values:
                        set_values[key] = str(value)
                set_values["TradeDirection"] = "2"
                self._write_set_values(set_values)
                try:
                    set_target, ini_target = self._save_final_artifacts(pair, stats, rank, set_values=set_values)
                    report_target = self.reports.save_final_trade_report(
                        pair,
                        candidate,
                        rank,
                        set_target=set_target,
                        ini_target=ini_target,
                    )
                    saved_files.append(str(set_target))
                    saved_ini_files.append(str(ini_target))
                    save_attempts.append({
                        "rank": rank,
                        "status": "SAVED",
                        "set": str(set_target),
                        "ini": str(ini_target),
                        "trade_report": str(report_target),
                        "pass": candidate.get("Pass"),
                        "profit": self.selector.f(stats.get("Profit")),
                    })
                except Exception as exc:
                    save_attempts.append({"rank": rank, "status": "ERROR", "pass": candidate.get("Pass"), "error": str(exc)})
                    print(f"FINAL_TEST: не удалось сохранить TOP-{rank}: {exc}")

            audit_file = WORKING_DIR / f"final_artifact_audit_{pair['symbol']}.json"
            audit_file.write_text(json.dumps({
                "symbol": pair["symbol"],
                "source": "ADAPTIVE_OPTIMIZATION",
                "selected": len(top3),
                "saved": len(saved_files),
                "levels": level_log,
                "save_attempts": save_attempts,
            }, indent=2, ensure_ascii=False, default=str), encoding="utf-8")

            self.report_cleanup.cleanup_pair(pair["symbol"])
            self._cleanup_old()
            return {
                "Status": "BOTH",
                "FinalStats": [item.get("stats", {}) for item in top3],
                "SavedFiles": saved_files,
                "SavedIniFiles": saved_ini_files,
                "TradeReports": [x.get("trade_report") for x in save_attempts if x.get("trade_report")],
                "SavedTop3": len(saved_files),
                "TestedCandidates": sum(x["single_test_passed"] for x in level_log),
                "Levels": level_log,
                "AuditFile": str(audit_file),
            }

        raise RuntimeError(f"Неизвестный этап: {stage.get('name')}")

