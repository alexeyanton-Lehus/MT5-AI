import json
import math
from pathlib import Path


REFERENCE_ATR3 = 0.01

# Values taken directly from Appendix B (application B).
# coefficient: Stop = REFERENCE_ATR3 * coefficient.
# min_step/start_step are native MT5 price increments for the pair.
PAIR_SETTINGS = {
    "EURUSD": (1, 0.00002, 0.00008), "GBPUSD": (1, 0.00002, 0.00008),
    "USDCHF": (1, 0.00002, 0.00008), "USDJPY": (300, 0.002, 0.008),
    "EURJPY": (300, 0.002, 0.008), "EURCHF": (1, 0.00002, 0.00008),
    "GBPCHF": (1, 0.00002, 0.00008), "EURGBP": (1, 0.00002, 0.00008),
    "AUDUSD": (1, 0.00002, 0.00008), "NZDUSD": (1, 0.00002, 0.00008),
    "USDCAD": (1, 0.00002, 0.00008), "EURCAD": (1, 0.00002, 0.00008),
    "NZDCAD": (1, 0.00002, 0.00008), "GBPCAD": (1, 0.00002, 0.00008),
    "AUDCAD": (1, 0.00002, 0.00008), "EURAUD": (1, 0.00002, 0.00008),
    "GBPAUD": (1, 0.00002, 0.00008), "EURNZD": (1, 0.00002, 0.00008),
    "GBPNZD": (1, 0.00002, 0.00008), "AUDNZD": (1, 0.00002, 0.00008),
    "NZDCHF": (1, 0.00002, 0.00008), "CADCHF": (1, 0.00002, 0.00008),
    "AUDCHF": (1, 0.00002, 0.00008), "CADJPY": (300, 0.002, 0.008),
    "GBPJPY": (400, 0.002, 0.008), "NZDJPY": (200, 0.002, 0.008),
    "AUDJPY": (200, 0.002, 0.008), "CHFJPY": (300, 0.002, 0.008),
    "USDDKK": (10, 0.0002, 0.0008), "USDSEK": (20, 0.0002, 0.0008),
    "EURPLN": (10, 0.0002, 0.0008), "EURNOK": (10, 0.0002, 0.0008),
    "USDPLN": (10, 0.0002, 0.0008), "USDHUF": (1000, 0.02, 0.08),
    "EURHUF": (1000, 0.02, 0.08), "CHFHUF": (1000, 0.02, 0.08),
    "GBPHUF": (1000, 0.02, 0.08), "USDZAR": (40, 0.0002, 0.0008),
    "EURZAR": (30, 0.0002, 0.0008), "USDMXN": (30, 0.0002, 0.0008),
    "GBPSEK": (30, 0.0002, 0.0008), "EURILS": (10, 0.0002, 0.0008),
    "GBPILS": (10, 0.0002, 0.0008), "GBPSGD": (1, 0.0002, 0.0008),
    "USDILS": (10, 0.0002, 0.0008), "USDSGD": (1, 0.00002, 0.00008),
    "EURSEK": (10, 0.0002, 0.0008), "USDNOK": (10, 0.0002, 0.0008),
}


class ATRScaler:
    """Apply the pair-specific ATR range rules from Appendix B.

    The normalized internal ATR scale is based on EURUSD = 0.01.
    Only the stop is scaled to the pair: native Stop = 0.01 * coefficient.
    Start is always zero. The initial and minimum native steps come from
    Appendix B and are kept as price increments, independent of the ATR
    coefficient.
    """

    def __init__(self, config_file=None):
        if config_file is None:
            config_file = Path("config/atr_scales.json")
        self.config_file = Path(config_file)
        with open(self.config_file, "r", encoding="utf-8") as f:
            self.data = json.load(f)

    def _pair(self, symbol):
        try:
            return self.data[symbol]
        except KeyError as exc:
            raise RuntimeError(
                f"Нет ATR(3) max.vol для пары {symbol} в {self.config_file}"
            ) from exc

    def _settings(self, symbol):
        try:
            return PAIR_SETTINGS[symbol]
        except KeyError as exc:
            raise RuntimeError(
                f"Нет настроек ATR из приложения Б для пары {symbol}"
            ) from exc

    def native_digits(self, symbol):
        return int(self._pair(symbol)["digits"])

    def atr3_max(self, symbol):
        return float(self._pair(symbol)["atr3_max"])

    def coefficient(self, symbol):
        return float(self._settings(symbol)[0])

    def min_step(self, symbol):
        return float(self._settings(symbol)[1])

    def start_step(self, symbol):
        return float(self._settings(symbol)[2])

    def normalized_to_native_factor(self, symbol):
        return self.coefficient(symbol)

    def native_to_normalized_factor(self, symbol):
        factor = self.normalized_to_native_factor(symbol)
        return 1.0 / factor

    def normalized_to_native(self, value, symbol):
        return float(value) * self.normalized_to_native_factor(symbol)

    def native_to_normalized(self, value, symbol):
        return float(value) * self.native_to_normalized_factor(symbol)

    def native_point(self, symbol):
        return 10.0 ** (-self.native_digits(symbol))

    def _quantize_up(self, value, point):
        if value == 0:
            return 0.0
        units = math.ceil((float(value) / point) - 1e-12)
        return units * point

    def normalized_step_to_native(self, step, symbol):
        """Convert an internal normalized step to the pair-native step.

        RangeShrinker stores ATR steps in normalized units. The configured
        Appendix-B step is the initial native step; after narrowing the step
        may be halved, but never below Appendix-B minimum step.
        """
        if float(step) <= 0:
            return 0.0
        return float(step) * self.coefficient(symbol)

    def range_to_native(self, rng, symbol):
        """Build the exact native MT5 ATR range for one symbol.

        Initial optimization ranges use the Appendix-B values directly:
          Start = 0
          Step  = Appendix-B start step
          Stop  = 0.01 * pair coefficient

        After narrowing, RangeShrinker stores the range on the normalized
        EURUSD scale. Those narrowed start/step/stop values are converted to
        native pair units by multiplying by the pair coefficient.
        """
        narrowed = any(
            key in rng for key in ("median", "source_start", "source_step", "source_stop")
        )

        if not narrowed:
            # Initial optimization: Appendix-B is the source of truth.
            start = 0.0
            step = self.start_step(symbol)
            stop = REFERENCE_ATR3 * self.coefficient(symbol)
        else:
            # Narrowed ranges are stored in the normalized internal scale.
            start = float(rng.get("start", 0.0)) * self.coefficient(symbol)
            step = float(rng.get("step", 0.0)) * self.coefficient(symbol)
            stop = float(rng.get("stop", 0.0)) * self.coefficient(symbol)

        point = self.native_point(symbol)
        start = self._quantize_up(start, point)
        step = self._quantize_up(step, point)
        stop = self._quantize_up(stop, point)

        if step <= 0 and stop > start:
            raise RuntimeError(f"Некорректный ATR step для {symbol}: {step}")
        if stop < start:
            raise RuntimeError(
                f"Некорректный ATR диапазон для {symbol}: {start} > {stop}"
            )

        return {"start": start, "step": step, "stop": stop}
