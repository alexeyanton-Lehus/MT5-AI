from pathlib import Path
import shutil
import time


class ReportCleanup:
    """Очищает временные отчёты MT5 без удаления свежих результатов."""

    XML_MAX_AGE_SECONDS = 4 * 60 * 60

    def __init__(self, terminal_dir):
        self.terminal_dir = Path(terminal_dir)

    def cleanup_old_xml(self, max_age_seconds=None):
        """Удаляет все XML старше заданного возраста внутри reports.

        Очистка не зависит от текущей валюты. Свежие XML не удаляются,
        поэтому очистка не вмешивается в последовательность обработки
        текущего этапа.
        """
        reports_root = self.terminal_dir / "reports"
        if not reports_root.exists():
            return 0

        if max_age_seconds is None:
            max_age_seconds = self.XML_MAX_AGE_SECONDS

        cutoff = time.time() - max_age_seconds
        deleted = 0

        # Scan all XML files under reports, regardless of symbol directory.
        for item in reports_root.rglob("*.xml"):
            if not item.is_file():
                continue

            try:
                if item.stat().st_mtime < cutoff:
                    item.unlink()
                    deleted += 1
                    print(
                        f"Старый XML удалён ({max_age_seconds / 3600:.0f}ч+): {item}"
                    )
            except OSError as exc:
                print(f"Не удалось удалить старый XML {item}: {exc}")

        if deleted:
            print(f"Глобальная очистка reports: удалено XML старше 4 часов: {deleted}")

        return deleted

    def cleanup_pair(self, symbol):
        """Удаляет временные одиночные тестовые отчёты."""
        reports_dir = self.terminal_dir / "reports" / symbol
        tests_dir = reports_dir / "tests"

        tests_dir.mkdir(parents=True, exist_ok=True)

        deleted = 0

        for item in list(tests_dir.iterdir()):
            try:
                if item.is_dir():
                    shutil.rmtree(item)
                else:
                    item.unlink()
                deleted += 1
            except Exception as e:
                print(f"Не удалось удалить {item}: {e}")

        print(
            f"\nОчистка reports/{symbol}/tests: "
            f"удалено объектов {deleted}."
        )
