"""Numeric parsing for MT5 reports.

MT5 reports can contain decimal commas or decimal points and may use spaces or
non-breaking spaces as thousands separators. This module keeps report parsing
consistent across XML and HTML readers and does not change ordinary Python
configuration/input parsing.
"""

import html
import re


def parse_report_number(value):
    """Parse a number as displayed in an MT5 XML/HTML report.

    Supports decimal comma/point, thousands separators, NBSP and percent
    signs. When both separators are present, the rightmost separator is the
    decimal separator. With only one separator, a comma is treated as the
    decimal separator; spaces remain the thousands separator.
    """
    if value is None:
        return None

    if isinstance(value, bool):
        return float(value)

    if isinstance(value, (int, float)):
        return float(value)

    text = html.unescape(str(value))
    text = text.replace("\u00a0", " ").replace("\u202f", " ")
    text = text.replace("%", "").strip()
    text = re.sub(r"(?<=\d)[\s']+(?=\d)", "", text)

    match = re.search(r"[-+]?\d[\d.,]*", text)
    if not match:
        return None

    number = match.group(0)
    comma = number.rfind(",")
    dot = number.rfind(".")

    if comma >= 0 and dot >= 0:
        if comma > dot:
            number = number.replace(".", "").replace(",", ".")
        else:
            number = number.replace(",", "")
    elif comma >= 0:
        number = number.replace(",", ".")

    try:
        return float(number)
    except ValueError:
        return None
