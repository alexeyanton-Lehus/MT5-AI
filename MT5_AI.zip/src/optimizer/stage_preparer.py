from optimizer.range_manager import RangeManager
from optimizer.range_shrinker import RangeShrinker
from mt5.set_file import SetFile
from project_paths import CONFIG_DIR, WORKING_DIR
from optimizer.atr_scaler import ATRScaler
from pathlib import Path
import json


class StagePreparer:
    COMMON_PARAMETERS = (
        "RiskPercent", "MaxOrdersGrid", "MA_Period",
    )

    BUY_PARAMETERS = (
        "ATR_Period_for_MM_buy", "ATR_min_level_for_buy", "TP_ATR_Coeff_buy",
        "SL_ATR_Coeff_buy", "Trail_ATR_Coeff_buy", "ProfitFactor_buy",
        "LotMultiplier_buy", "ATR_Period_for_Grid_buy", "GridStep_ATR_BUY_Coeff",
        "RSI_Period_buy", "RSI_BOTTOM", "ATR_Period_for_MAdist_buy",
        "DistMA_ATR_Coeff_BUY",
    )
    SELL_PARAMETERS = (
        "ATR_Period_for_MM_sell", "ATR_min_level_for_sell", "TP_ATR_Coeff_sell",
        "SL_ATR_Coeff_sell", "Trail_ATR_Coeff_sell", "ProfitFactor_sell",
        "LotMultiplier_sell", "ATR_Period_for_Grid_sell", "GridStep_ATR_SELL_Coeff",
        "RSI_Period_sell", "RSI_UP", "ATR_Period_for_MAdist_sell",
        "DistMA_ATR_Coeff_SELL",
    )

    def __init__(self, stage_manager, set_filename, pair, expert_settings=None):
        self.stage_manager = stage_manager
        self.range_manager = RangeManager()
        self.setfile = SetFile(set_filename)
        self.pair = pair
        self.symbol = pair["symbol"]
        self.expert_settings = expert_settings or {}
        self.atr_scaler = ATRScaler()
        self.shrinker = RangeShrinker(
            CONFIG_DIR / "optimization_ranges.json",
            WORKING_DIR / "narrowed_ranges.json",
        )

    def _current_line_parts(self, name):
        prefix = name + "="
        for line in self.setfile.lines:
            if line.startswith(prefix):
                parts = line.rstrip("\r\n").split("=", 1)[1].split("||")
                if len(parts) >= 4:
                    return parts[0], parts[1], parts[2], parts[3]
                return parts[0], None, None, None
        raise RuntimeError(f"Переменная {name} не найдена в working.set")

    def _optimize_names(self, stage):
        optimize = stage.get("optimize", [])
        if isinstance(optimize, list):
            return set(optimize)
        mode = str(optimize).upper()
        if mode == "BUY":
            return set(self.BUY_PARAMETERS)
        if mode == "SELL":
            return set(self.SELL_PARAMETERS)
        if mode == "BOTH":
            return (
                set(self.COMMON_PARAMETERS)
                | set(self.BUY_PARAMETERS)
                | set(self.SELL_PARAMETERS)
            )
        if not mode:
            return set()
        raise RuntimeError(f"Неизвестное значение optimize: {optimize}")

    def _force_pair_specific_values(self):
        """Force pair-specific EA inputs before every optimization stage.

        TradeSymbol, MaxSpread and Magic must never be inherited from the
        previous currency. These are fixed per-pair values and are not
        optimization parameters.
        """
        required = ("symbol", "max_spread", "magic")
        missing = [key for key in required if key not in self.pair]
        if missing:
            raise RuntimeError(
                f"Для пары {self.symbol} отсутствуют обязательные настройки: "
                + ", ".join(missing)
            )

        pair_values = {
            "TradeSymbol": str(self.pair["symbol"]),
            "MaxSpread": str(self.pair["max_spread"]),
            "Magic": str(self.pair["magic"]),
        }

        # Write exact fixed values. Do not preserve the previous pair's
        # optimization/current-value fields for MaxSpread or Magic.
        replacements = {
            "TradeSymbol": f"TradeSymbol={pair_values['TradeSymbol']}\n",
            "MaxSpread": (
                f"MaxSpread={pair_values['MaxSpread']}||80||1||800||N\n"
            ),
            "Magic": (
                f"Magic={pair_values['Magic']}||{pair_values['Magic']}||1||999999||N\n"
            ),
        }

        found = set()
        for i, line in enumerate(self.setfile.lines):
            for name, replacement in replacements.items():
                if line.startswith(name + "="):
                    self.setfile.lines[i] = replacement
                    found.add(name)
                    break

        missing_lines = set(replacements) - found
        if missing_lines:
            raise RuntimeError(
                f"В working.set отсутствуют переменные: {', '.join(sorted(missing_lines))}"
            )

        self.setfile.save()

        # Read back and verify immediately. This prevents a wrong currency
        # from reaching MT5 even if working.set was left by the previous run.
        verify = {}
        for line in self.setfile.lines:
            if "=" not in line:
                continue
            name, rest = line.rstrip("\r\n").split("=", 1)
            verify[name] = rest.split("||", 1)[0]

        mismatches = {
            name: (verify.get(name), expected)
            for name, expected in pair_values.items()
            if verify.get(name) != expected
        }
        if mismatches:
            raise RuntimeError(
                f"Несоответствие pair-specific параметров для {self.symbol}: {mismatches}"
            )

        print(
            f"PAIR SYNC: {self.symbol} | "
            f"TradeSymbol={pair_values['TradeSymbol']} | "
            f"MaxSpread={pair_values['MaxSpread']} | "
            f"Magic={pair_values['Magic']}"
        )

    def _ranges_for_stage(self, stage, optimize):
        stage_name = stage.get("name")

        # COMMON is the first pass and always starts from the original ranges.
        # BOTH_STAGE_1 and BOTH_STAGE_2 use the narrowed ranges produced by
        # the preceding optimization pass.
        use_narrowed = stage_name in ("BOTH_STAGE_1", "BOTH_STAGE_2")

        if use_narrowed:
            direction = stage["trade_direction"]
            if direction == "BUY_ONLY":
                ranges = self.shrinker.load("BUY")
            elif direction == "SELL_ONLY":
                ranges = self.shrinker.load("SELL")
            elif direction == "BOTH":
                ranges = self.shrinker.load("BOTH")
            else:
                raise RuntimeError(f"Неизвестное направление для сужения: {direction}")
        else:
            ranges = {}
            for name in optimize:
                settings = self.expert_settings.get(name)
                if settings is not None:
                    ranges[name] = {
                        "start": settings["start"],
                        "step": settings["step"],
                        "stop": settings["end"],
                    }
                else:
                    rng = self.range_manager.get(name)
                    if rng is not None:
                        ranges[name] = rng

        result = {}
        for name, rng in ranges.items():
            if name in ("ATR_min_level_for_buy", "ATR_min_level_for_sell"):
                native = self.atr_scaler.range_to_native(rng, self.symbol)
                result[name] = {**rng, **native}
            else:
                result[name] = rng

        return result

    def prepare(self):
        stage = self.stage_manager.current()
        if stage is None:
            raise RuntimeError("Этапов больше нет.")

        print("\n================ STAGE ================")
        print(stage)
        print("=======================================\n")

        # Pair-specific values must be synchronized before any stage
        # parameters are written, so values from the previous currency cannot
        # leak into the current optimization.
        self._force_pair_specific_values()

        # The optimization mode must match the current stage exactly:
        # COMMON/BOTH_STAGE_1 -> BOTH.
        # This value is written before OptimizationRunner builds the MT5 INI.
        stage_direction = stage.get("trade_direction", "BOTH")
        if stage_direction not in {"BOTH", "BUY_ONLY", "SELL_ONLY"}:
            raise RuntimeError(
                f"Неизвестное направление stage {stage.get('name')}: {stage_direction}"
            )
        self.setfile.set_trade_direction(stage_direction)
        optimize = self._optimize_names(stage)
        freeze = set(stage.get("freeze", []))
        optimize -= freeze
        stage_ranges = self._ranges_for_stage(stage, optimize)

        for line in list(self.setfile.lines):
            if "=" not in line or "||" not in line:
                continue

            name = line.split("=", 1)[0]
            if name == "TradeDirection":
                continue

            current_value, old_start, old_step, old_stop = self._current_line_parts(name)

            if name in stage_ranges:
                rng = stage_ranges[name]
                start, step, stop = rng["start"], rng["step"], rng["stop"]
            else:
                if old_start is None:
                    start = step = stop = current_value
                else:
                    start, step, stop = old_start, old_step, old_stop

            enabled = name in optimize and name not in freeze
            self.setfile.set_optimizer(name, current_value, start, step, stop, enabled)

            source = "GUI" if name in self.expert_settings and not stage.get("shrink_ranges", False) else "range"
            if stage.get("shrink_ranges", False) and name in stage_ranges:
                source = "median"
            print(f"{name:35} {'Y' if enabled else 'N'} | {start} || {step} || {stop} ({source})")

        self.setfile.save()
