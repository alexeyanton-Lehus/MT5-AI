import json
from pathlib import Path


class RangeManager:

    def __init__(self):

        with open(
            Path("config/optimization_ranges.json"),
            "r",
            encoding="utf-8"
        ) as f:

            self.ranges = json.load(f)

    def get(self, variable):

        if variable not in self.ranges:
            return None

        return self.ranges[variable]

    def start(self, variable):

        return self.get(variable)["start"]

    def step(self, variable):

        return self.get(variable)["step"]

    def stop(self, variable):

        return self.get(variable)["stop"]