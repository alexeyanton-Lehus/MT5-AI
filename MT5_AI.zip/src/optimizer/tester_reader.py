from pathlib import Path
from html.parser import HTMLParser
import html
import re
import unicodedata

from optimizer.number_parser import parse_report_number


class _MT5TableParser(HTMLParser):
    """Extract MT5 HTML table rows without depending on report language."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.rows = []
        self._row = None
        self._cell = None
        self._cell_parts = None
        self._skip_depth = 0

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        if tag in ("script", "style"):
            self._skip_depth += 1
            return
        if self._skip_depth:
            return
        if tag == "tr":
            if self._row is not None:
                self._finish_row()
            self._row = []
            return
        if tag in ("td", "th"):
            if self._row is None:
                self._row = []
            if self._cell is not None:
                self._finish_cell()
            self._cell = tag
            self._cell_parts = []

    def handle_endtag(self, tag):
        tag = tag.lower()
        if tag in ("script", "style"):
            if self._skip_depth:
                self._skip_depth -= 1
            return
        if self._skip_depth:
            return
        if tag in ("td", "th"):
            if self._cell is not None:
                self._finish_cell()
            return
        if tag == "tr":
            self._finish_row()

    def handle_data(self, data):
        if self._skip_depth:
            return
        if self._cell is not None:
            self._cell_parts.append(data)

    def _finish_cell(self):
        text = " ".join(self._cell_parts or [])
        text = re.sub(r"\s+", " ", text.replace("\xa0", " ")).strip()
        self._row.append(text)
        self._cell = None
        self._cell_parts = None

    def _finish_row(self):
        if self._cell is not None:
            self._finish_cell()
        if self._row:
            self.rows.append(self._row)
        self._row = None


class TesterReader:
    """Read ONLY the completed MT5 single-test (Бек-тест) HTML report.

    ``result_ontester`` is deliberately separate from optimization
    ``result_2``. It is read only from the completed HTML report produced by
    a single test. Labels are supported in English, Russian and Ukrainian.
    """

    REQUIRED_STATS = (
        "Profit",
        "Profit Factor",
        "Recovery Factor",
        "Sharpe Ratio",
        "Equity Drawdown Relative",
        "Win %",
        "LR Correlation",
        "result_ontester",
    )

    _ALIASES = {
        "Total Net Profit": (
            "Total Net Profit", "Net Profit",
            "Чистая прибыль", "Чистий прибуток",
        ),
        "Gross Profit": (
            "Gross Profit", "Валовая прибыль",
            "Загальний прибуток", "Загальний прибуток",
        ),
        "Gross Loss": (
            "Gross Loss", "Валовый убыток", "Загальний збиток",
        ),
        "Profit Factor": (
            "Profit Factor", "ProfitFactor", "PF",
            "Profitability", "Прибыльность", "Прибутковість",
            "Фактор прибыли", "Фактор прибутку",
        ),
        "Recovery Factor": (
            "Recovery Factor", "RecoveryFactor",
            "Фактор восстановления", "Фактор відновлення",
        ),
        "Sharpe Ratio": (
            "Sharpe Ratio", "SharpeRatio",
            "Коэффициент Шарпа", "Коефіцієнт Шарпа",
        ),
        "Expected Payoff": (
            "Expected Payoff", "ExpectedPayoff",
            "Ожидаемый выигрыш", "Очікуваний виграш",
        ),
        "Equity Drawdown Relative": (
            "Equity Drawdown Relative", "Equity DD %",
            "Относительная просадка по средствам",
            "Относительная просадка за средствами",
            "Відносна просадка за коштами",
        ),
        "Equity Drawdown": (
            "Equity Drawdown",
        ),
        "Trades": (
            "Total Trades", "Trades", "Всего трейдов", "Всего сделок",
            "Усього трейдів", "Усього угод",
        ),
        "Total Deals": (
            "Total Deals", "Всего сделок", "Усього угод",
        ),
        "Win %": (
            "Profit Trades (% of total)", "Profit Trades", "Win %",
            "Прибыльные трейды (% от всех)", "Прибыльные трейды",
            "Прибуткові трейди (% від усіх)", "Прибуткові трейди",
        ),
        "Win % Long": (
            "Long Trades (% profitable)", "Long Trades (% of total)",
            "Длинные трейды (% прибыльных)", "Длинные трейды (% от всех)",
            "Длинные сделки (% прибыльных)", "Длинные сделки (% от всех)",
            "Довгі трейди (% виграшні)", "Довгі трейди (% від усіх)",
            "Довгі угоди (% виграшних)", "Довгі угоди (% від усіх)",
        ),
        "Win % Short": (
            "Short Trades (% profitable)", "Short Trades (% of total)",
            "Короткие трейды (% прибыльных)", "Короткие трейды (% от всех)",
            "Короткие сделки (% прибыльных)", "Короткие сделки (% от всех)",
            "Короткі трейди (% виграшні)", "Короткі трейди (% від усіх)",
            "Короткі угоди (% виграшних)", "Короткі угоди (% від усіх)",
        ),
        "AHPR %": ("AHPR", "AHPR %"),
        "GHPR %": ("GHPR", "GHPR %"),
        "LR Correlation": (
            "LR Correlation", "LRCorrelation",
            "Корреляция LR", "Кореляція LR",
        ),
        "result_ontester": (
            "OnTester result", "OnTester Result", "OnTester",
            "Результат OnTester", "Результат функции OnTester",
            "Результат функції OnTester", "Результат OnTester()",
            "Результат функции OnTester()", "Результат функції OnTester()",
        ),
    }

    def read(self, report_file):
        report_file = Path(report_file)
        if not report_file.exists():
            raise FileNotFoundError(f"Отчёт не найден: {report_file}")
        if report_file.suffix.lower() not in (".htm", ".html"):
            raise RuntimeError(
                "TesterReader ожидает HTM/HTML Бек-теста после завершения "
                f"одиночного теста, получен: {report_file}"
            )

        raw = report_file.read_bytes()
        text, encoding = self._decode_html(raw)
        if not text.strip():
            raise RuntimeError(f"HTML отчёт пустой: {report_file}")

        result = self._parse(text)
        missing = [key for key in self.REQUIRED_STATS if key not in result]
        if missing:
            raise RuntimeError(
                "\nОтчёт завершённого Бек-теста MT5 прочитан, но статистика "
                "извлечена неполностью.\n"
                f"Файл: {report_file}\n"
                f"Кодировка: {encoding}\n"
                f"Получено: {result}\n"
                f"Не хватает: {', '.join(missing)}"
            )

        print(
            f"TesterReader: прочитан {report_file.name} "
            f"(encoding={encoding}, stats={len(result)}, "
            f"result_ontester={result.get('result_ontester')})"
        )
        return result

    @staticmethod
    def _decode_html(raw):
        if raw.startswith(b"\xff\xfe"):
            return raw.decode("utf-16-le"), "utf-16-le"
        if raw.startswith(b"\xfe\xff"):
            return raw.decode("utf-16-be"), "utf-16-be"

        sample = raw[:8192]
        nul_count = sample.count(b"\x00")
        if nul_count > 20:
            even_nul = sample[1::2].count(b"\x00")
            odd_nul = sample[0::2].count(b"\x00")
            if even_nul > odd_nul:
                return raw.decode("utf-16-le"), "utf-16-le"
            return raw.decode("utf-16-be"), "utf-16-be"

        for encoding in ("utf-8-sig", "utf-8", "cp1251", "cp1252"):
            try:
                return raw.decode(encoding), encoding
            except UnicodeDecodeError:
                pass
        return raw.decode("utf-8", errors="replace"), "utf-8-replace"

    def _parse(self, text):
        result = {}
        parser = _MT5TableParser()
        parser.feed(text)
        parser.close()
        if parser._row is not None:
            parser._finish_row()
        for cells in parser.rows:
            self._parse_row(cells, result)
        self._parse_text_fallback(text, result)
        self._copy_alias(result, "Profit", "Total Net Profit")
        # Relative drawdown must come only from MT5's equity-relative field.
        # Do not derive it from the generic/ambiguous "Equity Drawdown" field.
        self._copy_alias(result, "Relative Drawdown", "Equity Drawdown Relative")
        return result

    def _parse_row(self, cells, result):
        if not cells:
            return
        for i, cell in enumerate(cells):
            canonical = self._canonical_name(cell)
            if canonical is None:
                continue
            value_text = None
            for j in range(i + 1, len(cells)):
                if cells[j].strip():
                    value_text = cells[j]
                    break
            if value_text is None:
                continue
            value = self._value_for_label(canonical, value_text)
            if value is not None:
                result[canonical] = value

    def _parse_text_fallback(self, text, result):
        visible = re.sub(r"(?is)<br\s*/?>", "\n", text)
        visible = re.sub(r"(?is)</(?:p|div|tr|li|h[1-6])>", "\n", visible)
        visible = re.sub(r"(?is)<[^>]+>", " ", visible)
        visible = html.unescape(visible)
        lines = [self._clean(x) for x in visible.splitlines()]
        lines = [x for x in lines if x]

        for target, variants in self._ALIASES.items():
            if target in result:
                continue
            wanted = [self._normalize(v) for v in variants]
            for i, line in enumerate(lines):
                norm = self._normalize(line)
                matched = False
                for variant in wanted:
                    if norm == variant:
                        matched = True
                        if i + 1 < len(lines):
                            value = self._value_for_label(target, lines[i + 1])
                            if value is not None:
                                result[target] = value
                        break
                    if norm.startswith(variant):
                        remainder = norm[len(variant):]
                        # A normalized label may be immediately followed by
                        # its value (for example Profit Factor3,31).  Do not
                        # treat a bare label as a match without a value.
                        if remainder and re.match(r"[-+]?\d", remainder):
                            matched = True
                            value = self._value_for_label(target, remainder)
                            if value is not None:
                                result[target] = value
                        break
                if matched and target in result:
                    break

    def _canonical_name(self, label):
        key = self._normalize(label)
        for canonical, aliases in self._ALIASES.items():
            for alias in aliases:
                if key == self._normalize(alias):
                    return canonical
        return None

    def _value_for_label(self, label, value):
        value = str(value)
        if label in {"Win %", "Win % Long", "Win % Short"}:
            match = re.search(r"([-+]?\d+(?:[.,]\d+)?)\s*%", value)
            if match:
                return self._number(match.group(1))
        if label in {"AHPR %", "GHPR %"}:
            match = re.search(r"\(([-+]?\d+(?:[.,]\d+)?)\s*%\)", value)
            if match:
                return self._number(match.group(1))
            match = re.search(r"([-+]?\d+(?:[.,]\d+)?)\s*%", value)
            if match:
                return self._number(match.group(1))
        return self._number(value)

    @staticmethod
    def _number(value):
        return parse_report_number(value)

    @staticmethod
    def _normalize(text):
        # MT5 report labels are presentation text.  Ignore case, spaces,
        # hyphens, punctuation, parentheses and the №/# variants so that
        # equivalent labels such as Бек-тест/бектест and
        # Результат OnTester()/Результат OnTester are treated identically.
        # The canonical internal keys remain English and are never changed.
        text = html.unescape(str(text))
        text = text.replace("№", "")
        text = unicodedata.normalize("NFKC", text)
        text = text.replace("\xa0", " ").replace("\u200b", "")
        text = text.replace("ё", "е").replace("Ё", "Е")
        text = text.replace("–", "-").replace("—", "-").replace("‑", "-")
        text = text.casefold()
        return re.sub(r"[^\w]+", "", text, flags=re.UNICODE).replace("_", "")

    @staticmethod
    def _clean(text):
        return re.sub(r"\s+", " ", str(text).replace("\xa0", " ").strip())

    @staticmethod
    def _copy_alias(result, target, source):
        if target not in result and source in result:
            result[target] = result[source]
