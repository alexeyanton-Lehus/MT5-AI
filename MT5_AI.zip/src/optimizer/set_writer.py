from pathlib import Path


class SetWriter:

    def __init__(self, set_file):
        self.set_file = Path(set_file)

    @staticmethod
    def _normalize_value(value):
        if value is None:
            return ""
        return str(value).strip()

    def write(self, best):
        text = self.set_file.read_text(encoding="utf-16")
        lines = text.splitlines()

        new_lines = []
        updated_params = []

        for line in lines:

            stripped = line.strip()

            if not stripped:
                new_lines.append(line)
                continue

            if stripped.startswith(";"):
                new_lines.append(line)
                continue

            if "=" not in line:
                new_lines.append(line)
                continue

            name, rest = line.split("=", 1)

            if name in best:
                value = self._normalize_value(best[name])

                # MT5 expects TradeDirection as the enum's numeric value:
                # BUY_ONLY=0, SELL_ONLY=1, BOTH=2.
                # Keep the human-readable names in Python, but never write
                # them literally into the .set file.
                if name == "TradeDirection":
                    modes = {
                        "BUY_ONLY": "0",
                        "SELL_ONLY": "1",
                        "BOTH": "2",
                    }
                    if value in modes:
                        value = modes[value]
                    elif value not in modes.values():
                        raise ValueError(
                            f"Неизвестное значение TradeDirection: {value}"
                        )

                updated_params.append(f"{name}={value}")

                if "||" in rest:
                    suffix = rest[rest.find("||"):]
                    new_lines.append(f"{name}={value}{suffix}")
                else:
                    new_lines.append(f"{name}={value}")
            else:
                new_lines.append(line)

        self.set_file.write_text("\n".join(new_lines) + "\n", encoding="utf-16")

        # Write debug log to file
        from pathlib import Path
        log_dir = Path("C:/MT5_AI/logs")
        log_dir.mkdir(parents=True, exist_ok=True)
        log_file = log_dir / "set_writer_debug.log"
        
        with open(log_file, "a", encoding="utf-8") as log:
            log.write(f"========== SetWriter.write() ==========\n")
            log.write(f"Обновлено параметров: {len(updated_params)}\n")
            log.write(f"Обновлённые параметры: {', '.join(updated_params)}\n")
            if "TradeDirection" in best:
                log.write(f"TradeDirection в входных данных: {best['TradeDirection']}\n")
            else:
                log.write("TradeDirection НЕ найден во входных данных!\n")
            log.write(f"Все входные параметры: {list(best.keys())}\n")
            log.write("\n")
        
        print(f"\nworking.set обновлён. Обновлено параметров: {len(updated_params)}")
        print(f"Детали записаны в: {log_file}")