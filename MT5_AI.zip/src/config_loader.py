import json
from pathlib import Path

CONFIG_PATH = Path("config/config.json")


def load_config():

    if not CONFIG_PATH.exists():
        raise FileNotFoundError(
            f"Не найден файл конфигурации:\n{CONFIG_PATH}"
        )

    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        cfg = json.load(f)

    required = [
        "mt5_path",
        "expert_name",
        "timeframe",
        "database",
        "filters",
        "optimization"
    ]

    for item in required:
        if item not in cfg:
            raise Exception(f"Отсутствует параметр '{item}'")

    return cfg

def load_tester_config():
    """Load the canonical MT5 tester configuration from config/tester.json."""
    tester_path = Path(__file__).resolve().parents[1] / "config" / "tester.json"
    if not tester_path.exists():
        raise FileNotFoundError(
            f"Не найден файл конфигурации тестера:\n{tester_path}"
        )

    with open(tester_path, "r", encoding="utf-8") as f:
        cfg = json.load(f)

    if not isinstance(cfg, dict):
        raise ValueError(f"Некорректный формат {tester_path}: ожидается JSON-объект")

    return cfg

