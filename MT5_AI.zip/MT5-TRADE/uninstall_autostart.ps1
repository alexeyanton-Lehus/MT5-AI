$ErrorActionPreference = 'Continue'
$Project = 'C:\MT5_AI\MT5-TRADE'
$Optimizer = 'C:\MT5_AI\src\main.py'
$Autonomous = Join-Path $Project 'autonomous.py'
$RunBat = Join-Path $Project 'run_autonomous.bat'
$TaskName = 'MT5-TRADE Autonomous'

Write-Host '=== FULL MT5-TRADE AUTOMATION REMOVAL ==='

# 1) Stop every Scheduled Task whose name OR action references our automation.
$tasks = Get-ScheduledTask -ErrorAction SilentlyContinue
foreach ($t in $tasks) {
    $match = ($t.TaskName -eq $TaskName) -or ($t.TaskName -match 'MT5[-_ ]?TRADE|MT5.*Optim')
    foreach ($a in @($t.Actions)) {
        $text = (($a.Execute + ' ' + $a.Arguments + ' ' + $a.WorkingDirectory)).ToLowerInvariant()
        if ($text.Contains('c:\mt5_ai\mt5-trade') -or $text.Contains('c:\mt5_ai\src\main.py')) { $match = $true }
    }
    if ($match) {
        Write-Host "Stopping/removing task: $($t.TaskName)"
        Stop-ScheduledTask -TaskName $t.TaskName -ErrorAction SilentlyContinue
        Unregister-ScheduledTask -TaskName $t.TaskName -Confirm:$false -ErrorAction SilentlyContinue
    }
}

# 2) Remove our task explicitly in case enumeration missed it.
schtasks.exe /Delete /TN "$TaskName" /F 2>$null | Out-Null

# 3) Kill automation Python processes, including optimizer children. Never kill MT5.
function Stop-AutomationProcesses {
    $found = $false
    foreach ($p in Get-CimInstance Win32_Process -ErrorAction SilentlyContinue) {
        if ($p.Name -notin @('python.exe','pythonw.exe')) { continue }
        $cmd = [string]$p.CommandLine
        if ($cmd.ToLowerInvariant().Contains($Autonomous.ToLowerInvariant()) -or
            $cmd.ToLowerInvariant().Contains($Optimizer.ToLowerInvariant()) -or
            $cmd.ToLowerInvariant().Contains($RunBat.ToLowerInvariant())) {
            $found = $true
            Write-Host "Stopping PID $($p.ProcessId): $cmd"
            & taskkill.exe /PID $p.ProcessId /T /F 2>$null | Out-Null
            Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue
        }
    }
    return $found
}

for ($i=1; $i -le 10; $i++) {
    $found = Stop-AutomationProcesses
    Start-Sleep -Milliseconds 700
    if (-not $found) { break }
}

# 4) Remove common startup links created by this project only.
$startup = [Environment]::GetFolderPath('Startup')
foreach ($name in @('run_autonomous.bat','MT5-TRADE Autonomous.lnk','MT5-TRADE.lnk')) {
    $f = Join-Path $startup $name
    if (Test-Path $f) { Remove-Item $f -Force -ErrorAction SilentlyContinue; Write-Host "Removed startup item: $f" }
}

# 5) Verify: no matching scheduled tasks and no automation Python.
$leftTask = $false
foreach ($t in (Get-ScheduledTask -ErrorAction SilentlyContinue)) {
    $match = ($t.TaskName -eq $TaskName)
    foreach ($a in @($t.Actions)) {
        $text = (($a.Execute + ' ' + $a.Arguments + ' ' + $a.WorkingDirectory)).ToLowerInvariant()
        if ($text.Contains('c:\mt5_ai\mt5-trade') -or $text.Contains('c:\mt5_ai\src\main.py')) { $match = $true }
    }
    if ($match) { Write-Host "ERROR: task remains: $($t.TaskName)"; $leftTask=$true }
}
$leftProc = @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
    $_.Name -in @('python.exe','pythonw.exe') -and (
      ([string]$_.CommandLine).ToLowerInvariant().Contains($Autonomous.ToLowerInvariant()) -or
      ([string]$_.CommandLine).ToLowerInvariant().Contains($Optimizer.ToLowerInvariant())
    )
})
if ($leftTask -or $leftProc.Count -gt 0) {
    Write-Host 'ERROR: automation is still present.'
    exit 1
}
Write-Host 'OK: Scheduled Tasks removed.'
Write-Host 'OK: autonomous.py stopped.'
Write-Host 'OK: optimizer src\main.py stopped.'
Write-Host 'OK: trading MT5 NOT TOUCHED.'
exit 0
