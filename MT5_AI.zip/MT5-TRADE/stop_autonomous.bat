@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ps=Get-CimInstance Win32_Process -Filter \"Name='pythonw.exe' OR Name='python.exe'\" | Where-Object { $_.CommandLine -like '*MT5-TRADE*autonomous.py*' }; foreach($p in $ps){ Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue; Write-Host ('Остановлен autonomous.py PID ' + $p.ProcessId) }"
echo.
echo Торговый MT5 не затронут.
pause
