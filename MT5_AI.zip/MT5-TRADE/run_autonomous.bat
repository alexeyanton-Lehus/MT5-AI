@echo off
cd /d C:\MT5_AI\MT5-TRADE
where pythonw >nul 2>&1
if %errorlevel%==0 (
    start "" pythonw .\autonomous.py
) else (
    start "" python .\autonomous.py
)
