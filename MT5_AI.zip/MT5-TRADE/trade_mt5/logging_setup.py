import logging
from pathlib import Path


def setup_logging(path: str):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    root = logging.getLogger()
    for handler in list(root.handlers):
        try:
            handler.flush()
            handler.close()
        except Exception:
            pass
        root.removeHandler(handler)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
        handlers=[
            logging.FileHandler(p, mode="w", encoding="utf-8"),
            logging.StreamHandler(),
        ],
        force=True,
    )
