import logging
import os
import subprocess
import time
from pathlib import Path
import psutil

LOG = logging.getLogger(__name__)


class TradingTerminal:
    def __init__(self, path, timeout=60):
        self.path = Path(path).resolve()
        self.timeout = timeout
        self.pid = None

    def _matches(self, proc):
        try:
            exe = proc.info.get("exe") or ""
            return Path(exe).resolve() == self.path
        except Exception:
            return False

    def pids(self):
        out = []
        for p in psutil.process_iter(["pid", "exe", "name"]):
            try:
                if self._matches(p):
                    out.append(p.pid)
            except Exception:
                pass
        return out

    def is_running(self):
        return bool(self.pids())

    def start(self, timeout=30):
        """Start only the exact configured trading terminal executable."""
        if not self.path.exists():
            raise FileNotFoundError(f"Торговый MT5 не найден: {self.path}")
        existing = self.pids()
        if existing:
            if len(existing) > 1:
                raise RuntimeError(f"Найдено несколько торговых MT5: {existing}")
            self.pid = existing[0]
            return self.pid

        subprocess.Popen([str(self.path)], cwd=str(self.path.parent), close_fds=True)
        deadline = time.time() + timeout
        while time.time() < deadline:
            pids = self.pids()
            if len(pids) == 1:
                self.pid = pids[0]
                return self.pid
            if len(pids) > 1:
                raise RuntimeError(f"После запуска обнаружено несколько торговых MT5: {pids}")
            time.sleep(0.5)
        raise TimeoutError(f"Торговый MT5 не появился после запуска: {self.path}")
