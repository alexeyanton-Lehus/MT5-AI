from datetime import datetime


def in_trading_window(now, cfg):
    if now.weekday() not in cfg.get("weekdays", [0,1,2,3,4]):
        return False
    start_h, start_m = map(int, cfg.get("work_start", "00:00").split(":"))
    end_h, end_m = map(int, cfg.get("work_end", "23:57").split(":"))
    start = now.replace(hour=start_h, minute=start_m, second=0, microsecond=0)
    end = now.replace(hour=end_h, minute=end_m, second=59, microsecond=999999)
    return start <= now <= end
