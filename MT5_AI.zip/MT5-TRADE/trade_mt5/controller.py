import ctypes
from ctypes import wintypes
from pathlib import Path
import json, re, time

ROOT = Path(__file__).resolve().parent.parent
CFG = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
user32 = ctypes.windll.user32
EnumWindowsProc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
SW_RESTORE = 9


def win_text(hwnd):
    n = user32.GetWindowTextLengthW(hwnd)
    if n <= 0: return ""
    buf = ctypes.create_unicode_buffer(n+1)
    user32.GetWindowTextW(hwnd, buf, n+1)
    return buf.value


def visible_windows():
    out=[]
    @EnumWindowsProc
    def cb(hwnd,_):
        if user32.IsWindowVisible(hwnd):
            t=win_text(hwnd)
            if t: out.append((hwnd,t))
        return True
    user32.EnumWindows(cb,0)
    return out


def chart_info(title):
    m=re.search(r"\[([A-Z0-9_]+),(M1|M2|M3|M4|M5|M6|M10|M12|M15|M20|M30|H1|H2|H3|H4|H6|H8|H12|D1|W1|MN)\]", title, re.I)
    return (m.group(1).upper(),m.group(2).upper()) if m else (None,None)


def find_mt5():
    for hwnd,title in visible_windows():
        low=title.lower()
        if "ava trade markets" in low and ("-mt5:" in low or "mt5:" in low): return hwnd,title
    return None


def find_chart(symbol,tf):
    for hwnd,title in visible_windows():
        s,t=chart_info(title)
        if s==symbol.upper() and t==tf.upper(): return hwnd,title
    return None


def activate_chart(hwnd):
    user32.ShowWindow(hwnd, SW_RESTORE)
    user32.SetForegroundWindow(hwnd)
    time.sleep(0.5)

    # F7 in MT5 acts on the active chart. Explicitly click the chart
    # client area so the keyboard focus cannot remain on another window.
    r = get_rect(hwnd)
    if r:
        x = r.left + max(50, (r.right - r.left) // 2)
        y = r.top + max(100, (r.bottom - r.top) // 2)
        user32.SetCursorPos(x, y)
        time.sleep(0.2)
        user32.mouse_event(0x0002, 0, 0, 0, 0)
        user32.mouse_event(0x0004, 0, 0, 0, 0)
        time.sleep(0.4)


def send_f7():
    # Use SendInput rather than keybd_event.
    INPUT_KEYBOARD = 1
    KEYEVENTF_KEYUP = 0x0002
    class KEYBDINPUT(ctypes.Structure):
        _fields_ = [
            ("wVk", wintypes.WORD),
            ("wScan", wintypes.WORD),
            ("dwFlags", wintypes.DWORD),
            ("time", wintypes.DWORD),
            ("dwExtraInfo", ctypes.POINTER(wintypes.ULONG)),
        ]
    class INPUT(ctypes.Structure):
        _fields_ = [("type", wintypes.DWORD), ("ki", KEYBDINPUT)]

    extra = ctypes.pointer(wintypes.ULONG(0))
    inputs = (INPUT * 2)()
    inputs[0].type = INPUT_KEYBOARD
    inputs[0].ki = KEYBDINPUT(0x76, 0, 0, 0, extra)
    inputs[1].type = INPUT_KEYBOARD
    inputs[1].ki = KEYBDINPUT(0x76, 0, KEYEVENTF_KEYUP, 0, extra)
    user32.SendInput(2, ctypes.byref(inputs), ctypes.sizeof(INPUT))


def find_new_properties(before_hwnds, timeout=6):
    deadline=time.time()+timeout
    while time.time()<deadline:
        for hwnd,title in visible_windows():
            low=title.lower()
            if CFG["expert_name"].lower() in low and hwnd not in before_hwnds:
                return hwnd,title
        time.sleep(0.15)
    # fallback: any visible properties window with our EA title
    for hwnd,title in visible_windows():
        if CFG["expert_name"].lower() in title.lower(): return hwnd,title
    return None


def get_rect(hwnd):
    r=wintypes.RECT()
    if not user32.GetWindowRect(hwnd,ctypes.byref(r)): return None
    return r


def click_load_by_observed_layout(hwnd):
    r=get_rect(hwnd)
    if not r: return False
    w=r.right-r.left; h=r.bottom-r.top
    # In the user's actual MT5 dialog, Load is the upper of the two
    # right-side buttons. Center is approximately x=89.5%, y=92.0%.
    x=r.left+int(w*0.895)
    y=r.top+int(h*0.920)
    print(f"Окно свойств: ({r.left},{r.top})-({r.right},{r.bottom})")
    print(f"Клик «Завантажити»: ({x},{y})")
    user32.SetCursorPos(x,y)
    time.sleep(0.25)
    user32.mouse_event(0x0002,0,0,0,0)
    user32.mouse_event(0x0004,0,0,0,0)
    return True


def find_file_dialog(timeout=4):
    deadline=time.time()+timeout
    while time.time()<deadline:
        for hwnd,title in visible_windows():
            low=title.lower()
            if any(x in low for x in ("открыть","відкрити","open","select","выбор","вибір")):
                return hwnd,title
        time.sleep(0.15)
    return None


def run_safe_test():
    print("\n========== MT5-TRADE v0.6 LOAD TEST ==========\n")
    mt5=find_mt5()
    if not mt5:
        print("ОШИБКА: торговый MT5 не найден."); return
    mt5_hwnd,mt5_title=mt5
    print(f"Торговый MT5: HWND={mt5_hwnd}\n  {mt5_title}")
    chart=find_chart(CFG["test_symbol"],CFG["timeframe"])
    if not chart:
        print(f"ОШИБКА: {CFG['test_symbol']},{CFG['timeframe']} не найден."); return
    ch,ct=chart
    print(f"Найден график: HWND={ch} | {ct}")

    # Important: if a properties dialog is already open, do not press F7 again.
    existing=[(hw,t) for hw,t in visible_windows() if CFG["expert_name"].lower() in t.lower()]
    if existing:
        print("Уже открыто окно свойств EA. F7 НЕ отправляю.")
        props=existing[-1]
    else:
        print("Перед F7 окно свойств отсутствует.")
        print("Активирую EURUSD,H4...")
        activate_chart(ch)
        before={hw for hw,_ in visible_windows()}
        print("Отправляю F7...")
        send_f7()
        props=find_new_properties(before)
        if not props:
            print("ОШИБКА: после F7 окно свойств нашего EA не найдено.")
            print("Список видимых окон после F7:")
            for hw,t in visible_windows(): print(f"  HWND={hw} | {t}")
            return

    ph,pt=props
    print(f"Найдено окно свойств: HWND={ph} | {pt}")
    print("Нажимаю ТОЛЬКО «Завантажити»...")
    if not click_load_by_observed_layout(ph):
        print("ОШИБКА: не удалось получить геометрию окна."); return
    time.sleep(0.8)
    dlg=find_file_dialog()
    if dlg:
        print(f"ДИАЛОГ ВЫБОРА SET ОТКРЫТ: HWND={dlg[0]} | {dlg[1]}")
    else:
        print("Диалог выбора SET не найден.")
    print("Остановка. SET не выбирается и не применяется.")
