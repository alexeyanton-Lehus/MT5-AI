import logging
from pathlib import Path

import MetaTrader5 as mt5

LOG = logging.getLogger(__name__)


def read_trading_account(terminal_path):
    """Read the balance/currency from the already-running trading MT5.

    The function never starts MT5. The caller is responsible for verifying that
    the exact trading terminal process is already running.
    """
    path = str(Path(terminal_path).resolve())
    if not mt5.initialize(path=path):
        code = mt5.last_error()
        raise RuntimeError(f"Не удалось подключиться к торговому MT5 через MetaTrader5 API: {code}")
    try:
        info = mt5.account_info()
        if info is None:
            raise RuntimeError(f"Не удалось получить account_info(): {mt5.last_error()}")
        balance = float(info.balance)
        currency = str(info.currency or "").strip().upper()
        if balance <= 0:
            raise RuntimeError(f"Получен некорректный баланс торгового счёта: {balance}")
        if not currency:
            raise RuntimeError("Торговый MT5 не вернул валюту счёта")
        return balance, currency
    finally:
        mt5.shutdown()
