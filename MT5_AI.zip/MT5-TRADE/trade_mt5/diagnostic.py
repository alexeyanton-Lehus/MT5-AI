
import ctypes
from ctypes import wintypes
from pathlib import Path
import json
import re
import sys

ROOT = Path(__file__).resolve().parent.parent
CFG = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))

user32 = ctypes.windll.user32

EnumWindowsProc = ctypes.WINFUNCTYPE(
    wintypes.BOOL, wintypes.HWND, wintypes.LPARAM
)

def get_window_text(hwnd):
    n = user32.GetWindowTextLengthW(hwnd)
    if n <= 0:
        return ""
    buf = ctypes.create_unicode_buffer(n + 1)
    user32.GetWindowTextW(hwnd, buf, n + 1)
    return buf.value

def is_visible(hwnd):
    return bool(user32.IsWindowVisible(hwnd))

def enum_windows():
    result = []

    @EnumWindowsProc
    def callback(hwnd, lparam):
        if is_visible(hwnd):
            title = get_window_text(hwnd)
            if title.strip():
                result.append((hwnd, title))
        return True

    user32.EnumWindows(callback, 0)
    return result

def extract_symbol_timeframe(title):
    # Examples seen in MT5 titles:
    # [CHFJPY,H4] or ... [CHFJPY,H4] ...
    m = re.search(r"\[([A-Z0-9_]+),(M1|M5|M15|M30|H1|H4|D1|W1|MN)\]", title)
    if m:
        return m.group(1), m.group(2)
    return None, None

def run_diagnostic():
    print()
    print("========== MT5-TRADE DIAGNOSTIC ==========")
    print()
    print("Конфигурация:")
    print(f"  MT5: {CFG['trading_mt5_path']}")
    print(f"  trading_input: {CFG['trading_input']}")
    print(f"  EA: {CFG['expert_name']}")
    print(f"  TF: {CFG['timeframe']}")
    print()

    input_dir = Path(CFG["trading_input"])
    input_dir.mkdir(parents=True, exist_ok=True)

    sets = sorted(input_dir.glob("*.set"))
    print(f".set в trading_input: {len(sets)}")
    for p in sets:
        print(f"  - {p.name}")
    print()

    print("Видимые окна Windows:")
    mt5_candidates = []

    for hwnd, title in enum_windows():
        low = title.lower()
        if "ava trade" in low or "metatrader" in low or "mt5" in low:
            mt5_candidates.append((hwnd, title))

    if not mt5_candidates:
        print("  MT5-окно не найдено.")
    else:
        for hwnd, title in mt5_candidates:
            symbol, timeframe = extract_symbol_timeframe(title)
            extra = ""
            if symbol:
                extra = f" | symbol={symbol} timeframe={timeframe}"
            print(f"  HWND={hwnd} | {title}{extra}")

    print()
    print("Режим: ТОЛЬКО ДИАГНОСТИКА.")
    print("MT5, графики и советники НЕ изменялись.")
    print()
