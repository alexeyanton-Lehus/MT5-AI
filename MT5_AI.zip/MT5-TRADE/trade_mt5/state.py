import json
import hashlib
from pathlib import Path


class StateStore:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.data = self._load()

    def _load(self):
        if not self.path.exists():
            return {"installed": {}, "last_batch": None}
        try:
            return json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:
            return {"installed": {}, "last_batch": None}

    def save(self):
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps(self.data, indent=2, ensure_ascii=False), encoding="utf-8")
        tmp.replace(self.path)

    @staticmethod
    def sha256(path):
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                h.update(chunk)
        return h.hexdigest()

    def installed_hash(self, symbol):
        return self.data.get("installed", {}).get(symbol, {}).get("sha256")

    def mark_installed(self, symbol, set_path, batch_id=None):
        self.data.setdefault("installed", {})[symbol] = {
            "filename": Path(set_path).name,
            "sha256": self.sha256(set_path),
            "applied_at": __import__("datetime").datetime.now().isoformat(timespec="seconds"),
            "batch_id": batch_id,
        }
        self.save()
