import logging
import re
import time
from pathlib import Path

from pywinauto import Desktop
from pywinauto.keyboard import send_keys

from .chart_manager import ChartManagerBridge

LOG = logging.getLogger(__name__)

CHART_RE = re.compile(
    r"(?:\[)?([A-Z0-9_]{3,20}),(M1|M2|M3|M4|M5|M6|M10|M12|M15|M20|M30|H1|H2|H3|H4|H6|H8|H12|D1|W1|MN1)(?:\])?",
    re.I,
)


class MT5UI:
    """GUI controller for the already running trading MT5.

    Important safety rules:
    - never starts or restarts a test terminal;
    - never closes charts;
    - never uses blind screen coordinates for the SET button;
    - identifies the real EA-properties window and its child Button control.
    """

    def __init__(self, pid, expert_name, timeframe="H4", timeout=60):
        self.pid = pid
        self.expert_name = expert_name
        self.timeframe = timeframe
        self.timeout = timeout
        self.window = None

    def connect(self):
        """Attach to the already-running terminal using its real top-level Win32 window.

        UIA Desktop enumeration is unreliable with some MT5 builds (the process is
        visible to Win32 but its main frame is not returned by Desktop.windows()).
        Therefore process identity is established by TradingTerminal and the GUI
        attachment itself is done through EnumWindows + the exact PID.
        """
        import win32gui
        import win32process
        from pywinauto import Application

        deadline = time.time() + self.timeout

        while time.time() < deadline:
            matches = []

            def inspect(hwnd):
                try:
                    if not win32gui.IsWindow(hwnd):
                        return

                    _, pid = win32process.GetWindowThreadProcessId(hwnd)

                    if pid != self.pid:
                        return

                    title = (win32gui.GetWindowText(hwnd) or "").strip()

                    if not title:
                        return

                    l, t, r, b = win32gui.GetWindowRect(hwnd)
                    area = max(0, r - l) * max(0, b - t)
                    cls = win32gui.GetClassName(hwnd)
                    visible = bool(win32gui.IsWindowVisible(hwnd))

                    matches.append(
                        (
                            visible,
                            area,
                            hwnd,
                            title,
                            cls,
                            (l, t, r, b),
                        )
                    )

                except Exception:
                    pass

            win32gui.EnumWindows(
                lambda h, _: inspect(h),
                None,
            )

            if matches:
                # The main terminal frame is normally the largest visible
                # top-level window belonging to this exact PID.
                matches.sort(
                    reverse=True,
                    key=lambda x: (x[0], x[1]),
                )

                visible, area, hwnd, title, cls, rect = matches[0]

                try:
                    self.window = (
                        Application(backend="win32")
                        .connect(process=self.pid)
                        .window(handle=hwnd)
                    )

                    LOG.info(
                        "Подключено к главному окну торгового MT5: "
                        "HWND=%s | %s | class=%s | rect=%s",
                        hwnd,
                        title,
                        cls,
                        rect,
                    )

                    return self.window

                except Exception as exc:
                    LOG.warning(
                        "Найдено окно MT5 HWND=%s, "
                        "но подключение pywinauto не удалось: %s",
                        hwnd,
                        exc,
                    )

            time.sleep(0.5)

        raise TimeoutError(
            "Не найдено главное окно торгового MT5"
        )

    def _activate(self):
        if self.window is None:
            self.connect()

        self.window.set_focus()
        time.sleep(0.2)

    @staticmethod
    def _chart_titles(pid):
        """Find chart identities belonging to this exact MT5 PID.

        MT5 builds expose chart windows differently. Some use [EURUSD,H4],
        some expose EURUSD,H4 without brackets, and some append other text.
        We inspect every Win32 descendant of the terminal instead of requiring
        one exact window-title format.
        """
        try:
            import win32gui
            import win32process
        except Exception:
            return []

        result = []
        seen = set()

        timeframe_tokens = {
            "M1",
            "M2",
            "M3",
            "M4",
            "M5",
            "M6",
            "M10",
            "M12",
            "M15",
            "M20",
            "M30",
            "H1",
            "H2",
            "H3",
            "H4",
            "H6",
            "H8",
            "H12",
            "D1",
            "W1",
            "MN1",
        }

        def inspect(hwnd):
            try:
                if not win32gui.IsWindow(hwnd):
                    return

                _, p = win32process.GetWindowThreadProcessId(hwnd)

                if p != pid:
                    return

                title = str(
                    win32gui.GetWindowText(hwnd) or ""
                ).strip()

                if not title:
                    return

                m = CHART_RE.search(title)

                if not m:
                    return

                symbol = m.group(1).upper()
                tf = m.group(2).upper()

                if tf not in timeframe_tokens:
                    return

                key = (hwnd, symbol, tf)

                if key not in seen:
                    seen.add(key)
                    result.append(
                        (
                            hwnd,
                            f"{symbol},{tf}",
                        )
                    )

            except Exception:
                pass

        tops = []

        win32gui.EnumWindows(
            lambda h, _: tops.append(h),
            None,
        )

        for top in tops:
            try:
                _, p = win32process.GetWindowThreadProcessId(top)

                if p != pid:
                    continue

                inspect(top)

                win32gui.EnumChildWindows(
                    top,
                    lambda h, _: inspect(h),
                    None,
                )

            except Exception:
                pass

        return result

    def _uia_chart_control(self, symbol, timeframe=None):
        """Find an MT5 chart control exposed through UI Automation.

        MT5 charts may be internal MDI objects rather than Win32 child windows.
        In that case EnumChildWindows cannot see them, while UI Automation can
        expose the chart/tab text.
        """
        target = (
            f"{symbol},{timeframe or self.timeframe}"
        ).upper()

        try:
            from pywinauto import Desktop

            root = Desktop(
                backend="uia"
            ).window(
                handle=self.window.handle if self.window else 0
            )

            for control_type in (
                "TabItem",
                "Text",
                "Pane",
                "Custom",
            ):
                try:
                    c = root.child_window(
                        title_re=rf"(?i).*{re.escape(target)}.*",
                        control_type=control_type,
                    )

                    if c.exists(timeout=0.6):
                        return c

                except Exception:
                    pass

        except Exception as exc:
            LOG.debug(
                "UIA поиск вкладки %s не выполнен: %s",
                target,
                exc,
            )

        return None

    def chart_exists(self, symbol, timeframe=None):
        tf = timeframe or self.timeframe
        title = f"{symbol},{tf}"

        charts = self._chart_titles(self.pid)

        if any(
            t.upper() == title.upper()
            for _, t in charts
        ):
            LOG.info(
                "Поиск графика %s: найдено=True; Win32=%s",
                title,
                charts,
            )
            return True

        uia = self._uia_chart_control(
            symbol,
            tf,
        )

        found = uia is not None

        LOG.info(
            "Поиск графика %s: найдено=%s; Win32=%s; UIA=%s",
            title,
            found,
            charts,
            bool(uia),
        )

        return found

    def _activate_chart_hwnd(self, hwnd):
        """Activate an existing chart *inside* this exact MT5 process.

        MT5 charts are commonly MDI children. Bringing only the terminal's
        top-level frame to the foreground does NOT select the requested chart;
        F7 would then open EA properties for whichever chart was already active.

        We therefore explicitly activate the MDI child with WM_MDIACTIVATE and
        verify it with WM_MDIGETACTIVE. A click is used only as a fallback when
        the MT5 build does not expose the MDI relationship.
        """
        import win32gui
        import win32process
        import win32con
        from pywinauto import Application

        _, pid = win32process.GetWindowThreadProcessId(hwnd)

        if pid != self.pid:
            raise RuntimeError(
                f"Попытка активировать окно другого процесса: "
                f"PID={pid}, ожидался {self.pid}"
            )

        root = (
            win32gui.GetAncestor(
                hwnd,
                win32con.GA_ROOT,
            )
            or hwnd
        )

        _, root_pid = (
            win32process.GetWindowThreadProcessId(root)
        )

        if root_pid != self.pid:
            raise RuntimeError(
                "Корневое окно графика принадлежит "
                f"другому процессу: PID={root_pid}"
            )

        win32gui.ShowWindow(
            root,
            win32con.SW_RESTORE,
        )

        win32gui.SetForegroundWindow(root)
        time.sleep(0.15)

        mdi_client = None
        cur = hwnd

        while cur and cur != root:
            parent = win32gui.GetParent(cur)

            if not parent:
                break

            try:
                if (
                    win32gui.GetClassName(parent).lower()
                    == "mdiclient"
                ):
                    mdi_client = parent
                    break

            except Exception:
                pass

            cur = parent

        activated = False

        if mdi_client:
            try:
                win32gui.SendMessage(
                    mdi_client,
                    win32con.WM_MDIACTIVATE,
                    hwnd,
                    0,
                )

                time.sleep(0.25)

                active = win32gui.SendMessage(
                    mdi_client,
                    win32con.WM_MDIGETACTIVE,
                    0,
                    0,
                )

                activated = (
                    int(active or 0)
                    == int(hwnd)
                )

                LOG.info(
                    "Активация MDI-графика: "
                    "HWND=%s, MDI=%s, active=%s, подтверждено=%s",
                    hwnd,
                    mdi_client,
                    active,
                    activated,
                )

            except Exception as exc:
                LOG.debug(
                    "WM_MDIACTIVATE не сработал "
                    "для HWND=%s: %s",
                    hwnd,
                    exc,
                )

        if not activated:
            try:
                (
                    Application(backend="win32")
                    .connect(process=self.pid)
                    .window(handle=hwnd)
                    .click_input()
                )

                time.sleep(0.35)

                activated = True

                LOG.info(
                    "График HWND=%s активирован "
                    "кликом по самому окну",
                    hwnd,
                )

            except Exception as exc:
                LOG.debug(
                    "Клик по графику HWND=%s не сработал: %s",
                    hwnd,
                    exc,
                )

        try:
            win32gui.SetFocus(hwnd)
        except Exception:
            pass

        time.sleep(0.25)

        if not activated:
            raise RuntimeError(
                f"Не удалось активировать именно "
                f"график HWND={hwnd} в торговом MT5"
            )

        return root

    def _set_timeframe(
        self,
        symbol,
        timeframe,
        timeout=6,
    ):
        """Set timeframe using the real MT5 toolbar control, with verification.

        No screen coordinates are used.
        """
        target = (
            f"{symbol},{timeframe}"
        ).upper()

        self._activate()

        charts = self._chart_titles(self.pid)

        sym_hwnd = next(
            (
                h
                for h, t in charts
                if t.upper().startswith(
                    symbol.upper() + ","
                )
            ),
            None,
        )

        if sym_hwnd:
            self._activate_chart_hwnd(
                sym_hwnd
            )

        try:
            root = Desktop(
                backend="uia"
            ).window(
                handle=self.window.handle
            )

            wanted = timeframe.upper()

            for ct in (
                "Button",
                "ToolBar",
                "MenuItem",
            ):
                try:
                    controls = root.descendants(
                        control_type=ct
                    )
                except Exception:
                    controls = []

                for c in controls:
                    try:
                        name = (
                            c.element_info.name
                            or ""
                        ).strip().upper()

                        if name == wanted:
                            c.click_input()

                            LOG.info(
                                "Выбран таймфрейм %s "
                                "через реальный UI-контрол MT5",
                                timeframe,
                            )
                            break

                    except Exception:
                        continue

                else:
                    continue

                break

        except Exception as exc:
            LOG.debug(
                "UIA поиск кнопки таймфрейма %s: %s",
                timeframe,
                exc,
            )

        deadline = time.time() + timeout

        while time.time() < deadline:
            if self.chart_exists(
                symbol,
                timeframe,
            ):
                LOG.info(
                    "Подтверждён график %s",
                    target,
                )
                return

            time.sleep(0.25)

        if timeframe.upper() == "H4":
            self._activate()

            LOG.info(
                "Кнопка H4 не дала результата — "
                "использую стандартную команду MT5 Alt+6"
            )

            send_keys("%6")

            deadline = time.time() + timeout

            while time.time() < deadline:
                if self.chart_exists(
                    symbol,
                    timeframe,
                ):
                    LOG.info(
                        "График %s подтверждён после Alt+6",
                        target,
                    )
                    return

                time.sleep(0.25)

        raise RuntimeError(
            f"Не удалось установить таймфрейм "
            f"{timeframe} для {symbol}. "
            "Изменения графиков не подтверждены, "
            "автоматический выбор не выполнялся."
        )

    def open_chart(
        self,
        symbol,
        timeframe=None,
        timeout=8,
    ):
        """Ensure SYMBOL,TIMEFRAME exists without GUI automation for chart creation.

        If the exact chart already exists, the existing selection path is preserved
        because SET loading still uses the current proven mechanism. If the chart
        does not exist, creation and template application are delegated to the
        MQL5 chart-manager EA through FILE_COMMON. Python does not move the mouse,
        send keys, activate the terminal, or manipulate Market Watch to create it.
        """
        tf = timeframe or self.timeframe
        target = f"{symbol},{tf}"

        if self.chart_exists(
            symbol,
            tf,
        ):
            self.select_chart(
                symbol,
                tf,
            )

            LOG.info(
                "График %s уже открыт — выбран",
                target,
            )
            return

        charts = self._chart_titles(
            self.pid
        )

        if any(
            t.upper().startswith(
                symbol.upper() + ","
            )
            for _, t in charts
        ):
            LOG.info(
                "Для %s уже существует другой "
                "таймфрейм; не переключаю его. "
                "Создаю отдельный %s через MQL5 chart manager",
                symbol,
                target,
            )

        template = (
            "RSI+MA-martin-adaptiv-V13.tpl"
        )

        LOG.info(
            "Создаю %s без GUI: "
            "ChartOpen + ChartApplyTemplate(%s)",
            target,
            template,
        )

        bridge = ChartManagerBridge(
            timeout=max(
                float(timeout),
                20.0,
            )
        )

        response = (
            bridge.open_and_apply_template(
                symbol,
                tf,
                template,
            )
        )

        LOG.info(
            "MQL5 chart manager: %s",
            response,
        )

        deadline = (
            time.time()
            + max(
                float(timeout),
                20.0,
            )
        )

        while time.time() < deadline:
            if self.chart_exists(
                symbol,
                tf,
            ):
                break

            time.sleep(0.25)

        if not self.chart_exists(
            symbol,
            tf,
        ):
            raise RuntimeError(
                f"MQL5 chart manager сообщил "
                f"об открытии {target}, "
                "но Python не обнаружил график "
                "в торговом MT5."
            )

        if not self.chart_has_target_ea(
            symbol,
            tf,
        ):
            raise RuntimeError(
                f"График {target} создан, "
                f"но шаблон не загрузил "
                f"{self.expert_name}. "
                "SET НЕ загружаю."
            )

        LOG.info(
            "График %s создан и шаблон %s подтверждён",
            target,
            template,
        )

    def select_chart(
        self,
        symbol,
        timeframe=None,
    ):
        tf = timeframe or self.timeframe
        target = f"{symbol},{tf}"
        target_upper = target.upper()

        for hwnd, title in self._chart_titles(
            self.pid
        ):
            if title.upper() == target_upper:
                try:
                    self._activate_chart_hwnd(
                        hwnd
                    )

                    LOG.info(
                        "График %s ДЕЙСТВИТЕЛЬНО "
                        "активирован: HWND=%s, title=%s",
                        target,
                        hwnd,
                        title,
                    )

                    return hwnd

                except Exception as exc:
                    raise RuntimeError(
                        f"Не удалось активировать "
                        f"именно {target}: {exc}"
                    ) from exc

        uia = self._uia_chart_control(
            symbol,
            tf,
        )

        if uia is not None:
            try:
                self._activate()

                uia.click_input()

                time.sleep(0.5)

                LOG.info(
                    "Выбран график %s через UI Automation: "
                    "control_type=%s",
                    target,
                    uia.element_info.control_type,
                )

                return uia

            except Exception as exc:
                raise RuntimeError(
                    f"График {target} найден через UIA, "
                    "но не удалось его активировать: "
                    f"{exc}"
                ) from exc

        raise RuntimeError(
            f"График {target} не найден. "
            "Существующие графики не изменяю."
        )

    def chart_has_target_ea(
        self,
        symbol,
        timeframe=None,
    ):
        """Проверяет EA через MQL5 ChartGetString(CHART_EXPERT_NAME).

        GUI/UIA для проверки советника не используется.
        """

        tf = timeframe or self.timeframe

        try:
            bridge = ChartManagerBridge(
                timeout=20.0
            )

            expert = (
                bridge
                .get_chart_expert(
                    symbol,
                    tf,
                )
                .strip()
            )

            expected = (
                self.expert_name.strip()
            )

            found = (
                expert.casefold()
                == expected.casefold()
            )

            if found:
                LOG.info(
                    "%s,%s: EA подтверждён "
                    "через MQL5: %s",
                    symbol,
                    tf,
                    expert,
                )
            else:
                LOG.error(
                    "%s,%s: EA НЕ подтверждён. "
                    "MT5 сообщил '%s', "
                    "ожидается '%s'",
                    symbol,
                    tf,
                    expert or "<пусто>",
                    expected,
                )

            return found

        except Exception as exc:
            LOG.error(
                "%s,%s: ошибка проверки EA "
                "через MQL5: %s",
                symbol,
                tf,
                exc,
            )

            return False

    def _find_properties_hwnd(
        self,
        timeout=6,
    ):
        """Find the actual top-level EA properties window, not an owner/main frame."""
        import win32gui
        import win32process

        deadline = time.time() + timeout

        matches = []

        while time.time() < deadline:
            matches = []

            tops = []

            win32gui.EnumWindows(
                lambda h, _: tops.append(h),
                None,
            )

            for hwnd in tops:
                try:
                    if not win32gui.IsWindowVisible(
                        hwnd
                    ):
                        continue

                    _, pid = (
                        win32process.GetWindowThreadProcessId(
                            hwnd
                        )
                    )

                    if pid != self.pid:
                        continue

                    title = (
                        win32gui.GetWindowText(
                            hwnd
                        )
                        or ""
                    ).strip()

                    low = title.lower()

                    if (
                        self.expert_name.lower()
                        in low
                    ):
                        matches.append(
                            (
                                hwnd,
                                title,
                            )
                        )

                except Exception:
                    pass

            if matches:
                matches.sort(
                    key=lambda x:
                        self.expert_name.lower()
                        not in x[1].lower()
                )

                return matches[0]

            time.sleep(0.15)

        return None

    def open_expert_properties(
        self,
        symbol=None,
        timeframe=None,
    ):
        """Open properties only after positively identifying our EA on the chart."""

        if symbol:
            tf = timeframe or self.timeframe

            if not self.chart_has_target_ea(
                symbol,
                tf,
            ):
                raise RuntimeError(
                    f"На графике {symbol},{tf} "
                    f"не подтверждён {self.expert_name}. "
                    "Чужой советник не открываю "
                    "и не изменяю."
                )

        existing = self._find_properties_hwnd(
            timeout=0.5
        )

        if existing:
            LOG.info(
                "Окно свойств НАШЕГО EA уже открыто: "
                "HWND=%s | %s",
                *existing,
            )

            return Desktop(
                backend="uia"
            ).window(
                handle=existing[0]
            )

        self._activate()

        before = {
            w.handle
            for w in Desktop(
                backend="uia"
            ).windows()
            if w.process_id() == self.pid
        }

        send_keys("{F7}")

        found = self._find_properties_hwnd(
            timeout=self.timeout
        )

        if not found:
            raise RuntimeError(
                f"После F7 не найдено окно свойств "
                f"{self.expert_name}. "
                "Чужое окно свойств не принимается."
            )

        hwnd, title = found

        if hwnd in before:
            LOG.info(
                "Свойства нашего EA уже существовали: "
                "HWND=%s | %s",
                hwnd,
                title,
            )
        else:
            LOG.info(
                "Открыто окно свойств НАШЕГО EA: "
                "HWND=%s | %s",
                hwnd,
                title,
            )

        return Desktop(
            backend="uia"
        ).window(
            handle=hwnd
        )

    @staticmethod
    def _window_rect(hwnd):
        import win32gui

        return win32gui.GetWindowRect(hwnd)

    @staticmethod
    def _child_buttons(hwnd):
        """Return real descendant Button controls with native HWNDs and rectangles."""
        import win32gui

        buttons = []

        def cb(child, _):
            try:
                if (
                    win32gui.GetClassName(
                        child
                    ).lower()
                    == "button"
                ):
                    text = (
                        win32gui.GetWindowText(
                            child
                        )
                        or ""
                    ).strip()

                    r = win32gui.GetWindowRect(
                        child
                    )

                    if (
                        win32gui.IsWindowVisible(
                            child
                        )
                        and r[2] > r[0]
                        and r[3] > r[1]
                    ):
                        buttons.append(
                            (
                                child,
                                text,
                                r,
                            )
                        )

            except Exception:
                pass

            return True

        win32gui.EnumChildWindows(
            hwnd,
            cb,
            None,
        )

        return buttons

    def _find_load_button(self, dlg):
        """Find Load/Завантажити by text first, then by actual child-button geometry.

        The MT5 dialog on the user's build exposes the relevant controls as owner-drawn
        Button children with empty window text. Therefore the fallback uses the actual
        child HWND rectangles and the dialog bounds, not hard-coded screen coordinates.
        """
        import win32gui
        from pywinauto.controls.hwndwrapper import HwndWrapper

        hwnd = dlg.handle

        buttons = self._child_buttons(
            hwnd
        )

        if not buttons:
            raise RuntimeError(
                "В окне свойств EA не найдены "
                "дочерние Button-контролы"
            )

        load_words = (
            "load",
            "загруз",
            "завантаж",
        )

        for bh, text, rect in buttons:
            if any(
                word in text.lower()
                for word in load_words
            ):
                LOG.info(
                    "Найдена кнопка SET по тексту: "
                    "HWND=%s | %r | %s",
                    bh,
                    text,
                    rect,
                )

                return HwndWrapper(bh)

        dr = self._window_rect(
            hwnd
        )

        dl, dt, dright, dbottom = dr

        candidates = []

        for bh, text, r in buttons:
            l, t, right, bottom = r

            if (
                l < dl
                or right > dright
                or t < dt
                or bottom > dbottom
            ):
                continue

            bw = right - l
            bhgt = bottom - t

            if bw < 40 or bhgt < 15:
                continue

            rel_x = (
                (l + right) / 2
                - dl
            )

            rel_y = (
                (t + bottom) / 2
                - dt
            )

            rel_w = dright - dl
            rel_h = dbottom - dt

            if (
                rel_x < rel_w * 0.65
                or rel_y < rel_h * 0.70
            ):
                continue

            candidates.append(
                (
                    rel_y,
                    rel_x,
                    bh,
                    text,
                    r,
                )
            )

        if len(candidates) >= 2:
            candidates.sort(
                key=lambda x: (
                    x[0],
                    x[1],
                )
            )

            chosen = candidates[0]

            LOG.info(
                "Owner-drawn SET button candidate: "
                "HWND=%s | text=%r | rect=%s | candidates=%s",
                chosen[2],
                chosen[3],
                chosen[4],
                len(candidates),
            )

            return HwndWrapper(
                chosen[2]
            )

        detail = "; ".join(
            f"HWND={b[0]} text={b[1]!r} rect={b[2]}"
            for b in buttons
        )

        raise RuntimeError(
            "Не удалось однозначно определить "
            "кнопку «Завантажити». "
            f"Найденные Button-контролы: {detail}"
        )

    def _find_file_dialog(
        self,
        timeout=10,
    ):
        """Find the standard Windows Open dialog that is currently foreground."""
        deadline = time.time() + timeout

        title_words = (
            "open",
            "откры",
            "відкр",
            "select",
            "выбор",
            "вибір",
        )

        from pywinauto.controls.hwndwrapper import HwndWrapper
        import win32gui
        import win32process

        def pid_of(hwnd):
            try:
                return (
                    win32process
                    .GetWindowThreadProcessId(hwnd)[1]
                )
            except Exception:
                return 0

        def is_open_dialog(hwnd):
            try:
                if (
                    not hwnd
                    or not win32gui.IsWindowVisible(
                        hwnd
                    )
                ):
                    return False

                if (
                    win32gui.GetClassName(hwnd)
                    != "#32770"
                ):
                    return False

                title = (
                    win32gui.GetWindowText(
                        hwnd
                    )
                    or ""
                ).strip().lower()

                return any(
                    x in title
                    for x in title_words
                )

            except Exception:
                return False

        while time.time() < deadline:
            try:
                fg = (
                    win32gui.GetForegroundWindow()
                )

                if is_open_dialog(fg):
                    LOG.info(
                        "Найден native диалог SET: "
                        "HWND=%s | title=%r | "
                        "dialog_pid=%s | MT5_PID=%s",
                        fg,
                        win32gui.GetWindowText(fg),
                        pid_of(fg),
                        self.pid,
                    )

                    return HwndWrapper(fg)

                found = []

                def enum_cb(hwnd, _):
                    try:
                        if not is_open_dialog(
                            hwnd
                        ):
                            return

                        owner = win32gui.GetWindow(
                            hwnd,
                            win32gui.GW_OWNER,
                        )

                        parent = (
                            win32gui.GetParent(
                                hwnd
                            )
                        )

                        if (
                            pid_of(hwnd)
                            == self.pid
                            or pid_of(owner)
                            == self.pid
                            or pid_of(parent)
                            == self.pid
                        ):
                            found.append(hwnd)

                    except Exception:
                        pass

                win32gui.EnumWindows(
                    enum_cb,
                    None,
                )

                if found:
                    hwnd = found[-1]

                    LOG.info(
                        "Найден native диалог SET "
                        "по owner: HWND=%s | title=%r | "
                        "dialog_pid=%s | MT5_PID=%s",
                        hwnd,
                        win32gui.GetWindowText(
                            hwnd
                        ),
                        pid_of(hwnd),
                        self.pid,
                    )

                    return HwndWrapper(
                        hwnd
                    )

            except Exception as exc:
                LOG.debug(
                    "Поиск native диалога SET: %s",
                    exc,
                )

            time.sleep(0.15)

        return None

    def _filename_edit(self, file_dlg):
        """Return the bottom-most Edit control, which is the File name field."""
        import win32gui

        edits = []

        try:
            children = []

            def enum_child(hwnd, _):
                try:
                    if (
                        win32gui.GetClassName(
                            hwnd
                        )
                        == "Edit"
                    ):
                        children.append(hwnd)
                except Exception:
                    pass

            win32gui.EnumChildWindows(
                file_dlg.handle,
                enum_child,
                None,
            )

            for hwnd in children:
                r = win32gui.GetWindowRect(
                    hwnd
                )

                edits.append(
                    (
                        r[1],
                        hwnd,
                        r,
                    )
                )

        except Exception:
            pass

        if not edits:
            return file_dlg.child_window(
                control_type="Edit"
            )

        edits.sort(
            reverse=True
        )

        from pywinauto.controls.hwndwrapper import HwndWrapper

        return HwndWrapper(
            edits[0][1]
        )

    def _click_open_in_file_dialog(
        self,
        file_dlg,
    ):
        for caption in (
            "Open",
            "Открыть",
            "Відкрити",
            "Выбрать",
            "Вибрати",
        ):
            try:
                btn = file_dlg.child_window(
                    title=caption,
                    control_type="Button",
                )

                if btn.exists(
                    timeout=0.3
                ):
                    btn.click_input()
                    return

            except Exception:
                pass

        send_keys("{ENTER}")

    def _click_ok(self, dlg):
        for caption in (
            "OK",
            "ОК",
        ):
            try:
                btn = dlg.child_window(
                    title=caption,
                    control_type="Button",
                )

                if btn.exists(
                    timeout=0.4
                ):
                    btn.click_input()
                    return

            except Exception:
                pass

        for bh, text, _ in self._child_buttons(
            dlg.handle
        ):
            if text.strip().lower() in (
                "ok",
                "ок",
            ):
                from pywinauto.controls.hwndwrapper import HwndWrapper

                HwndWrapper(
                    bh
                ).click_input()

                return

        raise RuntimeError(
            "Кнопка OK в свойствах "
            "советника не найдена"
        )

    def load_set_in_properties(
        self,
        set_path,
        symbol=None,
        timeframe=None,
    ):
        """Load and apply an exact SET in the currently selected EA chart."""
        set_path = Path(
            set_path
        ).resolve()

        if not set_path.exists():
            raise FileNotFoundError(
                set_path
            )

        dlg = self.open_expert_properties(
            symbol=symbol,
            timeframe=timeframe,
        )

        load_btn = self._find_load_button(
            dlg
        )

        LOG.info(
            "Нажимаю найденную дочернюю кнопку "
            "Load: HWND=%s",
            load_btn.handle,
        )

        # Do NOT use synchronous SendMessage(BM_CLICK) here:
        # MT5 opens a modal common-file dialog from the button handler.
        try:
            import win32api
            import win32con

            win32api.PostMessage(
                load_btn.handle,
                win32con.BM_CLICK,
                0,
                0,
            )

            LOG.info(
                "Load: отправлен Win32 "
                "PostMessage(BM_CLICK): HWND=%s",
                load_btn.handle,
            )

        except Exception as exc:
            LOG.warning(
                "PostMessage(BM_CLICK) не сработал "
                "(%s), использую click_input(): %s",
                load_btn.handle,
                exc,
            )

            load_btn.click_input()

        time.sleep(0.5)

        file_dlg = self._find_file_dialog(
            timeout=10
        )

        if file_dlg is None:
            raise RuntimeError(
                "После Load не открылся "
                "стандартный диалог выбора SET"
            )

        edit = self._filename_edit(
            file_dlg
        )

        target_dir = str(
            set_path.parent
        )

        try:
            file_dlg.set_focus()

            send_keys("%d")
            time.sleep(0.2)

            send_keys(
                target_dir,
                with_spaces=True,
            )

            send_keys("{ENTER}")
            time.sleep(0.5)

        except Exception as exc:
            raise RuntimeError(
                f"Не удалось перейти в папку SET: "
                f"{target_dir}: {exc}"
            ) from exc

        edit = self._filename_edit(
            file_dlg
        )

        edit.set_edit_text(
            set_path.name
        )

        self._click_open_in_file_dialog(
            file_dlg
        )

        time.sleep(0.8)

        self._click_ok(
            dlg
        )

        time.sleep(0.8)

        LOG.info(
            "SET применён и окно свойств "
            "подтверждено: %s",
            set_path.name,
        )