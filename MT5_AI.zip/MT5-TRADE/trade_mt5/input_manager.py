import json
import logging
import re
from pathlib import Path
from tempfile import NamedTemporaryFile

LOG = logging.getLogger(__name__)
PROFIT_RE = re.compile(r"\+(-?\d+(?:[.,]\d+)?)pln-", re.IGNORECASE)
SYMBOL_RE = re.compile(r"^([A-Z0-9_]{3,20})-", re.IGNORECASE)


class InputManager:
    """Permanent trading settings store.

    Files are never deleted after successful application. A new file replaces
    the previous file only after it has been fully written and validated.
    """
    def __init__(self, input_dir):
        self.input_dir = Path(input_dir)
        self.input_dir.mkdir(parents=True, exist_ok=True)
        self.marker = self.input_dir / "optimization_complete.json"

    def list_sets(self):
        return [p for p in self.input_dir.glob("*.set") if p.is_file()]

    @staticmethod
    def symbol_from_filename(path):
        m = SYMBOL_RE.match(path.name)
        return m.group(1).upper() if m else None

    @staticmethod
    def profit_from_filename(path):
        m = PROFIT_RE.search(path.name)
        if not m:
            return None
        return float(m.group(1).replace(",", "."))

    def latest_batch(self):
        if not self.marker.exists():
            return None
        try:
            data = json.loads(self.marker.read_text(encoding="utf-8"))
            if not data.get("cycle_finished") and not data.get("complete"):
                return None
            return data
        except Exception:
            return None

    def pending_by_symbol(self):
        """Return the single highest-Profit SET for each symbol.

        ``-compl`` is a completion marker, not a quality tier.  Therefore the
        highest-Profit file is selected from *all* files for the symbol first.
        If that best file is already marked ``-compl``, the symbol is complete
        and lower-Profit files are never considered.
        """
        groups = {}
        for p in self.list_sets():
            symbol = self.symbol_from_filename(p)
            if not symbol:
                LOG.warning("SET пропущен: не удалось определить символ из имени %s", p.name)
                continue
            profit = self.profit_from_filename(p)
            groups.setdefault(symbol, []).append((profit, p))

        out = {}
        for symbol, items in sorted(groups.items()):
            with_profit = [(profit, p) for profit, p in items if profit is not None]
            if with_profit:
                chosen_profit, chosen = max(with_profit, key=lambda x: (x[0], x[1].name))
                LOG.info(
                    "SET для %s: максимальный Profit=%.2f | %s | кандидатов=%d",
                    symbol, chosen_profit, chosen.name, len(items)
                )
            else:
                chosen = max(items, key=lambda x: x[1].stat().st_mtime)[1]
                chosen_profit = None
                LOG.warning(
                    "SET для %s: Profit не найден; выбран самый новый | %s",
                    symbol, chosen.name
                )

            if chosen.stem.lower().endswith("-compl"):
                LOG.info("%s: лучший SET уже отмечен -compl — символ полностью завершён", symbol)
                continue

            out[symbol] = chosen
        return out

    @staticmethod
    def mark_completed(path):
        """Rename a successfully applied SET by adding the -compl marker."""
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(path)
        if path.stem.lower().endswith("-compl"):
            return path
        target = path.with_name(path.stem + "-compl" + path.suffix)
        if target.exists():
            raise FileExistsError(f"Нельзя отметить SET как compl: файл уже существует: {target.name}")
        path.rename(target)
        LOG.info("SET отмечен как успешно применённый: %s", target.name)
        return target

    @staticmethod
    def validate_set(path):
        path = Path(path)
        if not path.exists() or path.stat().st_size < 100:
            return False
        data = path.read_bytes()
        if b"RiskPercent" not in data and "RiskPercent" not in path.read_text(encoding="utf-16", errors="ignore"):
            return False
        return True


    def publish_best_files(self, files, expected_symbols, batch_id, allow_partial=False, cycle_complete=None, cycle_completed_symbols=None):
        """Publish exactly one highest-Profit SET per expected symbol from one cycle.

        This method never falls back to older files already present in
        ADVISOR_SETTINGS_DIR. The caller supplies the files produced by the
        current successful optimization cycle. Publication is atomic per
        symbol and the completion marker is written only after every expected
        symbol has a valid current-cycle SET.
        """
        expected = {str(s).upper() for s in expected_symbols}
        groups = {}
        for raw in files:
            p = Path(raw)
            symbol = self.symbol_from_filename(p)
            profit = self.profit_from_filename(p)
            if not symbol or symbol not in expected or profit is None or not self.validate_set(p):
                continue
            groups.setdefault(symbol, []).append((profit, p))

        missing = sorted(expected - set(groups))
        if missing and not allow_partial:
            raise RuntimeError(
                "Нельзя публиковать неполный цикл оптимизации. "
                f"Нет валидного SET для: {', '.join(missing)}"
            )

        published = {}
        symbols_to_publish = sorted(set(groups) & expected)
        for symbol in symbols_to_publish:
            profit, source = max(groups[symbol], key=lambda x: (x[0], x[1].name))
            target = self.input_dir / source.name
            with NamedTemporaryFile(
                dir=self.input_dir, prefix=f".{symbol}.", suffix=".tmp", delete=False
            ) as tmp:
                tmp_path = Path(tmp.name)
                tmp.write(source.read_bytes())
                tmp.flush()
            tmp_path.replace(target)

            for old in self.list_sets():
                if old != target and self.symbol_from_filename(old) == symbol:
                    try:
                        old.unlink()
                    except OSError:
                        LOG.exception("Не удалось удалить старый SET %s", old)

            published[symbol] = {
                "filename": target.name,
                "profit": profit,
                "sha256": __import__("hashlib").sha256(target.read_bytes()).hexdigest(),
            }

        # This marker is the handoff report for MT5-TRADE. It is written even
        # for a partial cycle: every currency was attempted, successful fresh
        # SETs are listed in ``published``, and missing currencies are explicit.
        # The trading Python therefore never needs to guess whether a cycle
        # finished or which settings belong to it.
        cycle_complete = bool(cycle_complete) if cycle_complete is not None else (not missing)
        completed_cycle = sorted(set(str(s).upper() for s in (cycle_completed_symbols or published)) & expected)
        cycle_missing = sorted(expected - set(completed_cycle))
        marker_data = {
            "complete": cycle_complete,
            "partial": not cycle_complete,
            "cycle_finished": True,
            "batch_id": batch_id,
            "finished_at": __import__("datetime").datetime.now().astimezone().isoformat(timespec="seconds"),
            "expected_symbols": sorted(expected),
            "published_symbols": sorted(published),
            "completed_cycle_symbols": completed_cycle,
            "missing_symbols": cycle_missing,
            "symbols": sorted(published),
            "published": published,
        }
        marker = self.input_dir / "optimization_complete.json"
        marker.write_text(
            json.dumps(marker_data, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        report = self.input_dir / "optimization_cycle_report.json"
        report.write_text(
            json.dumps(marker_data, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        return published

    def publish_best_from_final(self, final_dir, batch_id):
        """Utility used by the optimizer handoff.

        Selects exactly one highest-profit SET per symbol from final_dir and
        atomically replaces that symbol's permanent input file. It does not
        remove any previous trading file for symbols absent from this batch.
        """
        final_dir = Path(final_dir)
        groups = {}
        for p in final_dir.glob("*.set"):
            symbol = self.symbol_from_filename(p)
            profit = self.profit_from_filename(p)
            if not symbol or profit is None or not self.validate_set(p):
                continue
            groups.setdefault(symbol, []).append((profit, p))

        published = {}
        for symbol, items in groups.items():
            items.sort(key=lambda x: (x[0], x[1].name), reverse=True)
            source = items[0][1]
            target = self.input_dir / source.name
            # Remove old SET(s) for this symbol only after the new file is
            # fully copied. The previous file therefore remains intact until
            # the replacement is ready.
            with NamedTemporaryFile(dir=self.input_dir, prefix=f".{symbol}.", suffix=".tmp", delete=False) as tmp:
                tmp_path = Path(tmp.name)
                tmp.write(source.read_bytes())
                tmp.flush()
            tmp_path.replace(target)
            for old in self.list_sets():
                if old != target and self.symbol_from_filename(old) == symbol:
                    try:
                        old.unlink()
                    except OSError:
                        LOG.exception("Не удалось удалить старый SET %s", old)
            published[symbol] = {"filename": target.name, "profit": items[0][0]}

        marker = self.input_dir / "optimization_complete.json"
        marker.write_text(json.dumps({
            "complete": True,
            "batch_id": batch_id,
            "symbols": sorted(published),
            "published": published,
        }, indent=2, ensure_ascii=False), encoding="utf-8")
        return published
