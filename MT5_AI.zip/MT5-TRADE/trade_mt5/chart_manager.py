﻿from __future__ import annotations

import os
import time
import uuid
from pathlib import Path


class ChartManagerBridge:
    """Non-GUI bridge to the MQL5 chart manager EA.

    Python only writes/reads files in the MT5 common Files directory.
    It never activates the terminal, sends keyboard input, moves the mouse,
    or selects a chart.
    """

    def __init__(
        self,
        common_files: str | Path | None = None,
        timeout: float = 20.0,
    ):
        self.timeout = float(timeout)

        self.common_files = Path(common_files) if common_files else (
            Path(os.environ["APPDATA"])
            / "MetaQuotes"
            / "Terminal"
            / "Common"
            / "Files"
        )

        self.req = self.common_files / "MT5_AI" / "chart_manager.req"
        self.res = self.common_files / "MT5_AI" / "chart_manager.res"

    def _send(self, command: str, request_id: str) -> str:
        self.req.parent.mkdir(parents=True, exist_ok=True)

        try:
            self.res.unlink()
        except FileNotFoundError:
            pass

        tmp = self.req.with_suffix(".tmp")
        tmp.write_text(command, encoding="ascii")
        os.replace(tmp, self.req)

        deadline = time.time() + self.timeout

        while time.time() < deadline:
            try:
                response = self.res.read_text(
                    encoding="cp1252"
                ).strip()
            except (
                FileNotFoundError,
                PermissionError,
                OSError,
            ):
                response = ""

            if response.startswith("DONE|" + request_id + "|"):
                try:
                    self.req.unlink()
                except FileNotFoundError:
                    pass

                return response

            if response.startswith("ERROR|" + request_id + "|"):
                try:
                    self.req.unlink()
                except FileNotFoundError:
                    pass

                raise RuntimeError(
                    "MT5 chart manager: " + response
                )

            time.sleep(0.25)

        raise TimeoutError(
            f"MT5 chart manager не ответил за "
            f"{self.timeout:.0f} с: {command}"
        )

    def open_and_apply_template(
        self,
        symbol: str,
        timeframe: str,
        template: str,
    ) -> str:
        """Create/find SYMBOL,TIMEFRAME and apply the template."""

        request_id = uuid.uuid4().hex

        command = (
            f"OPEN_TEMPLATE|"
            f"{request_id}|"
            f"{symbol}|"
            f"{timeframe}|"
            f"{template}"
        )

        return self._send(command, request_id)

    def get_chart_expert(
        self,
        symbol: str,
        timeframe: str,
    ) -> str:
        """Return EA name reported by MT5 for SYMBOL,TIMEFRAME."""

        request_id = uuid.uuid4().hex

        command = (
            f"GET_EXPERT|"
            f"{request_id}|"
            f"{symbol}|"
            f"{timeframe}"
        )

        response = self._send(command, request_id)

        # Expected:
        # DONE|request_id|symbol|timeframe|chart_id|expert
        parts = response.split("|", 5)

        if len(parts) < 6:
            raise RuntimeError(
                f"Некорректный ответ MT5 chart manager: {response}"
            )

        return parts[5].strip()