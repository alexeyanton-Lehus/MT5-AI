@echo off
cd /d C:\MT5_AI\MT5-TRADE
python .\main.py
pause
