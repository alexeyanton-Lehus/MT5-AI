"""Live MT5 optimization dashboard with editable selection criteria."""
from __future__ import annotations

import json
import tkinter as tk
from datetime import datetime
from pathlib import Path
from tkinter import messagebox, ttk

ROOT = Path(__file__).resolve().parent.parent
STATUS_FILE = ROOT / "working" / "optimization_progress.json"
STATE_FILE = Path(__file__).resolve().parent / "autonomous_state.json"
FILTERS_FILE = ROOT / "config" / "optimization_filters.json"

OPTIMIZATION_FIELDS = [
    ("optimization_filter_result_2", "Result №2 — базовый минимум", "Число"),
    ("optimization_filter_profitability", "Profit Factor — базовый минимум", "Число"),
    ("optimization_filter_drawdown", "Relative DD — максимум, %", "Число"),
    ("optimization_filter_recovery", "Recovery Factor — базовый минимум", "Число"),
    ("optimization_filter_sharpe", "Sharpe Ratio — базовый минимум", "Число"),
    ("result_2_start", "Result №2 — старт FINAL_TEST", "Число"),
    ("result_2_step", "Result №2 — шаг ослабления", "Число"),
    ("result_2_min", "Result №2 — минимум", "Число"),
    ("profitability_start", "Profit Factor — старт FINAL_TEST", "Число"),
    ("profitability_step", "Profit Factor — шаг ослабления", "Число"),
    ("profitability_min", "Profit Factor — минимум", "Число"),
    ("recovery_start", "Recovery Factor — старт FINAL_TEST", "Число"),
    ("recovery_step", "Recovery Factor — шаг ослабления", "Число"),
    ("recovery_min", "Recovery Factor — минимум", "Число"),
    ("sharpe_start", "Sharpe Ratio — старт FINAL_TEST", "Число"),
    ("sharpe_step_factor", "Sharpe Ratio — множитель шага", "Множитель"),
    ("sharpe_min", "Sharpe Ratio — минимум", "Число"),
]

TEST_FIELDS = [
    ("drawdown", "Relative DD — максимум, %", "Число"),
    ("lr_correlation", "LR Correlation — минимум", "Число"),
    ("single_test_win", "Win % — минимум", "Процент"),
    ("single_test_ontester", "OnTester — минимум", "Число"),
]


def read_json(path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def write_json_atomic(path, data):
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    tmp.replace(path)


def fmt_time(value):
    if not value:
        return "—"
    try:
        return datetime.fromisoformat(value).astimezone().strftime("%d.%m.%Y %H:%M:%S")
    except Exception:
        return str(value)


def elapsed(start, end=None):
    if not start:
        return "—"
    try:
        a = datetime.fromisoformat(start)
        b = datetime.fromisoformat(end) if end else datetime.now().astimezone()
        sec = max(0, int((b - a).total_seconds()))
        d, sec = divmod(sec, 86400)
        h, sec = divmod(sec, 3600)
        m, s = divmod(sec, 60)
        return f"{d}д {h:02d}:{m:02d}:{s:02d}" if d else f"{h:02d}:{m:02d}:{s:02d}"
    except Exception:
        return "—"


class Dashboard:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("MT5 AI — оптимизация")
        self.root.geometry("920x700")
        self.root.minsize(760, 600)
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self.closed = False
        self.vars = {}
        self.filter_vars = {}

        notebook = ttk.Notebook(self.root)
        notebook.pack(fill="both", expand=True, padx=10, pady=10)

        status_tab = ttk.Frame(notebook, padding=14)
        optimization_tab = ttk.Frame(notebook, padding=14)
        tests_tab = ttk.Frame(notebook, padding=14)
        notebook.add(status_tab, text="Статус")
        notebook.add(optimization_tab, text="Оптимизация")
        notebook.add(tests_tab, text="Тесты")

        self._build_status(status_tab)
        self._build_criteria_tab(optimization_tab, OPTIMIZATION_FIELDS, "Критерии отбора кандидатов после оптимизации")
        self._build_criteria_tab(tests_tab, TEST_FIELDS, "Критерии отбора после одиночного теста")

        self.root.after(1000, self.refresh)

    def _build_status(self, frame):
        ttk.Label(frame, text="MT5 AI — СТАТУС ОПТИМИЗАЦИИ", font=("Segoe UI", 15, "bold")).pack(anchor="w", pady=(0, 12))
        self.status = ttk.Label(frame, text="Состояние: —", font=("Segoe UI", 11, "bold"))
        self.status.pack(anchor="w")
        self.progress = ttk.Progressbar(frame, mode="determinate", maximum=100)
        self.progress.pack(fill="x", pady=(8, 12))
        rows = [
            ("Текущая валюта", "symbol"), ("Валюты", "symbols"), ("Этап", "stage"),
            ("Начало", "started"), ("Время работы", "elapsed"), ("Последнее событие", "event"),
            ("Ошибки/пропуски", "failed"), ("Следующая автооптимизация", "next"),
        ]
        for label, key in rows:
            row = ttk.Frame(frame); row.pack(fill="x", pady=3)
            ttk.Label(row, text=label + ":", width=27).pack(side="left")
            var = tk.StringVar(value="—"); self.vars[key] = var
            ttk.Label(row, textvariable=var, wraplength=600).pack(side="left", fill="x", expand=True)
        ttk.Label(frame, text="Статус читается из working\\optimization_progress.json.", foreground="#666").pack(anchor="w", pady=(14, 0))

    def _build_criteria_tab(self, frame, fields, description):
        ttk.Label(frame, text=description, font=("Segoe UI", 12, "bold")).pack(anchor="w", pady=(0, 10))
        ttk.Label(frame, text="Изменения сохраняются в config\\optimization_filters.json и используются существующим кодом отбора.", foreground="#666", wraplength=820).pack(anchor="w", pady=(0, 12))

        canvas = tk.Canvas(frame, highlightthickness=0)
        scrollbar = ttk.Scrollbar(frame, orient="vertical", command=canvas.yview)
        body = ttk.Frame(canvas)
        body.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=body, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        for row_no, (key, label, unit) in enumerate(fields):
            ttk.Label(body, text=label, width=43).grid(row=row_no, column=0, sticky="w", padx=(0, 10), pady=5)
            var = tk.StringVar()
            self.filter_vars[key] = var
            ttk.Entry(body, textvariable=var, width=18).grid(row=row_no, column=1, sticky="w", pady=5)
            ttk.Label(body, text=unit, foreground="#666").grid(row=row_no, column=2, sticky="w", padx=8, pady=5)

        buttons = ttk.Frame(frame); buttons.pack(fill="x", pady=(12, 0))
        ttk.Button(buttons, text="Сохранить критерии", command=self.save_filters).pack(side="left")
        ttk.Button(buttons, text="Загрузить из файла", command=self.load_filters).pack(side="left", padx=8)
        self.filter_message = ttk.Label(buttons, text="", foreground="#666")
        self.filter_message.pack(side="left", padx=8)
        self.load_filters()

    def load_filters(self):
        data = read_json(FILTERS_FILE)
        for key, var in self.filter_vars.items():
            if key in data:
                var.set(str(data[key]))
        if hasattr(self, "filter_message"):
            self.filter_message.config(text="Значения загружены")

    def save_filters(self):
        data = read_json(FILTERS_FILE)
        try:
            for key, var in self.filter_vars.items():
                value = float(var.get().strip().replace(",", "."))
                data[key] = int(value) if value.is_integer() else value
        except ValueError:
            messagebox.showerror("Ошибка", "Все критерии должны содержать числовые значения.")
            return
        try:
            write_json_atomic(FILTERS_FILE, data)
        except Exception as exc:
            messagebox.showerror("Ошибка сохранения", str(exc))
            return
        self.filter_message.config(text="Сохранено")

    def refresh(self):
        if self.closed:
            return
        data = read_json(STATUS_FILE)
        state = read_json(STATE_FILE)
        status = data.get("status", "IDLE")
        self.status.config(text=f"Состояние: {status}")
        total = int(data.get("total_symbols") or 0)
        completed = len(data.get("completed_symbols") or [])
        failed = len(data.get("failed_symbols") or [])
        self.progress["value"] = min(100, 100 * (completed + failed) / total) if total else 0
        symbol = data.get("current_symbol") or "—"
        idx = data.get("current_symbol_index") or 0
        self.vars["symbol"].set(f"{symbol} ({idx}/{total})" if total and symbol != "—" else symbol)
        self.vars["symbols"].set(f"завершено {completed} | пропущено {failed} | всего {total}")
        stage = data.get("current_stage"); stage_no = data.get("current_stage_number") or 0; total_stages = data.get("total_stages") or 4
        self.vars["stage"].set(f"{stage_no}/{total_stages} — {stage}" if stage else "—")
        self.vars["started"].set(fmt_time(data.get("started_at")))
        self.vars["elapsed"].set(elapsed(data.get("started_at"), data.get("completed_at")))
        self.vars["event"].set(data.get("last_event") or "—")
        failed_list = data.get("failed_symbols") or []
        self.vars["failed"].set(", ".join(failed_list) if failed_list else "нет")
        self.vars["next"].set(fmt_time(state.get("next_optimization_at") or state.get("retry_after")))
        self.root.after(1000, self.refresh)

    def close(self):
        self.closed = True
        self.root.destroy()


if __name__ == "__main__":
    Dashboard().root.mainloop()
