@echo off
setlocal
set "STATE=%~dp0autonomous_state.json"
if exist "%STATE%" del /f /q "%STATE%"
echo Расписание сброшено.
echo При следующем запуске будет разрешен ОДИН цикл, после которого следующий запуск — через 14 дней.
pause
