@echo off
setlocal
cd /d C:\MT5_AI\MT5-TRADE
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%CD%\uninstall_autostart.ps1"
if errorlevel 1 (
  echo.
  echo UNINSTALL FAILED.
  pause
  exit /b 1
)
echo.
echo AUTOSTART AND AUTOMATION REMOVED COMPLETELY.
pause
