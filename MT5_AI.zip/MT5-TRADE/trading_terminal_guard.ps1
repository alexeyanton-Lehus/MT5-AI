$ErrorActionPreference = 'Stop'

# ============================================================
# MT5-TRADE Trading Terminal Guard
# ============================================================
# Controls ONLY the trading MT5.
# NEVER stops any MT5 process.
# NEVER touches the optimization/test MT5.
# ============================================================

$Terminal = 'C:\Program Files\Ava Trade MT5 Terminal\terminal64.exe'
$TerminalDir = Split-Path -Parent $Terminal

# No start on weekends.
$day = (Get-Date).DayOfWeek
if ($day -in @([DayOfWeek]::Saturday, [DayOfWeek]::Sunday)) {
    exit 0
}

if (-not (Test-Path -LiteralPath $Terminal)) {
    throw "Trading MT5 not found: $Terminal"
}

$target = [IO.Path]::GetFullPath($Terminal)

# Find ONLY the trading MT5.
$running = @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
    Where-Object {
        $_.Name -ieq 'terminal64.exe' -and
        $_.ExecutablePath -and
        ([IO.Path]::GetFullPath($_.ExecutablePath) -ieq $target)
    })

# IMPORTANT:
# If the trading MT5 process exists, leave it alone.
# Do NOT check MainWindowHandle.
# Do NOT kill it.
if ($running.Count -gt 0) {
    exit 0
}

# Trading MT5 is completely absent -> start it.
Start-Process `
    -FilePath $Terminal `
    -WorkingDirectory $TerminalDir `
    -WindowStyle Minimized | Out-Null

exit 0