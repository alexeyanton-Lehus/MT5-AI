$ErrorActionPreference = 'Stop'
$Project = 'C:\MT5_AI\MT5-TRADE'
$Script = Join-Path $Project 'autonomous.py'
$TaskName = 'MT5-TRADE Autonomous'

if (-not (Test-Path $Script)) { throw "Не найден $Script" }

$Python = Join-Path $env:LOCALAPPDATA 'Programs\Python\Python313\pythonw.exe'
if (-not (Test-Path $Python)) {
    $Python = (Get-Command pythonw.exe -ErrorAction Stop).Source
}

Write-Host '=== INSTALL MT5-TRADE AUTOSTART ==='

# Remove legacy Startup-folder launchers that could create a second Python
# supervisor or a visible console. The trading MT5 executable is never touched.
$startup = [Environment]::GetFolderPath('Startup')
foreach ($name in @('run_autonomous.bat','MT5-TRADE Autonomous.lnk','MT5-TRADE.lnk')) {
    $f = Join-Path $startup $name
    if (Test-Path $f) {
        Remove-Item $f -Force -ErrorAction SilentlyContinue
        Write-Host "Removed legacy startup item: $f"
    }
}

# Remove only the old automation task/processes.
& (Join-Path $Project 'uninstall_autostart.ps1') | Out-Host

$Action = New-ScheduledTaskAction `
    -Execute $Python `
    -Argument ('"' + $Script + '"') `
    -WorkingDirectory $Project

# Start at user logon. The Python supervisor then keeps running and performs
# its own low-overhead hourly trading-MT5 check.
$Trigger = New-ScheduledTaskTrigger -AtLogOn -User "$env:USERDOMAIN\$env:USERNAME"

$Principal = New-ScheduledTaskPrincipal `
    -UserId "$env:USERDOMAIN\$env:USERNAME" `
    -LogonType Interactive `
    -RunLevel Highest

$Settings = New-ScheduledTaskSettingsSet `
    -StartWhenAvailable `
    -ExecutionTimeLimit (New-TimeSpan -Days 3650) `
    -RestartCount 999 `
    -RestartInterval (New-TimeSpan -Minutes 1)

Register-ScheduledTask `
    -TaskName $TaskName `
    -Action $Action `
    -Trigger $Trigger `
    -Principal $Principal `
    -Settings $Settings `
    -Force | Out-Null

Write-Host "OK: Scheduled Task installed: $TaskName"

# IMPORTANT:
# Installing an AtLogOn task while Windows is already logged in does NOT fire
# the logon trigger. Start it explicitly now so the trading MT5 can be launched
# immediately instead of waiting for the next Windows logon.
Start-ScheduledTask -TaskName $TaskName
Write-Host "OK: Scheduled Task started immediately."

# Give pythonw a few seconds to appear. This is installation-time verification,
# not a recurring polling loop.
$found = $false
for ($i = 1; $i -le 10; $i++) {
    $running = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
        $_.Name -in @('python.exe','pythonw.exe') -and
        $_.CommandLine -and
        $_.CommandLine -match '(?i)C:\\MT5_AI\\MT5-TRADE\\autonomous\.py'
    }
    if ($running) {
        $found = $true
        break
    }
    Start-Sleep -Seconds 1
}

if (-not $found) {
    throw "Задача установлена, но autonomous.py не запустился. Проверьте Планировщик заданий и MT5-TRADE\trade_python.log."
}

Write-Host 'OK: autonomous.py is running.'
Write-Host 'Trading MT5 is controlled ONLY by MT5-TRADE\autonomous.py.'
Write-Host 'Test MT5 is controlled ONLY by C:\MT5_AI\src\main.py.'
