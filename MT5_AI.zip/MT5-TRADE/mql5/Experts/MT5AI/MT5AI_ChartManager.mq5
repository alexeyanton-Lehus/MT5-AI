#property strict
#property version   "1.00"
#property description "MT5_AI chart creation/template manager. No mouse/keyboard/UI automation."

input string InpRequestFile  = "MT5_AI\\chart_manager.req";
input string InpResponseFile = "MT5_AI\\chart_manager.res";
input int    InpPollMs       = 500;

string g_last_request = "";

ENUM_TIMEFRAMES ParseTimeframe(const string tf)
{
   string x = tf;
   StringToUpper(x);
   if(x == "M1")  return PERIOD_M1;
   if(x == "M5")  return PERIOD_M5;
   if(x == "M15") return PERIOD_M15;
   if(x == "M30") return PERIOD_M30;
   if(x == "H1")  return PERIOD_H1;
   if(x == "H4")  return PERIOD_H4;
   if(x == "D1")  return PERIOD_D1;
   if(x == "W1")  return PERIOD_W1;
   if(x == "MN1") return PERIOD_MN1;
   return PERIOD_CURRENT;
}

long FindChart(const string symbol, const ENUM_TIMEFRAMES tf)
{
   long id = ChartFirst();
   while(id != -1)
   {
      if(ChartSymbol(id) == symbol && (ENUM_TIMEFRAMES)ChartPeriod(id) == tf)
         return id;
      id = ChartNext(id);
   }
   return -1;
}

bool WriteResponse(const string text)
{
   int h = FileOpen(InpResponseFile,
                    FILE_WRITE|FILE_TXT|FILE_ANSI|FILE_COMMON|FILE_SHARE_READ|FILE_SHARE_WRITE);
   if(h == INVALID_HANDLE)
      return false;
   FileWriteString(h, text);
   FileFlush(h);
   FileClose(h);
   return true;
}

bool ReadRequest(string &request)
{
   request = "";
   if(!FileIsExist(InpRequestFile, FILE_COMMON))
      return false;

   int h = FileOpen(InpRequestFile,
                    FILE_READ|FILE_TXT|FILE_ANSI|FILE_COMMON|FILE_SHARE_READ|FILE_SHARE_WRITE);
   if(h == INVALID_HANDLE)
      return false;

   request = FileReadString(h);
   FileClose(h);
   return (StringLen(request) > 0);
}

void ProcessRequest()
{
   string req;
   if(!ReadRequest(req))
      return;
   if(req == g_last_request)
      return;

   g_last_request = req;

   string parts[];
   int n = StringSplit(req, '|', parts);
   if(n < 5)
   {
      WriteResponse("ERROR|BAD_REQUEST|" + req);
      return;
   }

   string command = parts[0];
   string request_id = parts[1];
   string symbol = parts[2];
   string tf_text = parts[3];
   string template_name = parts[4];

   StringToUpper(command);
   if(command != "OPEN_TEMPLATE")
   {
      WriteResponse("ERROR|" + request_id + "|UNKNOWN_COMMAND");
      return;
   }

   ENUM_TIMEFRAMES tf = ParseTimeframe(tf_text);
   if(tf == PERIOD_CURRENT)
   {
      WriteResponse("ERROR|" + request_id + "|BAD_TIMEFRAME|" + tf_text);
      return;
   }

   ResetLastError();
   if(!SymbolSelect(symbol, true))
   {
      int err = GetLastError();
      WriteResponse("ERROR|" + request_id + "|SYMBOL_SELECT|" + IntegerToString(err));
      return;
   }

   long chart_id = FindChart(symbol, tf);
   if(chart_id == -1)
   {
      ResetLastError();
      chart_id = ChartOpen(symbol, tf);
      if(chart_id == 0)
      {
         int err = GetLastError();
         WriteResponse("ERROR|" + request_id + "|CHART_OPEN|" + IntegerToString(err));
         return;
      }
   }

   // ChartOpen and ChartApplyTemplate are chart-queue operations. Give the
   // terminal a short interval to materialize the new chart before applying
   // the template. This does not activate or click anything.
   Sleep(700);

   ResetLastError();
   if(!ChartApplyTemplate(chart_id, template_name))
   {
      int err = GetLastError();
      WriteResponse("ERROR|" + request_id + "|TEMPLATE|" + IntegerToString(err) + "|" + LongToString(chart_id));
      return;
   }

   // Applying a template is asynchronous. Wait until MT5 reports the EA
   // from the template on the target chart before acknowledging success.
   string expert = "";
   ulong deadline = GetTickCount64() + 10000;
   while(GetTickCount64() < deadline)
   {
      expert = ChartGetString(chart_id, CHART_EXPERT_NAME);
      if(StringLen(expert) > 0)
         break;
      Sleep(250);
   }

   ChartRedraw(chart_id);
   if(StringLen(expert) == 0)
   {
      WriteResponse("ERROR|" + request_id + "|TEMPLATE_EA_NOT_FOUND|" + LongToString(chart_id));
      return;
   }

   WriteResponse("DONE|" + request_id + "|" + symbol + "|" + tf_text + "|" + LongToString(chart_id) + "|" + expert);
}

int OnInit()
{
   int ms = InpPollMs;
   if(ms < 100) ms = 100;
   EventSetMillisecondTimer(ms);
   Print("MT5_AI_ChartManager started. Request=", InpRequestFile);
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
   EventKillTimer();
}

void OnTimer()
{
   ProcessRequest();
}
