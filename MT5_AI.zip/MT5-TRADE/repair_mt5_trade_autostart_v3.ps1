$ErrorActionPreference = 'Stop'

# MT5-TRADE autostart repair v3
# IMPORTANT:
# - Never stops the optimizer.
# - Never starts the test MT5.
# - Uses only the configured trading MT5.
# - Does not start a second autonomous.py if one is already running.
# - Does not use hand-written Task Scheduler XML.

$Project = 'C:\MT5_AI\MT5-TRADE'
$Autonomous = Join-Path $Project 'autonomous.py'
$Guard = Join-Path $Project 'trading_terminal_guard.ps1'
$Terminal = 'C:\Program Files\Ava Trade MT5 Terminal\terminal64.exe'

$SupervisorTask = 'MT5-TRADE Autonomous'
$GuardLogonTask = 'MT5-TRADE Trading Terminal Guard - Logon'
$GuardRepeatTask = 'MT5-TRADE Trading Terminal Guard - Every5Min'

if (-not (Test-Path -LiteralPath $Autonomous)) { throw "Не найден $Autonomous" }
if (-not (Test-Path -LiteralPath $Guard)) { throw "Не найден $Guard" }
if (-not (Test-Path -LiteralPath $Terminal)) { throw "Не найден торговый MT5: $Terminal" }

$Python = Join-Path $env:LOCALAPPDATA 'Programs\Python\Python313\pythonw.exe'
if (-not (Test-Path -LiteralPath $Python)) {
    $cmd = Get-Command pythonw.exe -ErrorAction SilentlyContinue
    if ($cmd) { $Python = $cmd.Source }
}
if (-not (Test-Path -LiteralPath $Python)) {
    throw "Не найден pythonw.exe"
}

$UserId = "$env:USERDOMAIN\$env:USERNAME"

Write-Host '=== MT5-TRADE AUTOSTART REPAIR v3 ==='
Write-Host "Project:       $Project"
Write-Host "Trading MT5:   $Terminal"
Write-Host "Python:        $Python"
Write-Host "Optimizer:     NOT TOUCHED"

# ---------------------------------------------------------------------------
# 1. Remove legacy/broken guard tasks.
# ---------------------------------------------------------------------------
foreach ($name in @(
    'MT5-TRADE Trading Terminal Guard',
    $GuardLogonTask,
    $GuardRepeatTask
)) {
    Unregister-ScheduledTask -TaskName $name -Confirm:$false -ErrorAction SilentlyContinue
}

# ---------------------------------------------------------------------------
# 2. Supervisor task: autonomous.py at Windows logon.
# ---------------------------------------------------------------------------
$ActionSupervisor = New-ScheduledTaskAction `
    -Execute $Python `
    -Argument ('"' + $Autonomous + '"') `
    -WorkingDirectory $Project

$TriggerSupervisor = New-ScheduledTaskTrigger `
    -AtLogOn `
    -User $UserId

$Principal = New-ScheduledTaskPrincipal `
    -UserId $UserId `
    -LogonType Interactive `
    -RunLevel Highest

$SettingsSupervisor = New-ScheduledTaskSettingsSet `
    -StartWhenAvailable `
    -ExecutionTimeLimit (New-TimeSpan -Days 3650) `
    -RestartCount 999 `
    -RestartInterval (New-TimeSpan -Minutes 1) `
    -MultipleInstances IgnoreNew

Register-ScheduledTask `
    -TaskName $SupervisorTask `
    -Action $ActionSupervisor `
    -Trigger $TriggerSupervisor `
    -Principal $Principal `
    -Settings $SettingsSupervisor `
    -Force | Out-Null

Write-Host "OK: supervisor task installed."

# ---------------------------------------------------------------------------
# 3. Independent trading-terminal guard at logon.
# ---------------------------------------------------------------------------
$GuardArgs = '-NoProfile -ExecutionPolicy Bypass -File "' + $Guard + '"'

$ActionGuard = New-ScheduledTaskAction `
    -Execute 'powershell.exe' `
    -Argument $GuardArgs `
    -WorkingDirectory $Project

$TriggerGuardLogon = New-ScheduledTaskTrigger `
    -AtLogOn `
    -User $UserId

$SettingsGuard = New-ScheduledTaskSettingsSet `
    -StartWhenAvailable `
    -ExecutionTimeLimit (New-TimeSpan -Minutes 5) `
    -MultipleInstances IgnoreNew

Register-ScheduledTask `
    -TaskName $GuardLogonTask `
    -Action $ActionGuard `
    -Trigger $TriggerGuardLogon `
    -Principal $Principal `
    -Settings $SettingsGuard `
    -Force | Out-Null

Write-Host "OK: logon trading-terminal guard installed."

# ---------------------------------------------------------------------------
# 4. Independent 5-minute trading-terminal guard.
#    No hand-written XML.
# ---------------------------------------------------------------------------
$firstRun = (Get-Date).AddMinutes(1)

$TriggerGuardRepeat = New-ScheduledTaskTrigger `
    -Once `
    -At $firstRun `
    -RepetitionInterval (New-TimeSpan -Minutes 5) `
    -RepetitionDuration (New-TimeSpan -Days 3650)

Register-ScheduledTask `
    -TaskName $GuardRepeatTask `
    -Action $ActionGuard `
    -Trigger $TriggerGuardRepeat `
    -Principal $Principal `
    -Settings $SettingsGuard `
    -Force | Out-Null

Write-Host "OK: 5-minute trading-terminal guard installed."

# ---------------------------------------------------------------------------
# 5. Start the independent trading-terminal guard NOW.
#    This is deliberately independent from autonomous.py/optimization.
# ---------------------------------------------------------------------------
Write-Host "Starting independent trading-terminal guard NOW..."
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $Guard

# ---------------------------------------------------------------------------
# 6. Start autonomous.py NOW only if it is not already running.
#    This prevents a second supervisor/second optimization process.
# ---------------------------------------------------------------------------
$runningAuto = @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
    $_.Name -in @('python.exe','pythonw.exe') -and
    $_.CommandLine -and
    $_.CommandLine -match '(?i)C:\\MT5_AI\\MT5-TRADE\\autonomous\.py'
})

if ($runningAuto.Count -eq 0) {
    Write-Host "autonomous.py is not running. Starting scheduled task NOW..."
    Start-ScheduledTask -TaskName $SupervisorTask -ErrorAction Stop
    Start-Sleep -Seconds 3
} else {
    Write-Host "OK: autonomous.py already running. Second instance NOT started."
}

# ---------------------------------------------------------------------------
# 7. Verify exact trading MT5 process.
# ---------------------------------------------------------------------------
$trading = @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
    $_.Name -ieq 'terminal64.exe' -and
    $_.ExecutablePath -and
    ([IO.Path]::GetFullPath($_.ExecutablePath) -ieq [IO.Path]::GetFullPath($Terminal))
})

if ($trading.Count -eq 0) {
    Write-Warning "Торговый MT5 сейчас НЕ обнаружен."
    Write-Warning "Проверка пути: Test-Path '$Terminal'"
    Write-Warning "Ручной запуск для проверки:"
    Write-Warning "Start-Process -FilePath '$Terminal' -WorkingDirectory '$(Split-Path $Terminal)' -WindowStyle Minimized"
} else {
    Write-Host "OK: trading MT5 RUNNING. PID(s): $($trading.pid -join ', ')"
}

Write-Host ''
Write-Host '=== REPAIR v3 COMPLETE ==='
Write-Host 'Test/optimization MT5 was NOT stopped or controlled.'
Write-Host 'Trading MT5 is controlled independently.'
