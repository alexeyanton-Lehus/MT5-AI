Set shell = CreateObject("WScript.Shell")

cmd = "powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File ""C:\MT5_AI\MT5-TRADE\trading_terminal_guard.ps1"""

shell.Run cmd, 0, False