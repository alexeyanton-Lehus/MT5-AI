"""Publish one highest-profit final SET per symbol to trading_input.

This is the handoff step the optimizer should call only after its entire
optimization cycle has completed successfully.
"""
import argparse
from datetime import datetime
from pathlib import Path
from trade_mt5.config import load_config
from trade_mt5.input_manager import InputManager


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--final-dir", required=True)
    args = ap.parse_args()
    cfg = load_config()
    manager = InputManager(cfg["trading_input"])
    batch_id = datetime.now().strftime("%Y%m%d-%H%M%S")
    published = manager.publish_best_from_final(Path(args.final_dir), batch_id)
    print(f"Опубликовано валют: {len(published)}")
    for symbol, info in sorted(published.items()):
        print(f"{symbol}: Profit={info['profit']} | {info['filename']}")


if __name__ == "__main__":
    main()
