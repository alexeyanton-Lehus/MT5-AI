﻿import json
import logging
import os
import subprocess
import sys
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path

import psutil

from trade_mt5.config import load_config
from trade_mt5.input_manager import InputManager
from trade_mt5.logging_setup import setup_logging
from trade_mt5.state import StateStore
from trade_mt5.terminal import TradingTerminal
from trade_mt5.ui import MT5UI

ROOT = Path(__file__).resolve().parent
PROJECT_ROOT = ROOT.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
WORKING_DIR = PROJECT_ROOT / "working"
STATE_FILE = ROOT / "autonomous_state.json"
ACTIVE_OPT_FILE = ROOT / "optimizer_active.json"
DASHBOARD_SCRIPT = ROOT / "optimization_dashboard.py"

LOG = logging.getLogger("autonomous")


def now_local():
    return datetime.now().astimezone()


def load_auto_state():
    if not STATE_FILE.exists():
        return {}
    try:
        return json.loads(STATE_FILE.read_text(encoding="utf-8-sig"))
    except Exception:
        LOG.exception("Не удалось прочитать %s", STATE_FILE)
        return {}


def save_auto_state(data):
    """
    Save autonomous state without allowing an accidental rollback of a
    valid future optimization schedule.
    """
    try:
        existing = {}

        if STATE_FILE.exists():
            try:
                raw = STATE_FILE.read_text(encoding="utf-8")
                if raw.strip():
                    loaded = json.loads(raw.lstrip("\ufeff"))
                    if isinstance(loaded, dict):
                        existing = loaded
            except Exception:
                LOG.exception(
                    "Не удалось прочитать существующий autonomous_state.json "
                    "перед сохранением."
                )

        # Preserve all existing fields unless explicitly updated.
        merged = dict(existing)
        merged.update(data)

        # A valid future optimization gate is authoritative.
        existing_gate_raw = existing.get("next_optimization_at")
        incoming_gate_raw = merged.get("next_optimization_at")

        if existing_gate_raw:
            try:
                existing_gate = datetime.fromisoformat(existing_gate_raw)

                if existing_gate.tzinfo is None:
                    existing_gate = existing_gate.astimezone()

                now = now_local()

                if existing_gate > now:
                    preserve_gate = False

                    if not incoming_gate_raw:
                        preserve_gate = True
                    else:
                        try:
                            incoming_gate = datetime.fromisoformat(
                                incoming_gate_raw
                            )

                            if incoming_gate.tzinfo is None:
                                incoming_gate = incoming_gate.astimezone()

                            if incoming_gate < existing_gate:
                                preserve_gate = True

                        except (TypeError, ValueError):
                            preserve_gate = True

                    if preserve_gate:
                        merged["next_optimization_at"] = existing_gate_raw

                        LOG.warning(
                            "Защищено будущее расписание оптимизации: %s "
                            "(попытка заменить на: %r)",
                            existing_gate_raw,
                            incoming_gate_raw,
                        )

            except (TypeError, ValueError):
                pass

        tmp = STATE_FILE.with_suffix(".tmp")

        tmp.write_text(
            json.dumps(
                merged,
                indent=2,
                ensure_ascii=False
            ),
            encoding="utf-8"
        )

        tmp.replace(STATE_FILE)

    except Exception:
        LOG.exception("Не удалось сохранить %s", STATE_FILE)
        raise

def in_trading_window(now, cfg):
    weekdays = set(cfg.get("weekdays", [0, 1, 2, 3, 4]))
    if now.weekday() not in weekdays:
        return False
    start = cfg.get("start", "00:00")
    end = cfg.get("end", "23:57")
    sh, sm = map(int, start.split(":"))
    eh, em = map(int, end.split(":"))
    start_dt = now.replace(hour=sh, minute=sm, second=0, microsecond=0)
    end_dt = now.replace(hour=eh, minute=em, second=59, microsecond=999999)
    return start_dt <= now <= end_dt


def optimizer_script():
    return PROJECT_ROOT / "src" / "main.py"


def expected_symbols():
    path = PROJECT_ROOT / "config" / "optimization_list.json"
    data = json.loads(path.read_text(encoding="utf-8"))
    return [str(x).upper() for x in data]


def start_dashboard():
    """Start one visible status window. It never controls MT5 or optimization."""
    try:
        for p in psutil.process_iter(["pid", "name", "cmdline"]):
            try:
                cmd = " ".join(p.info.get("cmdline") or [])
                if "optimization_dashboard.py" in cmd and str(ROOT).lower() in cmd.lower():
                    return
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        pythonw = Path(sys.executable)
        if pythonw.name.lower() != "pythonw.exe":
            candidate = pythonw.with_name("pythonw.exe")
            if candidate.exists():
                pythonw = candidate
        if not pythonw.exists():
            LOG.warning("Не найден pythonw.exe для информационного табло")
            return
        subprocess.Popen(
            [str(pythonw), str(DASHBOARD_SCRIPT)],
            cwd=str(ROOT),
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0) if sys.platform == "win32" else 0,
        )
        LOG.info("Информационное табло оптимизации запущено")
    except Exception:
        LOG.exception("Не удалось запустить информационное табло")


def optimizer_processes():
    """Return running src/main.py optimizer processes, including manual runs."""
    result = []
    script = str(optimizer_script()).lower()
    root = str(PROJECT_ROOT).lower()
    for p in psutil.process_iter(["pid", "name", "cmdline"]):
        try:
            name = (p.info.get("name") or "").lower()
            if name not in {"python.exe", "pythonw.exe"}:
                continue
            cmdline = " ".join(p.info.get("cmdline") or []).lower()
            if script in cmdline and root in cmdline:
                result.append(p.info["pid"])
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    return sorted(set(result))


def _owner_claim_alive():
    if not ACTIVE_OPT_FILE.exists():
        return False
    try:
        data = json.loads(ACTIVE_OPT_FILE.read_text(encoding="utf-8"))
        owner_pid = int(data.get("owner_pid") or 0)
        if owner_pid <= 0:
            return False
        proc = psutil.Process(owner_pid)
        cmdline = " ".join(proc.cmdline()).lower()
        return proc.is_running() and "autonomous.py" in cmdline and str(ROOT).lower() in cmdline
    except (ValueError, psutil.NoSuchProcess, psutil.AccessDenied, OSError):
        return False


def active_optimizer_pid():
    """Return live optimizer PID, or -1 when another supervisor owns the claim."""
    live = optimizer_processes()
    if live:
        return live[0]

    if ACTIVE_OPT_FILE.exists():
        if _owner_claim_alive():
            return -1
        try:
            ACTIVE_OPT_FILE.unlink()
        except OSError:
            pass
    return None


def write_active_optimizer(pid=None, started_at=None, owner_pid=None):
    data = {
        "optimizer_pid": pid,
        "owner_pid": owner_pid or os.getpid(),
        "started_at": started_at or now_local().isoformat(timespec="seconds"),
    }
    tmp = ACTIVE_OPT_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(ACTIVE_OPT_FILE)


def clear_active_optimizer():
    try:
        if ACTIVE_OPT_FILE.exists():
            ACTIVE_OPT_FILE.unlink()
    except OSError:
        LOG.exception("Не удалось удалить %s", ACTIVE_OPT_FILE)


def run_optimizer():
    """Run ONLY C:\\MT5_AI\\src\\main.py and wait until it really ends."""
    script = optimizer_script()
    if not script.exists():
        raise FileNotFoundError(script)

    already = active_optimizer_pid()
    if already is not None:
        if already == -1:
            raise RuntimeError("Другой экземпляр autonomous.py уже зарезервировал запуск оптимизации.")
        raise RuntimeError(f"Оптимизатор уже работает, PID={already}. Второй экземпляр запрещён.")

    LOG.info("Запуск тестового Python-оптимизатора: %s", script)
    python_exe = Path(sys.executable)
    if python_exe.name.lower() == "pythonw.exe":
        python_exe = python_exe.with_name("python.exe")
    if not python_exe.exists():
        raise FileNotFoundError(f"Не найден обычный Python для тестового оптимизатора: {python_exe}")

    optimizer_log = ROOT / "optimizer_autonomous.log"
    creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if sys.platform == "win32" else 0

    start_time = now_local()
    proc = None
    write_active_optimizer(None, start_time.isoformat(timespec="seconds"), os.getpid())
    try:
        with open(optimizer_log, "a", encoding="utf-8", buffering=1) as out:
            proc = subprocess.Popen(
                [str(python_exe), "-u", str(script)],
                cwd=str(PROJECT_ROOT),
                text=True,
                stdout=out,
                stderr=subprocess.STDOUT,
                creationflags=creationflags,
            )
            write_active_optimizer(proc.pid, start_time.isoformat(timespec="seconds"), os.getpid())
            LOG.info("Автоматическая оптимизация ЗАПУЩЕНА, PID=%s, время=%s", proc.pid, start_time.strftime("%H:%M:%S"))
            rc = proc.wait()

        if rc != 0:
            raise RuntimeError(f"Тестовый Python завершился с кодом {rc}")

        manifest_path = WORKING_DIR / "optimization_cycle_result.json"
        if not manifest_path.exists():
            raise RuntimeError("Оптимизатор не создал optimization_cycle_result.json")
        return json.loads(manifest_path.read_text(encoding="utf-8"))
    finally:
        clear_active_optimizer()


def publish_cycle(manifest):
    manager = InputManager(load_config()["trading_input"])
    symbols = expected_symbols()
    files = manifest.get("saved_files", [])
    batch_id = now_local().strftime("%Y%m%d-%H%M%S")
    published = manager.publish_best_files(
        files, symbols, batch_id, allow_partial=True,
        cycle_complete=bool(manifest.get("complete")),
        cycle_completed_symbols=manifest.get("completed_symbols", []),
    )
    missing = sorted(set(symbols) - set(published))
    LOG.info(
        "Новый batch опубликован: %s | свежих символов=%d | без свежего SET=%s",
        batch_id, len(published), ", ".join(missing) if missing else "нет"
    )
    return batch_id, published


def current_batch_application_status(cfg):
    """Return (complete, missing_symbols) for the latest published batch.

    Optimization completion and MT5 application completion are separate
    states.  A 14-day optimization schedule may be committed only after every
    SET published by the completed optimization cycle has been marked -compl.
    """
    try:
        marker_path = Path(cfg["trading_input"]) / "optimization_complete.json"
        if not marker_path.exists():
            return False, []
        marker = json.loads(marker_path.read_text(encoding="utf-8"))
        if marker.get("complete") is not True:
            return False, []

        expected = {str(s).upper() for s in marker.get("published_symbols", [])}
        if not expected:
            expected = {str(s).upper() for s in marker.get("expected_symbols", [])}
        if not expected:
            return False, []

        manager = InputManager(cfg["trading_input"])
        applied = set()
        for path in manager.list_sets():
            if path.stem.lower().endswith("-compl"):
                symbol = manager.symbol_from_filename(path)
                if symbol:
                    applied.add(symbol.upper())

        missing = sorted(expected - applied)
        return not missing, missing
    except Exception:
        LOG.exception("Не удалось проверить состояние применения текущего batch")
        return False, []


def retry_apply_schedule(state, retry_at=None):
    """Schedule a retry of SET application without touching the 14-day optimization gate."""
    retry_at = retry_at or (now_local() + timedelta(minutes=5))
    state["next_apply_at"] = retry_at.isoformat(timespec="seconds")
    state["retry_after"] = retry_at.isoformat(timespec="seconds")
    return retry_at


def finalize_application_schedule(state):
    """Mark SET application as complete without changing the 14-day optimization gate."""
    state.pop("next_apply_at", None)
    state.pop("retry_after", None)
    state.pop("last_failed_optimization_at", None)
    save_auto_state(state)


def commit_schedule_after_application(state, cfg, marker_path):
    """Commit the 14-day optimization schedule after the current batch is applied.

    This function is kept as the public compatibility hook used by src/main.py.
    SET application state is separate from the optimization schedule.
    """
    marker_path = Path(marker_path)
    if not marker_path.exists():
        raise RuntimeError(f"Не найден marker завершённого batch: {marker_path}")

    marker = json.loads(marker_path.read_text(encoding="utf-8"))
    if marker.get("complete") is not True and marker.get("cycle_finished") is not True:
        raise RuntimeError("Текущий optimization batch ещё не отмечен как завершённый")

    finished_raw = (
        marker.get("finished_at")
        or state.get("last_optimization_finished_at")
        or now_local().isoformat(timespec="seconds")
    )
    try:
        completed_at = datetime.fromisoformat(finished_raw)
    except Exception as exc:
        raise RuntimeError(f"Некорректный finished_at в marker: {finished_raw!r}") from exc
    if completed_at.tzinfo is None:
        completed_at = completed_at.astimezone()

    schedule_next(state, completed_at, cfg, complete=True)
    state.pop("next_apply_at", None)
    state.pop("retry_after", None)
    state.pop("last_failed_optimization_at", None)
    save_auto_state(state)
    return state["next_optimization_at"]


def apply_pending(cfg, force=False):
    terminal = TradingTerminal(cfg["trading_mt5_path"])
    pids = terminal.pids()
    if not pids:
        return 0
    if len(pids) != 1:
        raise RuntimeError(f"Найдено несколько экземпляров торгового MT5: {pids}")

    pid = pids[0]
    terminal.pid = pid
    manager = InputManager(cfg["trading_input"])
    state = StateStore(Path(cfg["trading_input"]) / "trade_state.json")
    ui = MT5UI(pid, cfg["expert_name"], cfg.get("timeframe", "H4"))
    ui.connect()

    pending = manager.pending_by_symbol()
    applied = 0
    batch = manager.latest_batch() or {}
    for symbol, set_path in sorted(pending.items()):
        try:
            current_hash = state.installed_hash(symbol)
            same = False
            if current_hash:
                try:
                    same = StateStore.sha256(set_path) == current_hash
                except OSError:
                    same = False
            if same and not force:
                continue

            timeframe = cfg.get("timeframe", "H4")
            LOG.info("Применение актуального SET: %s -> %s", symbol, set_path.name)
            if not ui.chart_exists(symbol, timeframe):
                ui.open_chart(symbol, timeframe)
            ui.select_chart(symbol, timeframe)
            if not ui.chart_has_target_ea(symbol, timeframe):
                LOG.error("%s,%s: наш EA не подтверждён; SET НЕ загружается", symbol, timeframe)
                continue
            ui.load_set_in_properties(set_path, symbol=symbol, timeframe=timeframe)
            completed = manager.mark_completed(set_path)
            state.mark_installed(symbol, completed, batch.get("batch_id"))
            applied += 1
            LOG.info("%s: SET применён и отмечен как completed", symbol)
        except Exception as exc:
            # One bad chart/symbol must not abort the whole batch. The SET stays
            # pending and will be retried on the next pass.
            LOG.exception("%s: SET НЕ применён; продолжаю остальные валюты: %s", symbol, exc)
            continue
    return applied


def launch_trading_mt5_if_allowed(cfg, now=None):
    """Compatibility API for src/main.py.

    Manual and autonomous optimization use the same trading-terminal launcher.
    It may start ONLY the configured trading MT5 and ONLY inside the configured
    trading window. It never starts or controls the test MT5.
    """
    current = now or now_local()
    if not in_trading_window(current, cfg.get("trading_window", {})):
        LOG.info("MANUAL/AUTO HANDOFF: вне торгового окна — торговый MT5 не запускается")
        return False
    return ensure_trading_terminal(cfg, "ОПТИМИЗАЦИОННЫЙ HANDOFF")


def ensure_trading_terminal(cfg, reason="WATCHDOG"):
    try:
        terminal = TradingTerminal(cfg["trading_mt5_path"])
        pids = terminal.pids()
        if len(pids) > 1:
            raise RuntimeError(f"Найдено несколько экземпляров торгового MT5: {pids}")
        if pids:
            LOG.info("%s: торговый MT5 уже запущен, PID=%s", reason, pids[0])
            return True
        if not in_trading_window(now_local(), cfg.get("trading_window", {})):
            LOG.info("%s: вне торгового окна — торговый MT5 не запускается", reason)
            return False
        LOG.warning("%s: торговый MT5 отсутствует. Запускаю: %s", reason, terminal.path)
        pid = terminal.start(timeout=60)
        LOG.info("%s: торговый MT5 ЗАПУЩЕН, PID=%s", reason, pid)
        return True
    except Exception as exc:
        LOG.exception("%s: НЕ УДАЛОСЬ ЗАПУСТИТЬ торговый MT5: %s", reason, exc)
        return False


OPTIMIZATION_HOUR = 20
OPTIMIZATION_MINUTE = 30


def next_scheduled_optimization(now, interval_days=14):
    """Return the next fixed 20:30 local-time optimization slot."""
    candidate = now.replace(
        hour=OPTIMIZATION_HOUR, minute=OPTIMIZATION_MINUTE,
        second=0, microsecond=0
    )
    if candidate <= now:
        # If the supervisor is installed after today's 20:30 slot, the first
        # scheduled slot is tomorrow at 20:30. After a completed cycle,
        # schedule_next() explicitly uses +interval_days at the fixed 20:30 time.
        candidate += timedelta(days=1)
    return candidate


def initialize_schedule(state, now, cfg):
    """Restore the optimization schedule.

    A valid future next_optimization_at is authoritative. Stale cycle markers,
    optimization_progress.json and SET-application state must never pull the
    next optimization forward.
    """
    gate = state.get("next_optimization_at")

    # HARD RULE:
    # If the persisted gate is valid and still in the future, return it
    # immediately. Do not inspect old cycle/progress files at all.
    if gate:
        try:
            due = datetime.fromisoformat(gate)
            if due.tzinfo is None:
                due = due.astimezone()
            if due > now:
                return due
        except Exception:
            LOG.warning(
                "Некорректный next_optimization_at=%r; расписание будет пересоздано.",
                gate,
            )

    # The gate is missing/expired. Only now may an actually unfinished cycle
    # affect the schedule. This is relevant when an optimization really was
    # interrupted after its scheduled start.
    cycle_state = WORKING_DIR / "optimization_cycle_state.json"
    cycle_result = WORKING_DIR / "optimization_cycle_result.json"
    unfinished = False
    cycle_started_at = None
    result_complete = False

    if cycle_result.exists():
        try:
            result_data = json.loads(cycle_result.read_text(encoding="utf-8"))
            result_complete = result_data.get("complete") is True
        except Exception:
            result_complete = False

    if cycle_state.exists():
        try:
            cycle_data = json.loads(cycle_state.read_text(encoding="utf-8"))
            if cycle_data.get("complete") is False and not result_complete:
                raw_started = cycle_data.get("cycle_started_at")
                if raw_started:
                    try:
                        cycle_started_at = datetime.fromisoformat(raw_started)
                        if cycle_started_at.tzinfo is None:
                            cycle_started_at = cycle_started_at.astimezone()
                    except Exception:
                        cycle_started_at = None

                last_success_raw = (
                    state.get("last_successful_optimization_at")
                    or state.get("last_optimization_finished_at")
                )
                last_success = None
                if last_success_raw:
                    try:
                        last_success = datetime.fromisoformat(last_success_raw)
                        if last_success.tzinfo is None:
                            last_success = last_success.astimezone()
                    except Exception:
                        last_success = None

                if last_success is None or cycle_started_at is None or cycle_started_at > last_success:
                    unfinished = True
        except Exception:
            unfinished = False

    if unfinished:
        due = now.replace(microsecond=0)
        state["next_optimization_at"] = due.isoformat(timespec="seconds")
        state.pop("retry_after", None)
        save_auto_state(state)
        LOG.info(
            "Обнаружен действительно незавершённый цикл — повторная оптимизация "
            "разрешена немедленно: %s",
            state["next_optimization_at"],
        )
        return due

    interval = int(cfg.get("optimization_schedule", {}).get("interval_days", 14))
    due = next_scheduled_optimization(now, interval)
    state["next_optimization_at"] = due.isoformat(timespec="seconds")
    state.pop("retry_after", None)
    save_auto_state(state)
    LOG.info(
        "Расписание автоматической оптимизации создано заново: %s",
        state["next_optimization_at"],
    )
    return due


def cycle_due(state, now, cfg):
    due_at = initialize_schedule(state, now, cfg)
    return now >= due_at


def schedule_next(state, completed_at, cfg, complete=True):
    interval = int(cfg.get("optimization_schedule", {}).get("interval_days", 14))
    # Keep the optimization time fixed at 20:30; the next cycle is not
    # shifted by the duration of the current optimization.
    next_date = completed_at + timedelta(days=interval)
    due = next_date.replace(
        hour=OPTIMIZATION_HOUR, minute=OPTIMIZATION_MINUTE,
        second=0, microsecond=0
    )
    state["next_optimization_at"] = due.isoformat(timespec="seconds")
    state["last_optimization_finished_at"] = completed_at.isoformat(timespec="seconds")
    if complete:
        state["last_successful_optimization_at"] = completed_at.isoformat(timespec="seconds")
    state.pop("retry_after", None)
    state.pop("last_failed_optimization_at", None)


def _apply_pending_worker(cfg, apply_lock, reason):
    try:
        with apply_lock:
            applied = apply_pending(cfg, force=False)
        if applied:
            LOG.info("%s: применено SET=%d", reason, applied)
    except Exception as exc:
        LOG.exception("%s: применение SET не удалось: %s", reason, exc)


def trading_terminal_watchdog(cfg, stop_event, apply_lock):
    """Check trading MT5 exactly at local hour boundaries; never poll every 5 min."""
    LOG.info("WATCHDOG торгового MT5: первая проверка будет в начале следующего часа")
    while not stop_event.is_set():
        now = now_local()
        next_hour = now.replace(minute=0, second=0, microsecond=0) + timedelta(hours=1)
        wait_seconds = max(0.1, (next_hour - now).total_seconds())
        if stop_event.wait(wait_seconds):
            return
        try:
            if in_trading_window(now_local(), cfg.get("trading_window", {})):
                ensure_trading_terminal(cfg, "ЧАСОВАЯ ПРОВЕРКА")
                threading.Thread(
                    target=_apply_pending_worker,
                    args=(cfg, apply_lock, "Часовая проверка"),
                    name="trading-mt5-apply",
                    daemon=True,
                ).start()
            else:
                LOG.info("ЧАСОВАЯ ПРОВЕРКА: вне торгового окна")
        except Exception as exc:
            LOG.exception("ОШИБКА ЧАСОВОЙ ПРОВЕРКИ: %s", exc)


def seconds_to_gate(state, now):
    gate = state.get("next_optimization_at")
    if not gate:
        return 0.0
    try:
        due = datetime.fromisoformat(gate)
        if due.tzinfo is None:
            due = due.astimezone()
        return max(0.0, (due - now).total_seconds())
    except Exception:
        return 60.0


def run_forever():
    cfg = load_config()
    setup_logging(str(ROOT / "trade_python.log"))
    state = load_auto_state()
    stop_event = threading.Event()
    apply_lock = threading.Lock()

    start_dashboard()
    print("\n========== MT5-TRADE AUTONOMOUS ==========")
    print(f"Торговый MT5: {cfg['trading_mt5_path']}")
    print("Тестовый MT5 из торгового Python НЕ запускается и НЕ контролируется.")
    print("Торговый MT5: только в начале каждого часа.")
    print("Оптимизация: каждые 14 дней в 20:30; если срок уже прошёл, запуск выполняется при следующем старте supervisor.")

    watchdog = threading.Thread(
        target=trading_terminal_watchdog,
        args=(cfg, stop_event, apply_lock),
        name="trading-mt5-hourly-watchdog",
        daemon=True,
    )
    watchdog.start()

    # Trading MT5 is checked/launched only at the beginning of each hour.
    # Starting the supervisor must not trigger an immediate MT5 launch.

    last_block_log = None
    try:
        while True:
            now = now_local()
            try:
                running_pid = active_optimizer_pid()

                # A completed optimization may still have SETs that were not
                # actually applied to the trading MT5.  Retry APPLICATION only;
                # never start another optimization for this case.
                apply_complete, apply_missing = current_batch_application_status(cfg)
                if apply_missing and running_pid is None:
                    try:
                        if TradingTerminal(cfg["trading_mt5_path"]).is_running():
                            with apply_lock:
                                apply_pending(cfg, force=False)
                        apply_complete, apply_missing = current_batch_application_status(cfg)
                        if apply_complete:
                            finalize_application_schedule(state)
                            LOG.info("Все SET текущего batch применены. 14-дневное расписание сохранено.")
                        else:
                            retry_at = retry_apply_schedule(state)
                            save_auto_state(state)
                            LOG.info(
                                "Ожидается применение SET: %s | повтор применения: %s",
                                ", ".join(apply_missing) if apply_missing else "торговый MT5 недоступен",
                                retry_at.isoformat(timespec="seconds"),
                            )
                    except Exception as exc:
                        retry_at = retry_apply_schedule(state)
                        save_auto_state(state)
                        LOG.exception("Ошибка повторного применения SET: %s; повтор: %s", exc, retry_at)
                    time.sleep(1)
                    continue

                if cycle_due(state, now, cfg):
                    if running_pid is not None:
                        marker = now.strftime("%Y-%m-%d %H:%M")
                        if marker != last_block_log:
                            LOG.info(
                                "Автооптимизация уже должна быть запущена, но запуск заблокирован: %s. "
                                "Второй экземпляр НЕ запускается; ждём полного завершения текущего владельца.",
                                (f"PID={running_pid}" if running_pid > 0 else "другой autonomous.py уже владеет блокировкой"),
                            )
                            last_block_log = marker
                    else:
                        started_at = now_local()
                        try:
                            manifest = run_optimizer()
                            trade_cfg = load_config()
                            batch_id, published = publish_cycle(manifest)
                            LOG.info(
                                "Цикл оптимизации завершён: complete=%s | свежих SET=%d | failed=%d | batch=%s",
                                manifest.get("complete"),
                                len(published),
                                len(manifest.get("failed_symbols", [])),
                                batch_id,
                            )

                            # Always publish/apply whatever valid SETs this cycle produced.
                            # Missing currencies keep their previous installed SET.
                            if TradingTerminal(trade_cfg["trading_mt5_path"]).is_running():
                                try:
                                    with apply_lock:
                                        applied = apply_pending(trade_cfg, force=False)
                                    LOG.info("Batch %s применён к торговому MT5: %d SET", batch_id, applied)
                                except Exception as exc:
                                    LOG.exception("Batch опубликован, но применение не удалось: %s", exc)

                            # A partial cycle is NOT a completed 14-day cycle.
                            # The next run resumes the same cycle and skips symbols
                            # already completed successfully.
                            completed_at = now_local()
                            if manifest.get("complete"):
                                # A successful optimization completes the 14-day cycle
                                # independently of whether the trading MT5 is currently
                                # inside its weekday trading window. SET application is
                                # a separate retryable operation.
                                schedule_next(state, completed_at, cfg, complete=True)
                                apply_complete, apply_missing = current_batch_application_status(trade_cfg)
                                if apply_complete:
                                    state.pop("next_apply_at", None)
                                    state.pop("retry_after", None)
                                    state.pop("last_failed_optimization_at", None)
                                    save_auto_state(state)
                                else:
                                    retry_at = retry_apply_schedule(state, completed_at + timedelta(minutes=5))
                                    save_auto_state(state)
                                    LOG.warning(
                                        "Оптимизация %d/%d завершена, но SET применены не все: %s. "
                                        "14-дневный график зафиксирован; повтор применения %s",
                                        len(manifest.get("completed_symbols", [])),
                                        len(manifest.get("expected_symbols", [])),
                                        ", ".join(apply_missing) if apply_missing else "неизвестно",
                                        retry_at.isoformat(timespec="seconds"),
                                    )
                            else:
                                retry_at = completed_at + timedelta(minutes=5)
                                state["last_failed_optimization_at"] = completed_at.isoformat(timespec="seconds")
                                state["next_optimization_at"] = retry_at.isoformat(timespec="seconds")
                                state["retry_after"] = retry_at.isoformat(timespec="seconds")
                                save_auto_state(state)
                            LOG.info(
                                "Следующая автоматическая оптимизация: %s",
                                state["next_optimization_at"],
                            )
                        except Exception as exc:
                            LOG.exception("Цикл оптимизации завершился ошибкой: %s", exc)
                            failed_at = now_local()
                            state["last_failed_optimization_at"] = failed_at.isoformat(timespec="seconds")

                            # Never overwrite a valid future 14-day schedule that
                            # belongs to the last successful optimization. This
                            # prevents a stale/accidental run from converting
                            # 2026-10-04 20:30 into a +5-minute retry.
                            try:
                                current_gate = datetime.fromisoformat(
                                    state.get("next_optimization_at", "")
                                )
                                if current_gate.tzinfo is None:
                                    current_gate = current_gate.astimezone()
                            except Exception:
                                current_gate = None

                            last_success_raw = state.get("last_successful_optimization_at")
                            try:
                                last_success = (
                                    datetime.fromisoformat(last_success_raw)
                                    if last_success_raw else None
                                )
                                if last_success is not None and last_success.tzinfo is None:
                                    last_success = last_success.astimezone()
                            except Exception:
                                last_success = None

                            if current_gate is not None and current_gate > failed_at and last_success is not None:
                                # Preserve the existing valid schedule.
                                state.pop("retry_after", None)
                                save_auto_state(state)
                                LOG.warning(
                                    "Ошибка оптимизации НЕ меняет действующее расписание: %s",
                                    state["next_optimization_at"],
                                )
                            else:
                                # This was an actually due optimization attempt.
                                # Retry after 5 minutes.
                                retry_at = failed_at + timedelta(minutes=5)
                                state["next_optimization_at"] = retry_at.isoformat(timespec="seconds")
                                state["retry_after"] = retry_at.isoformat(timespec="seconds")
                                save_auto_state(state)
                                LOG.warning(
                                    "Повтор автоматической оптимизации назначен на %s",
                                    state["next_optimization_at"],
                                )
                        finally:
                            clear_active_optimizer()
            except Exception as exc:
                LOG.exception("Ошибка автономного цикла: %s", exc)

            # Wake at the due time instead of polling every 60 seconds. Cap at
            # 60s so external/manual completion can be noticed promptly.
            delay = seconds_to_gate(state, now_local())
            if delay <= 0:
                delay = 1.0
            stop_event.wait(min(60.0, delay))
    finally:
        stop_event.set()
        clear_active_optimizer()


if __name__ == "__main__":
    run_forever()


