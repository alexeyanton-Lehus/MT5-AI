@echo off
setlocal
cd /d C:\MT5_AI\MT5-TRADE
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%CD%\install_autostart.ps1"
if errorlevel 1 (
    echo.
    echo INSTALL FAILED.
    pause
    exit /b 1
)
echo.
echo AUTOSTART INSTALLED AND STARTED.
pause
