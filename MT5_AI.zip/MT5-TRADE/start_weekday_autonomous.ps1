$ErrorActionPreference = 'Stop'
# This launcher is used by Task Scheduler. It NEVER starts Python on Saturday/Sunday.
if ((Get-Date).DayOfWeek -in @([DayOfWeek]::Saturday, [DayOfWeek]::Sunday)) { exit 0 }
$Project = 'C:\MT5_AI\MT5-TRADE'
$Script = Join-Path $Project 'autonomous.py'
$Python = (Get-Command pythonw.exe -ErrorAction SilentlyContinue).Source
if (-not $Python) { $Python = Join-Path $env:LOCALAPPDATA 'Programs\Python\Python313\pythonw.exe' }
if (-not (Test-Path $Python)) { throw "Не найден pythonw.exe" }
$running = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
    $_.Name -in @('python.exe','pythonw.exe') -and $_.CommandLine -and $_.CommandLine -match '(?i)C:\\MT5_AI\\MT5-TRADE\\autonomous\.py'
}
if (-not $running) { Start-Process -FilePath $Python -ArgumentList "`"$Script`"" -WorkingDirectory $Project }
