$ErrorActionPreference='Stop'
$Project = 'C:\MT5_AI\MT5-TRADE'
$Script = Join-Path $Project 'autonomous.py'
if (-not (Test-Path $Script)) { throw "Не найден $Script" }
$Python = Join-Path $env:LOCALAPPDATA 'Programs\Python\Python313\pythonw.exe'
if (-not (Test-Path $Python)) { $Python = (Get-Command pythonw.exe -ErrorAction Stop).Source }
# The supervisor must run every day because optimization has its own 14-day
# schedule. The supervisor, not this launcher, enforces the trading MT5 window.
Start-Process -FilePath $Python -ArgumentList @('"'+$Script+'"') -WorkingDirectory $Project
