import logging
from pathlib import Path

from trade_mt5.config import load_config
from trade_mt5.input_manager import InputManager
from trade_mt5.logging_setup import setup_logging
from trade_mt5.state import StateStore
from trade_mt5.terminal import TradingTerminal
from trade_mt5.ui import MT5UI


def main():
    cfg = load_config()
    setup_logging(str(Path(__file__).resolve().parent / "trade_python.log"))
    log = logging.getLogger(__name__)

    print("\n========== MT5-TRADE v1.4.1 ==========")
    print("Режим: только уже запущенный торговый MT5")

    terminal = TradingTerminal(cfg["trading_mt5_path"])
    pids = terminal.pids()
    if not pids:
        raise RuntimeError(
            "Торговый MT5 не запущен. Python НЕ будет запускать другой терминал. "
            f"Ожидаемый terminal64.exe: {terminal.path}"
        )
    if len(pids) > 1:
        raise RuntimeError(f"Найдено несколько экземпляров торгового MT5: {pids}. Автоматически не выбираю.")
    pid = pids[0]
    terminal.pid = pid
    print(f"Торговый MT5: PID={pid}")

    manager = InputManager(cfg["trading_input"])
    batch = manager.latest_batch()
    if not batch:
        print("Предупреждение: нет завершённого optimization_complete.json.")
        print("Проверяю SET-файлы непосредственно в trading_input.")

    state = StateStore(Path(cfg["trading_input"]) / "trade_state.json")
    ui = MT5UI(pid, cfg["expert_name"], cfg.get("timeframe", "H4"))
    ui.connect()

    pending = manager.pending_by_symbol()
    if not pending:
        print("В trading_input нет SET-файлов для применения.")
        return

    print(f"Batch: {batch.get('batch_id') if batch else 'не определён'}")
    print(f"Кандидатов к применению: {len(pending)}")
    print(f"Таймфрейм: {cfg.get('timeframe', 'H4')}")

    applied = 0
    for symbol, set_path in sorted(pending.items()):
        current_hash = state.installed_hash(symbol)
        if current_hash:
            try:
                if StateStore.sha256(set_path) == current_hash:
                    print(f"{symbol}: уже установлен — пропуск")
                    continue
            except OSError:
                pass

        print(f"{symbol}: SET={set_path.name}")
        timeframe = cfg.get("timeframe", "H4")
        if not ui.chart_exists(symbol, timeframe):
            log.info("График %s,%s не открыт. Открываю его через интерфейс уже запущенного торгового MT5.", symbol, timeframe)
            ui.open_chart(symbol, timeframe)
        ui.select_chart(symbol, timeframe)

        # CRITICAL SAFETY GATE: F7 is forbidden until the selected chart is
        # positively confirmed to contain our EA. A different EA is never opened.
        if not ui.chart_has_target_ea(symbol, timeframe):
            print(f"{symbol}: ПРОПУСК — на {symbol},{timeframe} не подтверждён {cfg['expert_name']}")
            continue

        ui.load_set_in_properties(set_path, symbol=symbol, timeframe=timeframe)

        # Mark the exact SET only after Load + OK completed successfully.
        completed_path = manager.mark_completed(set_path)
        state.mark_installed(symbol, completed_path, batch.get("batch_id") if batch else None)
        applied += 1
        print(f"{symbol}: применён, отмечен -compl")

    if batch:
        state.data["last_batch"] = batch.get("batch_id")
    state.save()
    print(f"Готово. Применено: {applied}; пропущено как уже установленные: {len(pending) - applied}")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        logging.getLogger(__name__).exception("ОШИБКА: %s", exc)
        print(f"ОШИБКА: {exc}")
