from pywinauto import Desktop

for w in Desktop(backend="uia").windows():
    if w.class_name() == "MetaQuotes::MetaTrader::5.00":
        print("Нашёл:", w.window_text())

        for c in w.descendants():
            try:
                print(c.friendly_class_name(), "|", c.window_text())
            except:
                pass

        break