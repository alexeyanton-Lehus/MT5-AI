from pywinauto import Desktop

desktop = Desktop(backend="uia")

mt5 = desktop.window(class_name="MetaQuotes::MetaTrader::5.00")

tester = mt5.child_window(title="Тестер стратегій")

tab = tester.child_window(control_type="Tab")

for item in tab.children():
    print(item.window_text())

settings = tab.child_window(title="Установки", control_type="TabItem")

settings.click_input()    # НЕ select()