@echo off
cd /d C:\MT5_AI
python .\src\portfolio_analyzer.py
pause
